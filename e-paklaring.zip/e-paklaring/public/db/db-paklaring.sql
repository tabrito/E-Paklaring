-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2026 at 08:27 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db-paklaring`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrasi`
--

CREATE TABLE `administrasi` (
  `id_administrasi` varchar(10) NOT NULL,
  `id_exit_clear` varchar(10) DEFAULT NULL,
  `gaji_terakhir` int(20) DEFAULT NULL,
  `sisa_cuti` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `administrasi`
--

INSERT INTO `administrasi` (`id_administrasi`, `id_exit_clear`, `gaji_terakhir`, `sisa_cuti`) VALUES
('ADM-0001', 'EC-0001', 34000000, 9),
('ADM-0002', 'EC-0002', 20000000, 4);

-- --------------------------------------------------------

--
-- Table structure for table `approver`
--

CREATE TABLE `approver` (
  `nik` varchar(10) NOT NULL,
  `id_user` varchar(10) DEFAULT NULL,
  `id_departemen` varchar(10) NOT NULL,
  `jabatan` varchar(50) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `ttd` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `approver`
--

INSERT INTO `approver` (`nik`, `id_user`, `id_departemen`, `jabatan`, `first_name`, `last_name`, `ttd`) VALUES
('101010', 'U-0014', 'D-0011', 'Supervisor', 'Abdul', 'Karim', '69c3b1fc0167f.png'),
('101918', 'U-0012', 'D-0009', 'Supervisor', 'Chou', 'Tien-Chen', '69c3b204437e7.png'),
('123123', 'U-0008', 'D-0008', 'Manager', 'Ahmad', 'Ariyanto', '1774465954_ttd7.png'),
('141414', 'U-0013', 'D-0010', 'Supervisor', 'Yuki', 'Katero', '69c3b222e51c5.png'),
('2001', 'U-0000', 'D-0012', 'Supervisor', 'Muhammad', 'Amir', NULL),
('22332233', 'U-0011', 'D-0003', 'Supervisor', 'Rafael', 'Struick', '69c3b21a05ae5.png'),
('33443344', 'U-0010', 'D-0005', 'Supervisor', 'Farhan', 'Halim', '69c3b2113f7da.png');

-- --------------------------------------------------------

--
-- Table structure for table `aset`
--

CREATE TABLE `aset` (
  `id_aset` varchar(10) NOT NULL,
  `id_exit_clear` varchar(10) DEFAULT NULL,
  `id_card` varchar(50) DEFAULT NULL,
  `laptop` varchar(50) DEFAULT NULL,
  `seragam` varchar(50) DEFAULT NULL,
  `file_kerja` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `aset`
--

INSERT INTO `aset` (`id_aset`, `id_exit_clear`, `id_card`, `laptop`, `seragam`, `file_kerja`) VALUES
('AS-0001', 'EC-0001', 'Sudah', 'Sudah', 'Sudah', 'Sudah'),
('AS-0002', 'EC-0002', 'Sudah', 'Sudah', 'Sudah', 'Sudah');

-- --------------------------------------------------------

--
-- Table structure for table `departemen`
--

CREATE TABLE `departemen` (
  `id_departemen` varchar(10) NOT NULL,
  `departemen` varchar(100) DEFAULT NULL,
  `id_instansi` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departemen`
--

INSERT INTO `departemen` (`id_departemen`, `departemen`, `id_instansi`) VALUES
('D-0003', 'Finance', 'I-0001'),
('D-0005', 'Warehouse', 'I-0002'),
('D-0008', 'HRD', 'I-0001'),
('D-0009', 'QC', 'I-0001'),
('D-0010', 'Production', 'I-0002'),
('D-0011', 'RND', 'I-0001'),
('D-0012', 'QC', 'I-0002');

-- --------------------------------------------------------

--
-- Table structure for table `exit_clear`
--

CREATE TABLE `exit_clear` (
  `id_exit_clear` varchar(10) NOT NULL,
  `id_pengajuan` varchar(10) DEFAULT NULL,
  `id_approver_hr` varchar(10) DEFAULT NULL,
  `id_approver_spv` varchar(10) DEFAULT NULL,
  `approval_hr` varchar(50) DEFAULT NULL,
  `approval_spv` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exit_clear`
--

INSERT INTO `exit_clear` (`id_exit_clear`, `id_pengajuan`, `id_approver_hr`, `id_approver_spv`, `approval_hr`, `approval_spv`) VALUES
('EC-0001', 'P-0001', '123123', '22332233', 'Approved', 'Rejected'),
('EC-0002', 'P-0002', '123123', '33443344', 'Approved', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `instansi`
--

CREATE TABLE `instansi` (
  `id_instansi` varchar(10) NOT NULL,
  `instansi` varchar(100) DEFAULT NULL,
  `alamat` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `instansi`
--

INSERT INTO `instansi` (`id_instansi`, `instansi`, `alamat`) VALUES
('I-0001', 'PT. Maju Jaya Abadi', 'Jakarta Selatan'),
('I-0002', 'PT. Mitra Karya Utama', 'Tangerang');

-- --------------------------------------------------------

--
-- Table structure for table `interview`
--

CREATE TABLE `interview` (
  `id_interview` varchar(10) NOT NULL,
  `id_exit_clear` varchar(10) DEFAULT NULL,
  `alasan` text DEFAULT NULL,
  `kepuasan` varchar(50) DEFAULT NULL,
  `apresiasi` text DEFAULT NULL,
  `saran` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `interview`
--

INSERT INTO `interview` (`id_interview`, `id_exit_clear`, `alasan`, `kepuasan`, `apresiasi`, `saran`) VALUES
('IV-0001', 'EC-0001', 'pp', 'Tidak Puas', 'aa', 'vv'),
('IV-0002', 'EC-0002', 'qwe', 'Cukup Puas', 'fds', 'hhh');

-- --------------------------------------------------------

--
-- Table structure for table `karyawan`
--

CREATE TABLE `karyawan` (
  `nik` varchar(10) NOT NULL,
  `id_user` varchar(10) DEFAULT NULL,
  `id_departemen` varchar(10) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `jabatan` varchar(50) DEFAULT NULL,
  `jenis_kelamin` varchar(20) DEFAULT NULL,
  `tempat_lahir` varchar(50) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `tanggal_masuk` date DEFAULT NULL,
  `tanggal_resign` date DEFAULT NULL,
  `tanggal_keluar` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `karyawan`
--

INSERT INTO `karyawan` (`nik`, `id_user`, `id_departemen`, `first_name`, `last_name`, `jabatan`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `tanggal_masuk`, `tanggal_resign`, `tanggal_keluar`) VALUES
('1001', 'U-0000', 'D-0009', 'Budi', 'Santoso', 'Staff', 'Laki-laki', 'Jakarta', '0000-00-00', '0000-00-00', NULL, NULL),
('137865', 'U-0005', 'D-0003', 'Erika', 'Febriani', 'Staff', 'Perempuan', 'Tangerang', '1995-01-10', '2020-01-01', '2024-12-01', '2024-12-30'),
('1456145', 'U-0015', 'D-0005', 'Siti', 'Mutmainah', 'Staff', 'Perempuan', 'Bogor', '1998-06-16', '2018-06-21', '2026-03-02', '2026-03-31');

-- --------------------------------------------------------

--
-- Table structure for table `paklaring`
--

CREATE TABLE `paklaring` (
  `id_paklaring` varchar(10) NOT NULL,
  `id_pengajuan` varchar(10) DEFAULT NULL,
  `no_paklaring` varchar(50) DEFAULT NULL,
  `tanggal` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `paklaring`
--

INSERT INTO `paklaring` (`id_paklaring`, `id_pengajuan`, `no_paklaring`, `tanggal`) VALUES
('PAK-0001', 'P-0001', 'PAK-NOV-001', '2026-03-23'),
('PAK-0002', 'P-0002', 'PAK-NOV-001', '2026-03-23');

-- --------------------------------------------------------

--
-- Table structure for table `pengajuan`
--

CREATE TABLE `pengajuan` (
  `id_pengajuan` varchar(10) NOT NULL,
  `nik` varchar(10) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pengajuan`
--

INSERT INTO `pengajuan` (`id_pengajuan`, `nik`, `tanggal`, `status`) VALUES
('P-0001', '137865', '2026-03-23', 'Proses'),
('P-0002', '1456145', '2026-03-23', 'Proses');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` varchar(10) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(50) DEFAULT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `username`, `password`, `role`, `status`) VALUES
('U-0000', 'non-user', '123456', 'non-user', 'Non-active'),
('U-0005', 'erika', '$2y$10$9cajkWFWjdYWR4sJK6PpDeBJRXX/Ams.CyHpGE9PyvOyy3R9gd3h.', 'Karyawan', 'Active'),
('U-0008', 'ariyanto', '$2y$10$0eTaIChcZ5i30yu8YUcUm.jFsrfH/kcASaVEqTCes47VBFbQSPGwW', 'HRD', 'Active'),
('U-0010', 'farhan', '$2y$10$FPsXqbyOzYUpbBZDXNPyBOFr3cA3JxwVQbNK.G5vr12wse61Z.B3y', 'Supervisor', 'Active'),
('U-0011', 'rafael', '$2y$10$0A5HgxyhaCK0IgXCxzeQD.tCkf4PMCSEvSkojjjShP6rvpX71AWR.', 'Supervisor', 'Active'),
('U-0012', 'chou', '$2y$10$RXSQfw/JLJRSq0qP6f44Bev0xdH35YZSGiVjv2eVYPU0c41AaLVkS', 'Supervisor', 'Active'),
('U-0013', 'yuki', '$2y$10$FFAqCS1GTAZgzVgdjKHX/e9PX06gzEE9.1YyszxuX/DbxcYWvwFCS', 'Supervisor', 'Active'),
('U-0014', 'abdul', '$2y$10$K1ClbY7TB7mTLDkXkXUQqun9OUg438kmkvsEpLZ2gy3mdvDPd9cUS', 'Supervisor', 'Active'),
('U-0015', 'siti', '$2y$10$gDD..hoNOkHiTUgUeiw6v.sfX2sfuGMq4rSxvXYgMG02EK46GJ2XC', 'Karyawan', 'Active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrasi`
--
ALTER TABLE `administrasi`
  ADD PRIMARY KEY (`id_administrasi`),
  ADD KEY `administrasi_ibfk_1` (`id_exit_clear`);

--
-- Indexes for table `approver`
--
ALTER TABLE `approver`
  ADD PRIMARY KEY (`nik`),
  ADD KEY `approver_ibfk_1` (`id_user`),
  ADD KEY `approver_ibfk_2` (`id_departemen`);

--
-- Indexes for table `aset`
--
ALTER TABLE `aset`
  ADD PRIMARY KEY (`id_aset`),
  ADD KEY `aset_ibfk_1` (`id_exit_clear`);

--
-- Indexes for table `departemen`
--
ALTER TABLE `departemen`
  ADD PRIMARY KEY (`id_departemen`),
  ADD KEY `departemen_ibfk_1` (`id_instansi`);

--
-- Indexes for table `exit_clear`
--
ALTER TABLE `exit_clear`
  ADD PRIMARY KEY (`id_exit_clear`),
  ADD KEY `exit_clear_ibfk_1` (`id_pengajuan`),
  ADD KEY `exit_clear_ibfk_2` (`id_approver_hr`),
  ADD KEY `exit_clear_ibfk_3` (`id_approver_spv`);

--
-- Indexes for table `instansi`
--
ALTER TABLE `instansi`
  ADD PRIMARY KEY (`id_instansi`);

--
-- Indexes for table `interview`
--
ALTER TABLE `interview`
  ADD PRIMARY KEY (`id_interview`),
  ADD KEY `interview_ibfk_1` (`id_exit_clear`);

--
-- Indexes for table `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`nik`),
  ADD KEY `karyawan_ibfk_1` (`id_user`),
  ADD KEY `karyawan_ibfk_2` (`id_departemen`);

--
-- Indexes for table `paklaring`
--
ALTER TABLE `paklaring`
  ADD PRIMARY KEY (`id_paklaring`),
  ADD KEY `paklaring_ibfk_1` (`id_pengajuan`);

--
-- Indexes for table `pengajuan`
--
ALTER TABLE `pengajuan`
  ADD PRIMARY KEY (`id_pengajuan`),
  ADD KEY `pengajuan_ibfk_1` (`nik`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `administrasi`
--
ALTER TABLE `administrasi`
  ADD CONSTRAINT `administrasi_ibfk_1` FOREIGN KEY (`id_exit_clear`) REFERENCES `exit_clear` (`id_exit_clear`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `approver`
--
ALTER TABLE `approver`
  ADD CONSTRAINT `approver_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `approver_ibfk_2` FOREIGN KEY (`id_departemen`) REFERENCES `departemen` (`id_departemen`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `aset`
--
ALTER TABLE `aset`
  ADD CONSTRAINT `aset_ibfk_1` FOREIGN KEY (`id_exit_clear`) REFERENCES `exit_clear` (`id_exit_clear`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `departemen`
--
ALTER TABLE `departemen`
  ADD CONSTRAINT `departemen_ibfk_1` FOREIGN KEY (`id_instansi`) REFERENCES `instansi` (`id_instansi`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `exit_clear`
--
ALTER TABLE `exit_clear`
  ADD CONSTRAINT `exit_clear_ibfk_1` FOREIGN KEY (`id_pengajuan`) REFERENCES `pengajuan` (`id_pengajuan`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `exit_clear_ibfk_2` FOREIGN KEY (`id_approver_hr`) REFERENCES `approver` (`nik`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `exit_clear_ibfk_3` FOREIGN KEY (`id_approver_spv`) REFERENCES `approver` (`nik`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `interview`
--
ALTER TABLE `interview`
  ADD CONSTRAINT `interview_ibfk_1` FOREIGN KEY (`id_exit_clear`) REFERENCES `exit_clear` (`id_exit_clear`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `karyawan`
--
ALTER TABLE `karyawan`
  ADD CONSTRAINT `karyawan_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `karyawan_ibfk_2` FOREIGN KEY (`id_departemen`) REFERENCES `departemen` (`id_departemen`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `paklaring`
--
ALTER TABLE `paklaring`
  ADD CONSTRAINT `paklaring_ibfk_1` FOREIGN KEY (`id_pengajuan`) REFERENCES `pengajuan` (`id_pengajuan`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pengajuan`
--
ALTER TABLE `pengajuan`
  ADD CONSTRAINT `pengajuan_ibfk_1` FOREIGN KEY (`nik`) REFERENCES `karyawan` (`nik`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
