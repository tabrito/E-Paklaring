<?php
require_once '../vendor/autoload.php';
use Dompdf\Dompdf;

class Exit_clear extends Controller

{
  public function index()
  {
    if (!isset($_SESSION['user'])) {
        // Arahkan ke halaman login
        header('Location: ' . BASEURL . '/login');
        exit;
    }
    $data['judul'] = 'Exit Clear';
    $data['req'] = $this->model('Request_model')->getAllRequest();
    $data['exi'] = $this->model('Exit_clear_model')->getExitClear($_SESSION['user']['nik']);
    $data['current'] = $_SESSION['current'] ?? 0;
    unset($_SESSION['current']);
    $this->view('templates/header', $data);
    $this->view('exit_clear/index', $data);
    $this->view('templates/footer');
  }

    public function tambahInterview()
  {
      if ($this->model('Exit_clear_model')->tambahDataInterview($_POST) > 0) {
          // Flasher::setFlash('interview', 'berhasil', 'ditambahkan', 'warning');
          $_SESSION['current'] = 0;
          header('Location: ' . BASEURL . '/exit_clear');
          exit;
      } else {
          // Flasher::setFlash('interview', 'gagal', 'ditambahkan', 'secondary');
          $_SESSION['current'] = 0;
          header('Location: ' . BASEURL . '/exit_clear');
          exit;
      }
  }

public function cetak_pdf($id)
{

    $data['req'] = $this->model('Request_model')->getAllRequest();
    $data['exit'] = $this->model('Exit_clear_model')->getExitClearLengkap($_SESSION['user']['nik']);
        $data['app'] = $this->model('Exit_clear_model')->getApprover($id);
    ob_start();
    require '../app/views/exit_clear/cetak_pdf.php';
    $html = ob_get_clean();

    $dompdf = new Dompdf();
    $dompdf->loadHtml($html);

    $dompdf->setPaper('A4', 'portrait');

    $dompdf->render();
    $dompdf->stream("exit_clear.pdf", ["Attachment" => false]);

}

    public function tambahAset()
  {
      if ($this->model('Exit_clear_model')->tambahDataAset($_POST) > 0) {
          // Flasher::setFlash('interview', 'berhasil', 'ditambahkan', 'warning');
          $_SESSION['current'] = 1;
          header('Location: ' . BASEURL . '/exit_clear');
          exit;
      } else {
          // Flasher::setFlash('interview', 'gagal', 'ditambahkan', 'secondary');
          $_SESSION['current'] = 1;
          header('Location: ' . BASEURL . '/exit_clear');
          exit;
      }
  }

    public function tambahAdmin()
  {
      if ($this->model('Exit_clear_model')->tambahDataAdmin($_POST) > 0) {
          // Flasher::setFlash('interview', 'berhasil', 'ditambahkan', 'warning');
          $_SESSION['current'] = 2;
          header('Location: ' . BASEURL . '/exit_clear');
          exit;
      } else {
          // Flasher::setFlash('interview', 'gagal', 'ditambahkan', 'secondary');
          $_SESSION['current'] = 2;
          header('Location: ' . BASEURL . '/exit_clear');
          exit;
      }
  }

    public function ubahInterview()
  {
      if ($this->model('Exit_clear_model')->ubahDataInterview($_POST) > 0) {
          // Flasher::setFlash('interview', 'berhasil', 'diubah', 'warning');
          $_SESSION['current'] = 0;
          header('Location: ' . BASEURL . '/exit_clear');
          exit;
      } else {
          // Flasher::setFlash('interview', 'gagal', 'diubah', 'secondary');
          $_SESSION['current'] = 0;
          header('Location: ' . BASEURL . '/exit_clear');
          exit;
      }
  }

    public function ubahAset()
  {
      if ($this->model('Exit_clear_model')->ubahDataAset($_POST) > 0) {
          // Flasher::setFlash('interview', 'berhasil', 'diubah', 'warning');
          $_SESSION['current'] = 1;
          header('Location: ' . BASEURL . '/exit_clear');
          exit;
      } else {
          // Flasher::setFlash('interview', 'gagal', 'diubah', 'secondary');
          $_SESSION['current'] = 1;
          header('Location: ' . BASEURL . '/exit_clear');
          exit;
      }
  }

    public function ubahAdmin()
  {
      if ($this->model('Exit_clear_model')->ubahDataAdmin($_POST) > 0) {
          // Flasher::setFlash('interview', 'berhasil', 'diubah', 'warning');
          $_SESSION['current'] = 2;
          header('Location: ' . BASEURL . '/exit_clear');
          exit;
      } else {
          // Flasher::setFlash('interview', 'gagal', 'diubah', 'secondary');
          $_SESSION['current'] = 2;
          header('Location: ' . BASEURL . '/exit_clear');
          exit;
      }
  }

    public function resetInterview($id)
  {
      if ($this->model('Exit_clear_model')->resetDataInterview($id) > 0) {
          // Flasher::setFlash('interview', 'berhasil', 'direset', 'warning');
          $_SESSION['current'] = 0;
          header('Location: ' . BASEURL . '/exit_clear');
          exit;
      } else {
          // Flasher::setFlash('interview', 'gagal', 'direset', 'secondary');
          $_SESSION['current'] = 0;
          header('Location: ' . BASEURL . '/exit_clear');
          exit;
      }
  }

    public function resetAset($id)
  {
      if ($this->model('Exit_clear_model')->resetDataAset($id) > 0) {
          // Flasher::setFlash('interview', 'berhasil', 'direset', 'warning');
          $_SESSION['current'] = 1;
          header('Location: ' . BASEURL . '/exit_clear');
          exit;
      } else {
          // Flasher::setFlash('interview', 'gagal', 'direset', 'secondary');
          $_SESSION['current'] = 1;
          header('Location: ' . BASEURL . '/exit_clear');
          exit;
      }
  }

    public function resetAdmin($id)
  {
      if ($this->model('Exit_clear_model')->resetDataAdmin($id) > 0) {
          // Flasher::setFlash('interview', 'berhasil', 'direset', 'warning');
          $_SESSION['current'] = 2;
          header('Location: ' . BASEURL . '/exit_clear');
          exit;
      } else {
          // Flasher::setFlash('interview', 'gagal', 'direset', 'secondary');
          $_SESSION['current'] = 2;
          header('Location: ' . BASEURL . '/exit_clear');
          exit;
      }
  }

}
