<?php
class Login extends Controller {

    public function index() {
        if (isset($_SESSION['user'])) {
            header('Location: ' . BASEURL . '/home');
            exit;
        }
        $this->view('login/index');
    }

    public function auth() {

        $username = $_POST['username'];
        $password = $_POST['password'];

        $user = $this->model('Users_model')->getUserByUsername($username);

        if ($user && password_verify($password, $user['password'])) {
            // Login berhasil, simpan session
            $_SESSION['user'] = [
                'id_user' => $user['id_user'],
                'username' => $user['username'],
                'first_name' => $user['first_name'],
                'last_name' => $user['last_name'],
                'role' => $user['role'],
                'id_departemen' => $user['id_departemen'],
                'nik' => $user['nik'],
                'jabatan' => $user['jabatan']
            ];

            // regenerasi session id untuk mencegah session fixation
            session_regenerate_id(true);

            header('Location: ' . BASEURL . '/home');
            exit;
        } else {
            Flasher::setFlash('login', 'gagal', '', 'danger');
            header('Location: ' . BASEURL . '/login');
            exit;
        }
    }

    public function logout() {
        session_start();
        session_destroy();
        header('Location: ' . BASEURL . '/login');
        exit;
    }
}
