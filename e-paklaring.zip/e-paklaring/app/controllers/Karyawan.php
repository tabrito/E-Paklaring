<?php
require_once '../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;
class Karyawan extends Controller
{
  public function index()
  {
    if (!isset($_SESSION['user'])) {
        // Arahkan ke halaman login
        header('Location: ' . BASEURL . '/login');
        exit;
    }
    $data['judul'] = 'Data Karyawan';
    $data['kar'] = $this->model('Karyawan_model')->getAllKaryawan();
    $data['ins'] = $this->model('Instansi_model')->getAllInstansi();
    $this->view('templates/header', $data);
    $this->view('karyawan/index', $data);
    $this->view('templates/footer');
  }

public function importExcel()
{

    if (!isset($_FILES['file_excel'])) {
        header('Location: ' . BASEURL . '/karyawan');
        exit;
    }

    require '../vendor/autoload.php';

    $file = $_FILES['file_excel']['tmp_name'];

    $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($file);

    $rows = $spreadsheet->getActiveSheet()->toArray();

    foreach ($rows as $i => $row) {

        if ($i == 0) continue;

        $namaDept = $row[7];
        $namaInstansi = $row[8];

        // cari departemen berdasarkan dept + instansi
        $dept = $this->model('Instansi_model')
                     ->getByNamaDanInstansi($namaDept, $namaInstansi);

        if (!$dept) continue;

        $id_dept = $dept['id_departemen'];

        $data = [
            "nik" => $row[0],
            "first_name" => $row[1],
            "last_name" => $row[2],
            "jenis_kelamin" => $row[3],
            "tempat_lahir" => $row[4],
            "tanggal_lahir" => $row[5],
            "tanggal_masuk" => $row[6],
            "id_departemen" => $id_dept,
            "jabatan" => $row[9]
        ];

        $this->model('Karyawan_model')
             ->tambahDataKaryawan($data);

    }

    header('Location: ' . BASEURL . '/karyawan');
}

public function downloadTemplate()
{
    $file = '../public/template/template_import_karyawan.xlsx';

    if (file_exists($file)) {

        header('Content-Description: File Transfer');
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="template_import_karyawan.xlsx"');
        header('Content-Length: ' . filesize($file));

        readfile($file);
        exit;
    }

    echo "File tidak ditemukan";
}

      public function tambah()
    {
        if ($this->model('Karyawan_model')->tambahDataKaryawan($_POST) > 0) {
            Flasher::setFlash('karyawan', 'berhasil', 'ditambahkan', 'warning');
            header('Location: ' . BASEURL . '/karyawan');
            exit;
        } else {
            Flasher::setFlash('karyawan', 'gagal', 'ditambahkan', 'secondary');
            header('Location: ' . BASEURL . '/karyawan');
            exit;
        }
    }

    public function update()
    {
        if ($this->model('Karyawan_model')->updateData($_POST) > 0) {
            Flasher::setFlash('karyawan', 'berhasil', 'diupdate', 'warning');
        } else {
            Flasher::setFlash('karyawan', 'gagal', 'diupdate', 'secondary');
        }

        header('Location: ' . BASEURL . '/karyawan');
        exit;
    }

    public function getDepartemen($id_instansi)
    {
        echo json_encode(
            $this->model('Karyawan_model')->getDepartemenByInstansi($id_instansi)
        );
    }

        public function delete($nik)
    {
        if ($this->model('Karyawan_model')->deleteData($nik) > 0) {
            Flasher::setFlash('karyawan', 'berhasil', 'dihapus', 'warning');
        } else {
            Flasher::setFlash('karyawan', 'gagal', 'dihapus', 'secondary');
        }

        header('Location: ' . BASEURL . '/karyawan');
        exit;
    }
}
