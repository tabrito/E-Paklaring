<?php
require_once '../vendor/autoload.php';
use Dompdf\Dompdf;
class Paklaring extends Controller
{
  public function index()
  {
    if (!isset($_SESSION['user'])) {
        // Arahkan ke halaman login
        header('Location: ' . BASEURL . '/login');
        exit;
    }
    $data['judul'] = 'Paklaring';
    if($_SESSION['user']['role'] == 'HRD' OR $_SESSION['user']['role'] == 'Superadmin') {
      $data['pak'] = $this->model('Paklaring_model')->getAllPaklaring();
    } elseif ($_SESSION['user']['role'] == 'Supervisor') {
      $data['pak'] = $this->model('Paklaring_model')->getPaklaringByDept($_SESSION['user']['id_departemen']);
    } elseif ($_SESSION['user']['role'] == 'Karyawan') {
      $data['pak'] = $this->model('Paklaring_model')->getPaklaringByKaryawan($_SESSION['user']['nik']);
      $data['req'] = $this->model('Request_model')->getRequestByKaryawan($_SESSION['user']['nik']);
    }
    $this->view('templates/header', $data);
    $this->view('paklaring/index', $data);
    $this->view('templates/footer');
  }

    public function rilisPaklaring($id)
  {
      if ($this->model('Paklaring_model')->rilisDataPaklaring($id) > 0) {
          Flasher::setFlash('pakrlaring', 'berhasil', 'dirilis', 'warning');
          header('Location: ' . BASEURL . '/request');
          exit;
      } else {
          Flasher::setFlash('pakrlaring', 'gagal', 'dirilis', 'secondary');
          header('Location: ' . BASEURL . '/request');
          exit;
      }
  }

  public function cetak_pdf($id)
{

    $data['req'] = $this->model('Request_model')->getAllRequest();
    $data['exit'] = $this->model('Exit_clear_model')->getExitClearLengkap($id);
        $data['app'] = $this->model('Exit_clear_model')->getApprover($_SESSION['user']['id_departemen']);
    ob_start();
    require '../app/views/paklaring/cetak_pdf.php';
    $html = ob_get_clean();

    $dompdf = new Dompdf();
    $dompdf->loadHtml($html);

    $dompdf->setPaper('A4', 'portrait');

    $dompdf->render();
    $dompdf->stream("exit_clear.pdf", ["Attachment" => false]);

}

}
