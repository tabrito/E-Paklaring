<?php
class Pemesanan extends Controller
{
  public function index()
  {
    if (!isset($_SESSION['user'])) {
        // Arahkan ke halaman login
        header('Location: ' . BASEURL . '/login');
        exit;
    }
    $data['judul'] = 'Daftar Barang';
    $data['brg'] = $this->model('Barang_model')->getAllBarang();
    $data['history'] = $this->model('Pemesanan_model')->getHistoryPemesanan();
    $data['pemasok'] = $this->model('Pemesanan_model')->getAllPemasok();
    $this->view('templates/header', $data);
    $this->view('pemesanan/index', $data);
    $this->view('templates/footer');
  }

  public function detail($id)
  {
    $data['judul'] = 'Daftar Barang';
    $data['terima'] = $this->model('Pemesanan_model')->getHistoryPenerimaanById($id);
    $data['barang'] = $this->model('Pemesanan_model')->getBarangPemesananById($id);
    $data['pemasok'] = $this->model('Pemasok_model')->getAllPemasok();
    $this->view('templates/header', $data);
    $this->view('pemesanan/detail', $data);
    $this->view('templates/footer');
  }
  
  
  public function getDetailModal() {
    $id = $_POST['id_pesan'];
    $data = $this->model('Pemesanan_model')->getBarangPemesananById($id);
    echo json_encode($data);
}


  public function tambahBarangPesanan()
{
    $idPesan = $_POST['id_pesan']; // dari session / URL

    $idBarangPesanan = $this->model('Pemesanan_model')->generateIdBarangPesanan($idPesan);

    $data = [
        'id_barang_pesanan' => $idBarangPesanan,
        'id_barang' => $_POST['id_barang'],
        'id_pesan' => $idPesan,
        'id_pemasok' => $_POST['id_pemasok'],
        'qty' => $_POST['qty'],
        'keterangan' => $_POST['keterangan']
    ];

    $result = $this->model('Pemesanan_model')->insertBarangPesanan($data);

        if ($result > 0) {
            Flasher::setFlash('Barang', 'Berhasil', 'dipesan', 'warning');
            $_SESSION['after_submit'] = true;   // ← penanda
        } else {
            Flasher::setFlash('Barang', 'Gagal', 'dipesan', 'secondary');
        }
    header('Location: ' . BASEURL . '/pemesanan/detail/' . $idPesan);
    exit;

    
}

      // Insert pesanan ke tabel
    public function tambahPesanan()
    {
        if (isset($_POST['id_barang'])) {
            $id_pesan = $_POST['id_pesan'];
            $id_barang = $_POST['id_barang'];
            $id_pemasok = $_POST['id_pemasok'];
            $harga = $_POST['harga'];
            $qty = $_POST['qty'];
            $keterangan = $_POST['keterangan'];

            $dataInsert = [];
            foreach ($id_pesan as $i => $id) {
                $dataInsert[] = [
                    'id_pesan' => $id,
                    'id_barang' => $id_barang[$i],
                    'id_pemasok' => $id_pemasok[$i],
                    'harga' => $harga[$i],
                    'qty' => $qty[$i],
                    'keterangan' => $keterangan[$i] ?? ''
                ];
            }

            $result = $this->model('Pemesanan_model')->PesanBarang($dataInsert);

            if ($result) {
                Flasher::setFlash('Barang', 'Berhasil', 'dipesan', 'warning');
                $_SESSION['after_submit'] = true;   // ← penanda
            } else {
                Flasher::setFlash('Barang', 'Gagal', 'dipesan', 'secondary');
            }
        }
        header('Location: ' . BASEURL . '/pemesanan/');
        exit;
    }

      // Insert penerimaan ke tabel
    public function tambahPenerimaan()
    {
        if (isset($_POST['id_pesan'])) {
            $id_pesan = $_POST['id_pesan'];
            $id_barang = $_POST['id_barang'];
            $harga = $_POST['harga'];
            $qty = $_POST['qty'];
            $keterangan = $_POST['keterangan'];

            $dataInsert = [];
            foreach ($id_pesan as $i => $id) {
                $dataInsert[] = [
                    'id_pesan' => $id,
                    'id_barang' => $id_barang[$i],
                    'harga' => $harga[$i],
                    'qty' => $qty[$i],
                    'keterangan' => $keterangan[$i] ?? ''
                ];
            }


            $result = $this->model('Pemesanan_model')->TerimaBarang($dataInsert);

            if ($result) {
                Flasher::setFlash('Barang', 'Berhasil', 'diterima', 'warning');
                $_SESSION['after_submit'] = true;   // ← penanda
            } else {
                Flasher::setFlash('Barang', 'Gagal', 'diterima', 'secondary');
            }
        }
        header('Location: ' . BASEURL . '/penerimaan/detail/' . $_POST['id_pesan'][0]);
        exit;
    }

    public function terimaPemesanan($id)
{
  if ($this->model('Pemesanan_model')->terimaDataPemesanan($id) > 0) {
    header('Location: ' . BASEURL . '/pemesanan');
    exit;
  } else {
    header('Location: ' . BASEURL . '/pemesanan');
    exit;
  }
}

    public function tolakPemesanan($id)
{
  if ($this->model('Pemesanan_model')->tolakDataPemesanan($id) > 0) {
    header('Location: ' . BASEURL . '/pemesanan');
    exit;
  } else {
    header('Location: ' . BASEURL . '/pemesanan');
    exit;
  }
}

    public function hapusPesanan($id)
{
  $id_barang_pesanan = substr($id, 0, -4);
  if ($this->model('Pemesanan_model')->hapusDataPesanan($id) > 0) {
    Flasher::setFlash('pemesanan', 'berhasil', 'dihapus', 'warning');
    header('Location: ' . BASEURL . '/pemesanan/detail/' . $id_barang_pesanan);
    exit;
  } else {
    Flasher::setFlash('pemesanan', 'gagal', 'dihapus', 'secondary');
    header('Location: ' . BASEURL . '/pemesanan/detail/' . $id_barang_pesanan);
    exit;
  }
}

    public function hapusPenerimaan($id)
{
  $id_barang_pesanan = substr($id, 0, -4);
  if ($this->model('Pemesanan_model')->hapusDataPenerimaan($id) > 0) {
    Flasher::setFlash('penerimaan', 'berhasil', 'dihapus', 'warning');
    header('Location: ' . BASEURL . '/pemesanan/detail/' . $id_barang_pesanan);
    exit;
  } else {
    Flasher::setFlash('penerimaan', 'gagal', 'dihapus', 'secondary');
    header('Location: ' . BASEURL . '/pemesanan/detail/' . $id_barang_pesanan);
    exit;
  }
}

    public function hapusPemesanan($id)
{
  if ($this->model('Pemesanan_model')->hapusDataPemesanan($id) > 0) {
    Flasher::setFlash('pemesanan', 'berhasil', 'dihapus', 'warning');
    header('Location: ' . BASEURL . '/pemesanan');
    exit;
  } else {
    Flasher::setFlash('pemesanan', 'gagal', 'dihapus', 'secondary');
    header('Location: ' . BASEURL . '/pemesanan');
    exit;
  }
}

public function cetakPdf($id_pesan)
{
    $data['pesanan'] = $this->model('Pemesanan_model')->getBarangPemesananById($id_pesan);
    $data['nama_kepsek'] = $this->model('Pemesanan_model')->getNamaKepsek();

    $this->view('pemesanan/cetak_pdf', $data);
}


public function getUbah()
{
  echo json_encode($this->model('Pemesanan_model')->getPemesananById($_POST['id']));
}

public function getUbahTerima()
{
  echo json_encode($this->model('Pemesanan_model')->getPenerimaanById($_POST['id']));
}

public function ubahPemesanan()
{
  if ($this->model('Pemesanan_model')->ubahDataPemesanan($_POST) > 0) {
    Flasher::setFlash('pemesanan', 'berhasil', 'diubah', 'warning');
    header('Location: ' . BASEURL . '/pemesanan');
    exit;
  } else {
    Flasher::setFlash('pemesanan', 'gagal', 'diubah', 'secondary');
    header('Location: ' . BASEURL . '/pemesanan');
    exit;
  }
}

public function ubahPenerimaan()
{
  if ($this->model('Pemesanan_model')->ubahDataPenerimaan($_POST) > 0) {
    Flasher::setFlash('penerimaan', 'berhasil', 'diubah', 'warning');
    header('Location: ' . BASEURL . '/pemesanan/detail/' . $_POST['id_pesan']);
    exit;
  } else {
    Flasher::setFlash('penerimaan', 'gagal', 'diubah', 'secondary');
    header('Location: ' . BASEURL . '/pemesanan/detail/' . $_POST['id_pesan']);
    exit;
  }
}


  public function cariBarang()
  {
    $data['judul'] = 'Daftar Barang';
    $data['brg'] = $this->model('Pemesanan_model')->cariDataBarang();
    $data['history'] = $this->model('Pemesanan_model')->getHistoryPemesanan();
    $data['pemasok'] = $this->model('Pemesanan_model')->getAllPemasok();
    $this->view('templates/header', $data);
    $this->view('pemesanan/index', $data);
    $this->view('templates/footer');
  }

    public function getPemasok()
{
    $data = $this->model('Pemesanan_model')->getAllPemasok();
    echo json_encode($data);
}

public function getPesananId()
{
    $id = $_POST['id_barang_pesanan'] ?? '';

$barang = $this->model('Pemesanan_model')->getPesananById($id);

// Debug: cek output sebenarnya
// die(var_dump($barang));

header('Content-Type: application/json');
echo json_encode($barang);
exit;

    // Pastikan header JSON
    header('Content-Type: application/json');

    // Bersihkan output buffer sebelum echo JSON
    ob_clean(); 

    echo json_encode($barang);
    exit;
}

public function getBarangId()
{
    $id = $_POST['id_barang'] ?? '';

$barang = $this->model('Pemesanan_model')->getBarangById($id);

// Debug: cek output sebenarnya
// die(var_dump($barang));

header('Content-Type: application/json');
echo json_encode($barang);
exit;

    // Pastikan header JSON
    header('Content-Type: application/json');

    // Bersihkan output buffer sebelum echo JSON
    ob_clean(); 

    echo json_encode($barang);
    exit;
}



}
