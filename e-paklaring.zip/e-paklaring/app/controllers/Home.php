<?php
class Home extends Controller
{
    public function index()
    {
        // Cek apakah user sudah login
        if (!isset($_SESSION['user'])) {
            // Arahkan ke halaman login
            header('Location: ' . BASEURL . '/login');
            exit;
        }
        
        $data['judul'] = 'Home';
        $data['pengajuan'] = $this->model('Home_model')->getAllPengajuan();
        $data['exit_clear'] = $this->model('Home_model')->getAllExitClear();
        $data['paklaring'] = $this->model('Home_model')->getAllPaklaring();
        $data['users'] = $this->model('Home_model')->getAllUsers();
        $data['karyawan'] = $this->model('Home_model')->getAllKaryawan();
        $data['approver'] = $this->model('Home_model')->getAllApprover();

        $this->view('templates/header', $data);
        $this->view('home/index', $data);
        $this->view('templates/footer');
    }
}
