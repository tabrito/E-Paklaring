<?php
class Instansi extends Controller
{
  public function index()
  {
    if (!isset($_SESSION['user'])) {
        // Arahkan ke halaman login
        header('Location: ' . BASEURL . '/login');
        exit;
    }
    $data['judul'] = 'Data Instansi';
    $data['ins'] = $this->model('Instansi_model')->getAllInstansi();
    $data['idIns'] = $this->model('Instansi_model')->generateIDInstansi();
    $data['dep'] = $this->model('Instansi_model')->getAllDepartemen();
    $this->view('templates/header', $data);
    $this->view('instansi/index', $data);
    $this->view('templates/footer');
  }

      public function tambah()
    {
        if ($this->model('Instansi_model')->tambahInstansi($_POST) > 0) {
            Flasher::setFlash('instansi', 'berhasil', 'ditambahkan', 'warning');
        } else {
            Flasher::setFlash('instansi', 'gagal', 'ditambahkan', 'secondary');
        }

        header('Location: ' . BASEURL . '/instansi');
        exit;
    }


        public function update()
    {
        if ($this->model('Instansi_model')->updateInstansi($_POST) > 0) {
            Flasher::setFlash('instansi', 'berhasil', 'diupdate', 'warning');
        } else {
            Flasher::setFlash('instansi', 'gagal', 'diupdate', 'secondary');
        }

        header('Location: ' . BASEURL . '/instansi');
        exit;
    }

    public function delete($nik)
    {
        if ($this->model('Instansi_model')->deleteInstansi($nik) > 0) {
            Flasher::setFlash('instansi', 'berhasil', 'dihapus', 'warning');
        } else {
            Flasher::setFlash('instansi', 'gagal', 'dihapus', 'secondary');
        }

        header('Location: ' . BASEURL . '/instansi');
        exit;
    }

public function addDepartemen()
{

    $id = $this->model('Instansi_model')->addDepartemen($_POST);

    echo $id; // kirim id_departemen ke fetch

}

    public function deleteDepartemen($id)
{
    $this->model('Instansi_model')->deleteDepartemen($id);
}

}
