<?php
class Approver extends Controller
{
  public function index()
  {
     if (!isset($_SESSION['user'])) {
        // Arahkan ke halaman login
        header('Location: ' . BASEURL . '/login');
        exit;
    }
    $data['judul'] = 'Data Approver';
    $data['app'] = $this->model('Approver_model')->getAllApprover();
    $data['ins'] = $this->model('Instansi_model')->getAllInstansi();
    $this->view('templates/header', $data);
    $this->view('approver/index', $data);
    $this->view('templates/footer');
  }

  public function importExcel()
{

    if (!isset($_FILES['file_excel'])) {
        header('Location: ' . BASEURL . '/approver');
        exit;
    }

    require '../vendor/autoload.php';

    $file = $_FILES['file_excel']['tmp_name'];

    $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($file);

    $rows = $spreadsheet->getActiveSheet()->toArray();

    foreach ($rows as $i => $row) {

        if ($i == 0) continue;

        $namaDept = $row[3];
        $namaInstansi = $row[4];

        // cari departemen berdasarkan dept + instansi
        $dept = $this->model('Instansi_model')
                     ->getByNamaDanInstansiNonApprover($namaDept, $namaInstansi);

        if (!$dept) continue;

        $id_dept = $dept['id_departemen'];

        $data = [
            "nik" => $row[0],
            "first_name" => $row[1],
            "last_name" => $row[2],
            "id_departemen" => $id_dept,
            "jabatan" => $row[5],
            "ttd" => NULL
        ];

        $this->model('Approver_model')
             ->tambahDataApprover($data);

    }

    header('Location: ' . BASEURL . '/approver');
}

public function downloadTemplate()
{
    $file = '../public/template/template_import_approver.xlsx';

    if (file_exists($file)) {

        header('Content-Description: File Transfer');
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="template_import_approver.xlsx"');
        header('Content-Length: ' . filesize($file));

        readfile($file);
        exit;
    }

    echo "File tidak ditemukan";
}

public function uploadTTD()
{
    if (!isset($_FILES['ttd'])) {
        header('Location: ' . BASEURL . '/approval');
        exit;
    }

    $file = $_FILES['ttd'];

    $namaFile = time() . '_' . $file['name'];
    $tmp = $file['tmp_name'];

    $path = '../public/img/ttd/' . $namaFile;

    move_uploaded_file($tmp, $path);

    // simpan ke database (contoh)
    $this->model('Approver_model')->updateTTD([
        'ttd' => $namaFile,
        'nik' => $_POST['nik']
    ]);

    header('Location: ' . BASEURL . '/approver');
}
  
      public function tambah()
    {
          // Upload TTD
        $ttd = $_FILES['ttd'];

        $namaFile = $ttd['name'];
        $tmpName  = $ttd['tmp_name'];
        $size     = $ttd['size'];

        // Ambil ekstensi
        $extValid = ['jpg','jpeg','png'];
        $ext = strtolower(pathinfo($namaFile, PATHINFO_EXTENSION));

        if (!in_array($ext, $extValid)) {
            Flasher::setFlash('Format gambar', 'harus', 'jpg/jpeg/png', 'danger');
            header('Location: ' . BASEURL . '/approver');
            exit;
        }

        if ($size > 2000000) { // 2MB
            Flasher::setFlash('Ukuran gambar', 'maksimal', '2mb', 'danger');
            header('Location: ' . BASEURL . '/approver');
            exit;
        }

        // Rename file biar unik
        $namaBaru = uniqid() . '.' . $ext;

        move_uploaded_file($tmpName, 'img/ttd/' . $namaBaru);

        // Simpan ke database
        $_POST['ttd'] = $namaBaru;

        if ($this->model('Approver_model')->tambahDataApprover($_POST) > 0) {
            Flasher::setFlash('approver', 'berhasil', 'ditambahkan', 'warning');
            header('Location: ' . BASEURL . '/approver');
            exit;
        } else {
            Flasher::setFlash('approver', 'gagal', 'ditambahkan', 'secondary');
            header('Location: ' . BASEURL . '/approver');
            exit;
        }
    }

    public function update()
    {
      if ($_FILES['ttd']) {
                // Upload TTD
        $ttd = $_FILES['ttd'];

        $namaFile = $ttd['name'];
        $tmpName  = $ttd['tmp_name'];
        $size     = $ttd['size'];

        // Ambil ekstensi
        $extValid = ['jpg','jpeg','png'];
        $ext = strtolower(pathinfo($namaFile, PATHINFO_EXTENSION));

        if (!in_array($ext, $extValid)) {
            Flasher::setFlash('Format gambar', 'harus', 'jpg/jpeg/png', 'danger');
            header('Location: ' . BASEURL . '/approver');
            exit;
        }

        if ($size > 2000000) { // 2MB
            Flasher::setFlash('Ukuran gambar', 'maksimal', '2mb', 'danger');
            header('Location: ' . BASEURL . '/approver');
            exit;
        }

        // Rename file biar unik
        $namaBaru = uniqid() . '.' . $ext;

        move_uploaded_file($tmpName, 'img/ttd/' . $namaBaru);

        // Simpan ke database
        $_POST['ttd_lama'] = $namaBaru;
      }

        if ($this->model('Approver_model')->updateData($_POST) > 0) {
            Flasher::setFlash('approver', 'berhasil', 'diupdate', 'warning');
        } else {
            Flasher::setFlash('approver', 'gagal', 'diupdate', 'secondary');
        }

        header('Location: ' . BASEURL . '/approver');
        exit;
    }

    public function getDepartemen($id_instansi)
    {
        echo json_encode(
            $this->model('Approver_model')->getDepartemenByInstansi($id_instansi)
        );
    }

        public function delete($nik)
    {
        if ($this->model('Approver_model')->deleteData($nik) > 0) {
            Flasher::setFlash('approver', 'berhasil', 'dihapus', 'warning');
        } else {
            Flasher::setFlash('approver', 'gagal', 'dihapus', 'secondary');
        }

        header('Location: ' . BASEURL . '/approver');
        exit;
    }

}
