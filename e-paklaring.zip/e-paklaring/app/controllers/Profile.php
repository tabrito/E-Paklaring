<?php
class Profile extends Controller
{
  public function index()
  {
    if (!isset($_SESSION['user'])) {
        // Arahkan ke halaman login
        header('Location: ' . BASEURL . '/login');
        exit;
    }
    $data['judul'] = 'Profile';
    $data['pro'] = $this->model('Profile_model')->getProfile();
    $this->view('templates/header', $data);
    $this->view('profile/index', $data);
    $this->view('templates/footer');
  }

    // ================================
    // TAMBAH USER
    // ================================
    public function tambah()
    {
        if ($this->model('Users_model')->tambahUser($_POST) > 0) {
            Flasher::setFlash('user', 'berhasil', 'ditambahkan', 'success');
        } else {
            Flasher::setFlash('user', 'gagal', 'ditambahkan', 'danger');
        }

        header('Location: ' . BASEURL . '/users');
        exit;
    }

    // ================================
    // UPDATE USER
    // ================================
    public function update()
    {
        if ($this->model('Users_model')->updateUser($_POST) > 0) {
            Flasher::setFlash('user', 'berhasil', 'diupdate', 'success');
        } else {
            Flasher::setFlash('user', 'gagal', 'diupdate', 'danger');
        }

        header('Location: ' . BASEURL . '/users');
        exit;
    }

}
