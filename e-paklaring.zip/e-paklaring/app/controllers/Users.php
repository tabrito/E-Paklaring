<?php
class Users extends Controller
{
  public function index()
  {
    if (!isset($_SESSION['user'])) {
        // Arahkan ke halaman login
        header('Location: ' . BASEURL . '/login');
        exit;
    }
    $data['judul'] = 'Data Users';
    $data['user'] = $this->model('Users_model')->getAllUsers();
    $data['kar'] = $this->model('Users_model')->getKaryawanNonUser();
    $data['app'] = $this->model('Users_model')->getApproverNonUser();
    $this->view('templates/header', $data);
    $this->view('users/index', $data);
    $this->view('templates/footer');
  }

    // ================================
    // TAMBAH USER
    // ================================
    public function tambah()
    {
        if ($this->model('Users_model')->tambahUser($_POST) > 0) {
            Flasher::setFlash('user', 'berhasil', 'ditambahkan', 'warning');
        } else {
            Flasher::setFlash('user', 'gagal', 'ditambahkan', 'secondary');
        }

        header('Location: ' . BASEURL . '/users');
        exit;
    }

    // ================================
    // UPDATE USER
    // ================================
    public function update()
    {
        if ($this->model('Users_model')->updateUser($_POST) > 0) {
            Flasher::setFlash('user', 'berhasil', 'diupdate', 'warning');
        } else {
            Flasher::setFlash('user', 'gagal', 'diupdate', 'secondary');
        }

        header('Location: ' . BASEURL . '/users');
        exit;
    }

        public function changePassword()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . BASEURL . '/profile');
            exit;
        }

        $id_user = $_SESSION['user']['id_user']; // sesuaikan dengan session kamu
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];

        // Validasi confirm password
        if ($new_password !== $confirm_password) {
            Flasher::setFlash('Password baru','tidak','sama!', 'secondary');
            header('Location: ' . BASEURL . '/profile');
            exit;
        }

        // Ambil user berdasarkan ID
        $user = $this->model('Users_model')->getUserById($id_user);

        // Cek password lama
        if (!password_verify($current_password, $user['password'])) {
            Flasher::setFlash('Password lama','tidak','benar!', 'secondary');
            header('Location: ' . BASEURL . '/profile');
            exit;
        }

        // Hash password baru
        $newPasswordHash = password_hash($new_password, PASSWORD_DEFAULT);

        // Update password
        if ($this->model('Users_model')->updatePassword($id_user, $newPasswordHash) > 0) {
            Flasher::setFlash('Password','berhasil','diubah!', 'warning');
        } else {
            Flasher::setFlash('Password','gagal','diubah!', 'secondary');
        }

        header('Location: ' . BASEURL . '/profile');
        exit;
    }

}
