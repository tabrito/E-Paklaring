<?php
require_once '../vendor/autoload.php';
use Dompdf\Dompdf;
class Approval extends Controller
{
  public function index()
  {
        if (!isset($_SESSION['user'])) {
        // Arahkan ke halaman login
        header('Location: ' . BASEURL . '/login');
        exit;
    }
    $data['judul'] = 'Approval';
    if($_SESSION['user']['role'] == 'HRD' OR $_SESSION['user']['role'] == 'Superadmin') {
    $data['req'] = $this->model('Approval_model')->getAllRequest();
    } elseif ($_SESSION['user']['role'] == 'Supervisor') {
    $data['req'] = $this->model('Approval_model')->getRequestByDept($_SESSION['user']['id_departemen']);
    }
    $this->view('templates/header', $data);
    $this->view('approval/index', $data);
    $this->view('templates/footer');
  }

  public function detail($id)
  {
    $data['judul'] = 'Approval';
    $data['exi'] = $this->model('Approval_model')->getExitClear($id);
    $data['stat'] = $this->model('Approval_model')->getStatusApproval($id);
    $this->view('templates/header', $data);
    $this->view('approval/detail', $data);
    $this->view('templates/footer');
  }

  public function cetak_pdf($id, $dept)
{

    $data['req'] = $this->model('Request_model')->getAllRequest();
    $data['exit'] = $this->model('Exit_clear_model')->getExitClearLengkap($id);
        $data['app'] = $this->model('Exit_clear_model')->getApprover($dept);
    ob_start();
    require '../app/views/exit_clear/cetak_pdf.php';
    $html = ob_get_clean();

    $dompdf = new Dompdf();
    $dompdf->loadHtml($html);

    $dompdf->setPaper('A4', 'portrait');

    $dompdf->render();
    $dompdf->stream("exit_clear.pdf", ["Attachment" => false]);

}

  
    public function approveHRD($id)
    {
        $this->model('Approval_model')
             ->updateHRD($id, 'Approved');

        header('Location: ' . BASEURL . '/approval');
        exit;
    }


    public function rejectHRD($id)
    {
        $this->model('Approval_model')
             ->updateHRD($id, 'Rejected');

        header('Location: ' . BASEURL . '/approval');
        exit;
    }


    public function approveSPV($id)
    {
        $this->model('Approval_model')
             ->updateSPV($id, 'Approved');

        header('Location: ' . BASEURL . '/approval');
        exit;
    }


    public function rejectSPV($id)
    {
        $this->model('Approval_model')
             ->updateSPV($id, 'Rejected');

        header('Location: ' . BASEURL . '/approval');
        exit;
    }

}
