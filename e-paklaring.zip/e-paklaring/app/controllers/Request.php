<?php
class Request extends Controller
{
  public function index()
  {
    if (!isset($_SESSION['user'])) {
        // Arahkan ke halaman login
        header('Location: ' . BASEURL . '/login');
        exit;
    }
    $data['judul'] = 'Request';
    if($_SESSION['user']['role'] == 'HRD' OR $_SESSION['user']['role'] == 'Superadmin') {
      $data['req'] = $this->model('Request_model')->getAllRequest();
    } elseif ($_SESSION['user']['role'] == 'Supervisor') {
      $data['req'] = $this->model('Request_model')->getRequestByDept($_SESSION['user']['id_departemen']);
    } elseif ($_SESSION['user']['role'] == 'Karyawan') {
      $data['req'] = $this->model('Request_model')->getRequestByKaryawan($_SESSION['user']['nik']);
    }
      $this->view('templates/header', $data);
    $this->view('request/index', $data);
    $this->view('templates/footer');
  }

  public function search()
{

    $data['judul'] = 'Request';

    $keyword = $_POST['keyword'];

    $data['req'] = $this->model('Request_model')->searchAllRequest($keyword);

    $this->view('templates/header', $data);
    $this->view('request/index', $data);
    $this->view('templates/footer');
}

  public function tambah()
  {
      if ($this->model('Request_model')->tambahDataRequest($_POST) > 0) {
          Flasher::setFlash('request', 'berhasil', 'ditambahkan', 'warning');
          header('Location: ' . BASEURL . '/request');
          exit;
      } else {
          Flasher::setFlash('request', 'gagal', 'ditambahkan', 'secondary');
          header('Location: ' . BASEURL . '/request');
          exit;
      }
  }

}
