<?php

class Controller
{
  public function login() {
    if($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $userModel = $this->model('User_model');
        $user = $userModel->login($username, $password);

        if($user) {
            session_start();
            $_SESSION['user'] = $user;
            header("Location: index.php?controller=auth&action=dashboard");
        } else {
            $data['error'] = "Username atau password salah";
            $this->view('auth/login', $data);
        }
    } else {
        $this->view('auth/login');
    }
  }
  public function view($view, $data = [])
  {
    require_once '../app/views/' . $view . '.php';
  }

  public function model($model)
  {
    require_once '../app/models/' . $model . '.php';
    return new $model;
  }
}
