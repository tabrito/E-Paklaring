<?php
class Karyawan_model
{
  private $table = 'karyawan';
  private $db;

  public function __construct()
  {
    $this->db = new Database;
  }
    public function getAllKaryawan()
  {
$this->db->query("SELECT 
    k.*,
    u.status,
    d.departemen,
    i.*
FROM karyawan k
LEFT JOIN users u 
    ON k.id_user = u.id_user
LEFT JOIN departemen d 
    ON k.id_departemen = d.id_departemen
LEFT JOIN instansi i 
    ON d.id_instansi = i.id_instansi
ORDER BY u.status, k.first_name;");
    return $this->db->resultSet();
  }

  
    public function tambahDataKaryawan($data)
    {
        $query = "INSERT INTO karyawan 
                    (nik, 
                     id_user,
                     first_name, 
                     last_name, 
                     jenis_kelamin, 
                     tempat_lahir, 
                     tanggal_lahir, 
                     tanggal_masuk, 
                     id_departemen, 
                     jabatan, 
                     tanggal_resign, 
                     tanggal_keluar)
                  VALUES
                    (:nik,
                     :id_user,
                     :first_name,
                     :last_name,
                     :jenis_kelamin,
                     :tempat_lahir,
                     :tanggal_lahir,
                     :tanggal_masuk,
                     :id_departemen,
                     :jabatan,
                     :tanggal_resign,
                     :tanggal_keluar)";

        $this->db->query($query);

        $this->db->bind('nik', $data['nik']);
        $this->db->bind('id_user', 'U-0000');
        $this->db->bind('first_name', $data['first_name']);
        $this->db->bind('last_name', $data['last_name']);
        $this->db->bind('jenis_kelamin', $data['jenis_kelamin']);
        $this->db->bind('tempat_lahir', $data['tempat_lahir']);
        $this->db->bind('tanggal_lahir', $data['tanggal_lahir']);
        $this->db->bind('tanggal_masuk', $data['tanggal_masuk']);
        $this->db->bind('id_departemen', $data['id_departemen']);
        $this->db->bind('jabatan', $data['jabatan']);

        // Optional field (boleh NULL)
        $this->db->bind('tanggal_resign', 
            !empty($data['tanggal_resign']) ? $data['tanggal_resign'] : null
        );

        $this->db->bind('tanggal_keluar', 
            !empty($data['tanggal_keluar']) ? $data['tanggal_keluar'] : null
        );

        $this->db->execute();

        return $this->db->rowCount();
    }

    public function getDepartemenByInstansi($id_instansi)
    {
        $this->db->query("SELECT * FROM departemen WHERE id_instansi = :id_instansi");
        $this->db->bind('id_instansi', $id_instansi);
        return $this->db->resultSet();
    }

    public function updateData($data)
    {
        $query = "UPDATE karyawan SET
                    nik = :nik,
                    first_name = :first_name,
                    last_name = :last_name,
                    jenis_kelamin = :jenis_kelamin,
                    tempat_lahir = :tempat_lahir,
                    tanggal_lahir = :tanggal_lahir,
                    tanggal_masuk = :tanggal_masuk,
                    id_departemen = :id_departemen,
                    jabatan = :jabatan,
                    tanggal_resign = :tanggal_resign,
                    tanggal_keluar = :tanggal_keluar
                  WHERE nik = :nik_lama";

        $this->db->query($query);

        foreach ($data as $key => $value) {
            $this->db->bind($key, $value);
        }

        $this->db->execute();

        return $this->db->rowCount();
    }

        public function deleteData($nik)
    {
        $this->db->query("DELETE FROM karyawan WHERE nik = :nik");
        $this->db->bind('nik', $nik);
        $this->db->execute();

        return $this->db->rowCount();
    }
}
