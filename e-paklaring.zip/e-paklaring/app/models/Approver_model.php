<?php
class Approver_model
{
  private $table = 'karyawan';
  private $db;

  public function __construct()
  {
    $this->db = new Database;
  }
    public function getAllApprover()
  {
$this->db->query("SELECT 
    a.*,
    u.status,
    d.departemen,
    i.*
FROM approver a
LEFT JOIN users u 
    ON a.id_user = u.id_user
LEFT JOIN departemen d 
    ON a.id_departemen = d.id_departemen
LEFT JOIN instansi i 
    ON d.id_instansi = i.id_instansi
ORDER BY u.status, a.jabatan, a.first_name;");
    return $this->db->resultSet();
  }

      public function tambahDataApprover($data)
    {
        $query = "INSERT INTO approver 
                    (nik, 
                     id_user,
                     first_name, 
                     last_name, 
                     id_departemen, 
                     jabatan,
                     ttd)
                  VALUES
                    (:nik,
                     :id_user,
                     :first_name,
                     :last_name,
                     :id_departemen,
                     :jabatan,
                     :ttd)";

        $this->db->query($query);

        $this->db->bind('nik', $data['nik']);
        $this->db->bind('id_user', 'U-0000');
        $this->db->bind('first_name', $data['first_name']);
        $this->db->bind('last_name', $data['last_name']);
        $this->db->bind('id_departemen', $data['id_departemen']);
        $this->db->bind('jabatan', $data['jabatan']);
        $this->db->bind('ttd', $data['ttd']);

        $this->db->execute();

        return $this->db->rowCount();
    }

    public function updateTTD($data)
{
    $query = "
        UPDATE approver 
        SET ttd = :ttd
        WHERE nik = :nik
    ";

    $this->db->query($query);
    $this->db->bind('ttd', $data['ttd']);
    $this->db->bind('nik', $data['nik']);

    return $this->db->execute();
}

    public function getDepartemenByInstansi($id_instansi)
    {
        $this->db->query("SELECT *, d.id_departemen as id_departemen
FROM departemen d
LEFT JOIN approver a 
  ON d.id_departemen = a.id_departemen
WHERE d.id_instansi = :id_instansi
AND a.nik IS NULL");
        $this->db->bind('id_instansi', $id_instansi);
        return $this->db->resultSet();
    }

    public function updateData($data)
    {
        $query = "UPDATE approver SET
                    nik = :nik,
                    first_name = :first_name,
                    last_name = :last_name,
                    id_departemen = :id_departemen,
                    jabatan = :jabatan,
                    ttd = :ttd_lama
                  WHERE nik = :nik_lama";

        $this->db->query($query);

        foreach ($data as $key => $value) {
            $this->db->bind($key, $value);
        }

        $this->db->execute();

        return $this->db->rowCount();
    }

        public function deleteData($nik)
    {
        $this->db->query("DELETE FROM approver WHERE nik = :nik");
        $this->db->bind('nik', $nik);
        $this->db->execute();

        return $this->db->rowCount();
    }

}
