<?php
class Exit_clear_model
{
  private $table = 'pengajuan';
  private $db;

  public function __construct()
  {
    $this->db = new Database;
  }

public function getExitClear($id)
{
    $this->db->query("SELECT *, ec.id_exit_clear as id_exit
        FROM exit_clear ec
        LEFT JOIN pengajuan p 
            ON ec.id_pengajuan = p.id_pengajuan
        LEFT JOIN karyawan k 
            ON p.nik = k.nik
        LEFT JOIN aset a
            ON ec.id_exit_clear = a.id_exit_clear
        LEFT JOIN interview iv
            ON ec.id_exit_clear = iv.id_exit_clear
        LEFT JOIN administrasi ad
            ON ec.id_exit_clear = ad.id_exit_clear
        WHERE p.nik = :nik;");

    $this->db->bind('nik', $id);
    return $this->db->single();
}

public function getExitClearLengkap($id)
{
    $this->db->query("SELECT *, ec.id_exit_clear as id_exit, p.tanggal as tanggal_pengajuan, pk.tanggal as tanggal_paklaring
        FROM exit_clear ec
        LEFT JOIN pengajuan p 
            ON ec.id_pengajuan = p.id_pengajuan
        LEFT JOIN karyawan k 
            ON p.nik = k.nik
        LEFT JOIN aset a
            ON ec.id_exit_clear = a.id_exit_clear
        LEFT JOIN interview iv
            ON ec.id_exit_clear = iv.id_exit_clear
        LEFT JOIN administrasi ad
            ON ec.id_exit_clear = ad.id_exit_clear
        LEFT JOIN departemen dep
            ON k.id_departemen = dep.id_departemen
        LEFT JOIN instansi ins
            ON dep.id_instansi = ins.id_instansi
        LEFT JOIN paklaring pk
            ON p.id_pengajuan = pk.id_pengajuan
        WHERE p.nik = :nik;");

    $this->db->bind('nik', $id);
    return $this->db->single();
}

    public function getApprover($id)
  {
$this->db->query("SELECT 
    *
FROM approver a
LEFT JOIN users u 
    ON a.id_user = u.id_user
LEFT JOIN departemen d 
    ON a.id_departemen = d.id_departemen
LEFT JOIN instansi i 
    ON d.id_instansi = i.id_instansi
WHERE a.id_departemen = :id 
   OR d.departemen = 'HRD'
ORDER BY a.jabatan");

    $this->db->bind('id', $id);
    return $this->db->resultSet();
  }

      public function generateIDInterview()
{
    $this->db->query("SELECT id_interview 
                      FROM interview 
                      ORDER BY id_interview DESC 
                      LIMIT 1");

    $last = $this->db->single();

    if (!$last) {
        return 'IV-0001';
    }

    $lastNumber = (int) substr($last['id_interview'], 3);
    $newNumber  = $lastNumber + 1;

    return 'IV-' . str_pad($newNumber, 4, '0', STR_PAD_LEFT);
}

  public function tambahDataInterview($data)
  {
      $idInterview = $this->generateIDInterview();

      $query1 = "INSERT INTO interview
                (id_interview, id_exit_clear, alasan, kepuasan, apresiasi, saran)
                VALUES
                (:id_interview, :id_exit_clear, :alasan, :kepuasan, :apresiasi, :saran)";

      $this->db->query($query1);
      $this->db->bind('id_interview', $idInterview);
      $this->db->bind('id_exit_clear', $data['id_exit_clear']);
      $this->db->bind('alasan', $data['alasan']);
      $this->db->bind('kepuasan', $data['kepuasan']);
      $this->db->bind('apresiasi', $data['apresiasi']);
      $this->db->bind('saran', $data['saran']);
      $this->db->execute();
      
      return $this->db->rowCount();

  }

      public function generateIDAset()
{
    $this->db->query("SELECT id_aset 
                      FROM aset 
                      ORDER BY id_aset DESC 
                      LIMIT 1");

    $last = $this->db->single();

    if (!$last) {
        return 'AS-0001';
    }

    $lastNumber = (int) substr($last['id_aset'], 3);
    $newNumber  = $lastNumber + 1;

    return 'AS-' . str_pad($newNumber, 4, '0', STR_PAD_LEFT);
}

  public function tambahDataAset($data)
  {
      $idAset = $this->generateIDAset();

      $query1 = "INSERT INTO aset
                (id_aset, id_exit_clear, id_card, laptop, seragam, file_kerja)
                VALUES
                (:id_aset, :id_exit_clear, :id_card, :laptop, :seragam, :file_kerja)";

      $this->db->query($query1);
      $this->db->bind('id_aset', $idAset);
      $this->db->bind('id_exit_clear', $data['id_exit_clear']);
      $this->db->bind('id_card', $data['idcard']);
      $this->db->bind('laptop', $data['laptop']);
      $this->db->bind('seragam', $data['seragam']);
      $this->db->bind('file_kerja', $data['serah']);
      $this->db->execute();
      
      return $this->db->rowCount();

  }

      public function generateIDAdmin()
{
    $this->db->query("SELECT id_administrasi 
                      FROM administrasi 
                      ORDER BY id_administrasi DESC 
                      LIMIT 1");

    $last = $this->db->single();

    if (!$last) {
        return 'ADM-0001';
    }

    $lastNumber = (int) substr($last['id_administrasi'], 4);
    $newNumber  = $lastNumber + 1;

    return 'ADM-' . str_pad($newNumber, 4, '0', STR_PAD_LEFT);
}

  public function tambahDataAdmin($data)
  {
      $idAdmin = $this->generateIDAdmin();

      $query1 = "INSERT INTO administrasi
                (id_administrasi, id_exit_clear, gaji_terakhir, sisa_cuti)
                VALUES
                (:id_administrasi, :id_exit_clear, :gaji_terakhir, :sisa_cuti)";

      $this->db->query($query1);
      $this->db->bind('id_administrasi', $idAdmin);
      $this->db->bind('id_exit_clear', $data['id_exit_clear']);
      $this->db->bind('gaji_terakhir', $data['gaji']);
      $this->db->bind('sisa_cuti', $data['cuti']);
      $this->db->execute();
      
      return $this->db->rowCount();

  }

  public function ubahDataInterview($data)
  {
    $query1 = "UPDATE interview SET
                alasan = :alasan,
                kepuasan = :kepuasan,
                apresiasi = :apresiasi,
                saran = :saran
                WHERE id_interview = :id_interview";

      $this->db->query($query1);
      $this->db->bind('alasan', $data['alasan']);
      $this->db->bind('kepuasan', $data['kepuasan']);
      $this->db->bind('apresiasi', $data['apresiasi']);
      $this->db->bind('saran', $data['saran']);
      $this->db->bind('id_interview', $data['id_interview']);
      $this->db->execute();
      
      return $this->db->rowCount();

  }

  public function ubahDataAset($data)
  {
    $query1 = "UPDATE aset SET
                id_card = :id_card,
                laptop = :laptop,
                seragam = :seragam,
                file_kerja = :file_kerja
                WHERE id_aset = :id_aset";

      $this->db->query($query1);
      $this->db->bind('id_card', $data['idcard']);
      $this->db->bind('laptop', $data['laptop']);
      $this->db->bind('seragam', $data['seragam']);
      $this->db->bind('file_kerja', $data['serah']);
      $this->db->bind('id_aset', $data['id_aset']);
      $this->db->execute();
      
      return $this->db->rowCount();

  }

  public function ubahDataAdmin($data)
  {
    $query1 = "UPDATE administrasi SET
                gaji_terakhir = :gaji_terakhir,
                sisa_cuti = :sisa_cuti
                WHERE id_administrasi = :id_administrasi";

      $this->db->query($query1);
      $this->db->bind('gaji_terakhir', $data['gaji']);
      $this->db->bind('sisa_cuti', $data['cuti']);
      $this->db->bind('id_administrasi', $data['id_administrasi']);
      $this->db->execute();
      
      return $this->db->rowCount();

  }

    public function resetDataInterview($id)
    {
        $this->db->query("DELETE FROM interview WHERE id_interview = :id_interview");
        $this->db->bind('id_interview', $id);
        $this->db->execute();

        return $this->db->rowCount();
    }

    public function resetDataAset($id)
    {
        $this->db->query("DELETE FROM aset WHERE id_aset = :id_aset");
        $this->db->bind('id_aset', $id);
        $this->db->execute();

        return $this->db->rowCount();
    }

    public function resetDataAdmin($id)
    {
        $this->db->query("DELETE FROM administrasi WHERE id_administrasi = :id_administrasi");
        $this->db->bind('id_administrasi', $id);
        $this->db->execute();

        return $this->db->rowCount();
    }

}
