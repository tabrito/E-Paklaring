<?php
class Request_model
{
  private $table = 'pengajuan';
  private $db;

  public function __construct()
  {
    $this->db = new Database;
  }
  public function getAllRequest()
  {
    $this->db->query("SELECT *, p.tanggal as tanggal_pengajuan
        FROM pengajuan p
        JOIN karyawan k 
            ON p.nik = k.nik
        JOIN departemen d 
            ON k.id_departemen = d.id_departemen
        JOIN instansi i 
            ON d.id_instansi = i.id_instansi
        LEFT JOIN paklaring pr
            ON p.id_pengajuan = pr.id_pengajuan
        Left JOIN exit_clear ec
            ON p.id_pengajuan = ec.id_pengajuan
        Left JOIN aset ae
            ON ec.id_exit_clear = ae.id_exit_clear
        Left JOIN interview it
            ON ec.id_exit_clear = it.id_exit_clear
        Left JOIN administrasi ad
            ON ec.id_exit_clear = ad.id_exit_clear
        ORDER BY p.tanggal
            ;");
        return $this->db->resultSet();
  }

  public function searchAllRequest($keyword)
{
    $this->db->query("
        SELECT 
            *,
            p.tanggal AS tanggal_pengajuan

        FROM pengajuan p

        JOIN karyawan k 
            ON p.nik = k.nik

        JOIN departemen d 
            ON k.id_departemen = d.id_departemen

        JOIN instansi i 
            ON d.id_instansi = i.id_instansi

        LEFT JOIN paklaring pr
            ON p.id_pengajuan = pr.id_pengajuan

        LEFT JOIN exit_clear ec
            ON p.id_pengajuan = ec.id_pengajuan

        LEFT JOIN aset ae
            ON ec.id_exit_clear = ae.id_exit_clear

        LEFT JOIN interview it
            ON ec.id_exit_clear = it.id_exit_clear

        LEFT JOIN administrasi ad
            ON ec.id_exit_clear = ad.id_exit_clear

        WHERE
            k.first_name LIKE :keyword
            OR k.last_name LIKE :keyword

        ORDER BY p.tanggal DESC
    ");

    $this->db->bind('keyword', "%$keyword%");

    return $this->db->resultSet();
}

      public function generateIDRequest()
{
    $this->db->query("SELECT id_pengajuan 
                      FROM pengajuan 
                      ORDER BY id_pengajuan DESC 
                      LIMIT 1");

    $last = $this->db->single();

    if (!$last) {
        return 'P-0001';
    }

    $lastNumber = (int) substr($last['id_pengajuan'], 2);
    $newNumber  = $lastNumber + 1;

    return 'P-' . str_pad($newNumber, 4, '0', STR_PAD_LEFT);
}

      public function generateIDExitClear()
{
    $this->db->query("SELECT id_exit_clear 
                      FROM exit_clear 
                      ORDER BY id_exit_clear DESC 
                      LIMIT 1");

    $last = $this->db->single();

    if (!$last) {
        return 'EC-0001';
    }

    $lastNumber = (int) substr($last['id_exit_clear'], 3);
    $newNumber  = $lastNumber + 1;

    return 'EC-' . str_pad($newNumber, 4, '0', STR_PAD_LEFT);
}

      public function getIDApprovalHR()
{
    $this->db->query("SELECT nik 
                      FROM approver a
                      JOIN users u
                        ON a.id_user = u.id_user
                      WHERE u.role = :role");
    
    $this->db->bind('role', 'HRD');
    return $this->db->single();
}

      public function getIDApprovalSPV()
{
    $this->db->query("SELECT nik 
                      FROM approver a
                      JOIN users u
                        ON a.id_user = u.id_user
                      WHERE u.role = :role AND a.id_departemen = :id_departemen");
    
    $this->db->bind('role', 'Supervisor');
    $this->db->bind('id_departemen', $_SESSION['user']['id_departemen']);
    return $this->db->single();
}

  public function tambahDataRequest($data)
  {
      $idRequest = $this->generateIDRequest();

      $query1 = "INSERT INTO pengajuan
                (id_pengajuan, nik, tanggal, status)
                VALUES
                (:id_pengajuan, :nik, :tanggal, :status)";

      $this->db->query($query1);
      $this->db->bind('id_pengajuan', $idRequest);
      $this->db->bind('nik', $_SESSION['user']['nik']);
      $this->db->bind('tanggal', date('Y-m-d'));
      $this->db->bind('status', 'Proses');
      $this->db->execute();

      $idExitClear = $this->generateIDExitClear();
      $id_approval_hr = $this->getIDApprovalHR();
      $id_approval_spv = $this->getIDApprovalSPV();

      $query2 = "INSERT INTO exit_clear
                (id_exit_clear, id_pengajuan, id_approver_hr, id_approver_spv)
                VALUES
                (:id_exit_clear, :id_pengajuan, :id_approver_hr, :id_approver_spv)";

      $this->db->query($query2);
      $this->db->bind('id_exit_clear', $idExitClear);
      $this->db->bind('id_pengajuan', $idRequest);
      $this->db->bind('id_approver_hr', $id_approval_hr['nik']);
      $this->db->bind('id_approver_spv', $id_approval_spv['nik']);
      $this->db->execute();
      
      return $this->db->rowCount();

  }

  public function getRequestByDept($id)
  {
      $this->db->query("SELECT *, p.tanggal as tanggal_pengajuan
          FROM pengajuan p
          JOIN karyawan k 
              ON p.nik = k.nik
          JOIN departemen d 
              ON k.id_departemen = d.id_departemen
          JOIN instansi i 
              ON d.id_instansi = i.id_instansi
          LEFT JOIN paklaring pr
              ON p.id_pengajuan = pr.id_pengajuan
          LEFT JOIN exit_clear ec
              ON p.id_pengajuan = ec.id_pengajuan
          LEFT JOIN aset ae
              ON ec.id_exit_clear = ae.id_exit_clear
          LEFT JOIN interview it
              ON ec.id_exit_clear = it.id_exit_clear
          LEFT JOIN administrasi ad
              ON ec.id_exit_clear = ad.id_exit_clear
          WHERE k.id_departemen = :id
          ORDER BY p.tanggal;");
          
          $this->db->bind('id', $id);
          return $this->db->resultSet();
  }

  public function getRequestByKaryawan($id)
  {
      $this->db->query("SELECT *, p.tanggal as tanggal_pengajuan
          FROM pengajuan p
          JOIN karyawan k 
              ON p.nik = k.nik
          JOIN departemen d 
              ON k.id_departemen = d.id_departemen
          JOIN instansi i 
              ON d.id_instansi = i.id_instansi
          LEFT JOIN paklaring pr
              ON p.id_pengajuan = pr.id_pengajuan
          LEFT JOIN exit_clear ec
              ON p.id_pengajuan = ec.id_pengajuan
          LEFT JOIN aset ae
              ON ec.id_exit_clear = ae.id_exit_clear
          LEFT JOIN interview it
              ON ec.id_exit_clear = it.id_exit_clear
          LEFT JOIN administrasi ad
              ON ec.id_exit_clear = ad.id_exit_clear
          WHERE p.nik = :nik
          ORDER BY p.tanggal;");
          
          $this->db->bind('nik', $id);
          return $this->db->resultSet();
  }

  public function getAsetByKaryawan($id)
  {
      $this->db->query("SELECT *
          FROM aset a
          JOIN exit_clear ec
              ON a.id_exit_clear = ec.id_exit_clear
          JOIN pengajuan p
              ON ec.id_pengajuan = p.id_pengajuan
          JOIN karyawan k 
              ON p.nik = k.nik
          WHERE p.nik = :nik;");
          
          $this->db->bind('nik', $id);
          return $this->db->resultSet();
  }

}
