<?php
class Approval_model
{
  private $table = 'pengajuan';
  private $db;

  public function __construct()
  {
    $this->db = new Database;
  }
    public function getAllRequest()
  {
$this->db->query("SELECT *
                    FROM pengajuan p
                    JOIN karyawan k 
                        ON p.nik = k.nik

                    JOIN exit_clear ec 
                        ON p.id_pengajuan = ec.id_pengajuan

                    JOIN departemen d 
                        ON k.id_departemen = d.id_departemen

                    JOIN instansi i 
                        ON d.id_instansi = i.id_instansi

                    JOIN aset a
                        ON a.id_exit_clear = ec.id_exit_clear

                    JOIN interview iv
                        ON iv.id_exit_clear = ec.id_exit_clear

                    JOIN administrasi ad
                        ON ad.id_exit_clear = ec.id_exit_clear

                    GROUP BY ec.id_exit_clear;");
    return $this->db->resultSet();
  }

    public function getRequestByDept($id)
  {
$this->db->query("SELECT *
                    FROM pengajuan p
                    JOIN karyawan k 
                        ON p.nik = k.nik

                    JOIN exit_clear ec 
                        ON p.id_pengajuan = ec.id_pengajuan

                    JOIN departemen d 
                        ON k.id_departemen = d.id_departemen

                    JOIN instansi i 
                        ON d.id_instansi = i.id_instansi

                    JOIN aset a
                        ON a.id_exit_clear = ec.id_exit_clear

                    JOIN interview iv
                        ON iv.id_exit_clear = ec.id_exit_clear

                    JOIN administrasi ad
                        ON ad.id_exit_clear = ec.id_exit_clear

                    WHERE k.id_departemen = :id

                    GROUP BY ec.id_exit_clear;");
    $this->db->bind('id', $id);
    return $this->db->resultSet();
  }

    public function getStatusApproval($id)
  {
$this->db->query("SELECT *
                    FROM pengajuan p
                    JOIN karyawan k 
                        ON p.nik = k.nik

                    JOIN exit_clear ec 
                        ON p.id_pengajuan = ec.id_pengajuan

                    WHERE p.id_pengajuan = :id;");
    $this->db->bind('id', $id);
    return $this->db->single();
  }

public function getExitClear($id)
{
    $this->db->query("SELECT *
        FROM exit_clear ec
        JOIN pengajuan p 
            ON ec.id_pengajuan = p.id_pengajuan
        JOIN karyawan k 
            ON p.nik = k.nik
        JOIN aset a
            ON ec.id_exit_clear = a.id_exit_clear
        JOIN interview iv
            ON ec.id_exit_clear = iv.id_exit_clear
        JOIN administrasi ad
            ON ec.id_exit_clear = ad.id_exit_clear
        WHERE ec.id_pengajuan = :id");

    $this->db->bind('id', $id);

    return $this->db->single();
}

public function updateHRD($id, $status)
{
    $this->db->query("
        UPDATE exit_clear
        SET approval_hr = :status
        WHERE id_exit_clear = :id
    ");

    $this->db->bind('status', $status);
    $this->db->bind('id', $id);

    $this->db->execute();
}

public function updateSPV($id, $status)
{
    $this->db->query("
        UPDATE exit_clear
        SET approval_spv = :status
        WHERE id_exit_clear = :id
    ");

    $this->db->bind('status', $status);
    $this->db->bind('id', $id);

    $this->db->execute();
}

}
