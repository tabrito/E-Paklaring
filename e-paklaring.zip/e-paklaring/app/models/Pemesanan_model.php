<?php
class Pemesanan_model
{
  private $table = 'master_barang';
  private $db;

  public function __construct()
  {
    $this->db = new Database;
  }
  public function getAllBarang()
  {
$this->db->query("SELECT *
    FROM master_barang");
    return $this->db->resultSet();
  }

public function generateIdBarangPesanan($idPesan)
{
    $this->db->query("
        SELECT id_barang_pesanan 
        FROM barang_pesanan 
        WHERE id_barang_pesanan LIKE :pattern
        ORDER BY id_barang_pesanan DESC
        LIMIT 1
    ");

    $this->db->bind('pattern', $idPesan . '-%');
    $last = $this->db->single();

    if ($last) {
        // Ambil 3 digit terakhir
        $lastNum = (int)substr($last['id_barang_pesanan'], -3);
        $newNum = $lastNum + 1;
    } else {
        $newNum = 1;
    }

    return $idPesan . '-' . str_pad($newNum, 3, '0', STR_PAD_LEFT);
}

public function insertBarangPesanan($data)
{
    $query = "
        INSERT INTO barang_pesanan 
        (id_barang_pesanan, id_barang, id_pesan, id_pemasok, qty, keterangan)
        VALUES 
        (:id_barang_pesanan, :id_barang, :id_pesan, :id_pemasok, :qty, :keterangan)
    ";

    $this->db->query($query);

    $this->db->bind('id_barang_pesanan', $data['id_barang_pesanan']);
    $this->db->bind('id_barang', $data['id_barang']);
    $this->db->bind('id_pesan', $data['id_pesan']);
    $this->db->bind('id_pemasok', $data['id_pemasok']);
    $this->db->bind('qty', $data['qty']);
    $this->db->bind('keterangan', $data['keterangan']);

    $this->db->execute();

    return $this->db->rowCount();}



public function terimaDataPemesanan($id)
{
    $query = "UPDATE pemesanan SET
                disetujui    = 'Diterima'
              WHERE id_pesan  = :id_pesan";
    $this->db->query($query);
    $this->db->bind('id_pesan', $id);

    $this->db->execute();

    return $this->db->rowCount();
}

public function tolakDataPemesanan($id)
{
    $query = "UPDATE pemesanan SET
                disetujui    = 'Ditolak'
              WHERE id_pesan  = :id_pesan";
    $this->db->query($query);
    $this->db->bind('id_pesan', $id);

    $this->db->execute();

    return $this->db->rowCount();
}

public function hapusDataPesanan($id)
{
    $query = "DELETE FROM barang_pesanan WHERE id_barang_pesanan = :id_barang_pesanan";
    $this->db->query($query);
    $this->db->bind('id_barang_pesanan', $id);

    $this->db->execute();

    return $this->db->rowCount();
}

public function hapusDataPenerimaan($id)
{
    // 1. Ambil data barang & qty yang akan dihapus
    $this->db->query("SELECT id_barang, qty 
                      FROM barang_terima 
                      WHERE id_barang_terima = :id");
    $this->db->bind('id', $id);
    $data = $this->db->single();

    if (!$data) {
        return 0;
    }

    $id_barang = $data['id_barang'];
    $qty       = $data['qty'];

    // 2. Kurangi stok di master_barang
    $this->db->query("UPDATE master_barang 
                      SET stok = stok - :qty ,
                      ready_stok = ready_stok - :qty
                      WHERE id_barang = :id_barang");
    $this->db->bind('qty', $qty);
    $this->db->bind('id_barang', $id_barang);
    $this->db->execute();

    // 3. Hapus data penerimaan
    $this->db->query("DELETE FROM barang_terima 
                      WHERE id_barang_terima = :id");
    $this->db->bind('id', $id);
    $this->db->execute();

    return $this->db->rowCount();
}


public function hapusDataPemesanan($id)
{
    $query = "DELETE FROM pemesanan WHERE id_pesan = :id_pesan";
    $this->db->query($query);
    $this->db->bind('id_pesan', $id);

    $this->db->execute();

    return $this->db->rowCount();
}

public function ubahDataPemesanan($data)
{
    $query = "UPDATE barang_pesanan SET
                qty        = :qty,
                keterangan = :keterangan
              WHERE id_barang_pesanan = :id_barang_pesanan";

    $this->db->query($query);

    $this->db->bind('qty', $data['qty']);
    $this->db->bind('keterangan', $data['keterangan']);
    $this->db->bind('id_barang_pesanan', $data['id_barang_pesanan']);

    $this->db->execute();

    return $this->db->rowCount();
}

public function getNamaKepsek()
{
    $query = "SELECT * FROM pengguna WHERE role = 'Kepala Sekolah'";
    $this->db->query($query);
    return $this->db->single();
}


public function ubahDataPenerimaan($data)
{
    // 1. Ambil data lama
    $this->db->query("SELECT id_barang, qty 
                      FROM barang_terima 
                      WHERE id_barang_terima = :id");
    $this->db->bind('id', $data['id_barang_terima']);
    $lama = $this->db->single();

    if (!$lama) {
        return 0;
    }

    $id_barang   = $lama['id_barang'];
    $qty_lama    = $lama['qty'];
    $qty_baru    = $data['qty'];

    // 2. Hitung selisih
    $selisih = $qty_baru - $qty_lama;

    // 3. Update stok master_barang
    $this->db->query("UPDATE master_barang 
                      SET stok = stok + :selisih,
                            ready_stok = ready_stok + :selisih
                      WHERE id_barang = :id_barang");
    $this->db->bind('selisih', $selisih);
    $this->db->bind('id_barang', $id_barang);
    $this->db->execute();

    // 4. Update data penerimaan
    $query = "UPDATE barang_terima SET
                qty        = :qty,
                keterangan = :keterangan
              WHERE id_barang_terima = :id_barang_terima";

    $this->db->query($query);
    $this->db->bind('qty', $qty_baru);
    $this->db->bind('keterangan', $data['keterangan']);
    $this->db->bind('id_barang_terima', $data['id_barang_terima']);
    $this->db->execute();

    return $this->db->rowCount();
}


public function getPemesananById($id)
{
    $this->db->query("SELECT 
    b.*,  
    pm.*,
    bp.*
    FROM pemesanan p
    JOIN barang_pesanan bp ON p.id_pesan = bp.id_pesan
    JOIN master_barang b ON bp.id_barang = b.id_barang
    JOIN pemasok pm ON bp.id_pemasok = pm.id_pemasok
    WHERE bp.id_barang_pesanan = :id_barang_pesanan
    ");
    $this->db->bind('id_barang_pesanan', $id);
    return $this->db->single();
}

public function getPenerimaanById($id)
{
    $this->db->query("SELECT 
    b.*,  
    pm.*,
    bt.*
FROM pemesanan p
JOIN barang_terima bt 
    ON p.id_pesan = bt.id_pesan

JOIN master_barang b 
    ON bt.id_barang = b.id_barang

-- ambil pemasok dari barang_pesanan
JOIN barang_pesanan bp 
    ON bp.id_pesan = bt.id_pesan 
   AND bp.id_barang = bt.id_barang

JOIN pemasok pm 
    ON bp.id_pemasok = pm.id_pemasok

WHERE bt.id_barang_terima = :id_barang_terima");
    $this->db->bind('id_barang_terima', $id);
    return $this->db->single();
}



public function PesanBarang($dataInsert)
{
  // Ambil bulan & tahun sekarang
  $bulan = date('m');   // 11
  $tahun = date('Y');   // 2025

  // Pola ID: PSN-11-2025-001
  $prefix = "PSN-$bulan-$tahun-";

  // Ambil ID terakhir dengan bulan & tahun yang sama
  $this->db->query("SELECT MAX(id_pesan) AS last_id 
                    FROM pemesanan 
                    WHERE id_pesan LIKE :prefix");

  $this->db->bind('prefix', $prefix . '%');
  $last = $this->db->single();
  $lastId = $last['last_id'] ?? null;

  if ($lastId) {
      // Ambil 3 digit terakhir
      $lastNumber = (int)substr($lastId, -3);
      $newNumber = $lastNumber + 1;
  } else {
      $newNumber = 1;
  }

  // Gabungkan jadi ID baru
  $newId = $prefix . str_pad($newNumber, 3, '0', STR_PAD_LEFT);


  // Insert header pemesanan
  $this->db->query("INSERT INTO pemesanan (id_pesan, id_pengguna, disetujui, created_at)
                    VALUES (:id_pesan, :id_pengguna, :disetujui, CURRENT_TIMESTAMP)");

  $this->db->bind('id_pesan', $newId);
  $this->db->bind('id_pengguna', $_SESSION['user']['id_pengguna']);
  $this->db->bind('disetujui', 'Menunggu');
  $this->db->execute();

  $count = 0;
  $noUrut = 1; // untuk suffix -001

  foreach ($dataInsert as $row) {

      // Format: PSN-11-2025-001-001
      $id_barang_pesanan = $newId . '-' . str_pad($noUrut, 3, '0', STR_PAD_LEFT);

      $query = "INSERT INTO barang_pesanan 
                (id_barang_pesanan, id_barang, id_pesan, id_pemasok, harga, qty, keterangan)
                VALUES 
                (:id_barang_pesanan, :id_barang, :id_pesan, :id_pemasok, :harga, :qty, :keterangan)";

      $this->db->query($query);
      $this->db->bind('id_barang_pesanan', $id_barang_pesanan);
      $this->db->bind('id_barang', $row['id_barang']);
      $this->db->bind('id_pesan', $newId);
      $this->db->bind('id_pemasok', $row['id_pemasok']);
      $this->db->bind('harga', $row['harga']);
      $this->db->bind('qty', $row['qty']);
      $this->db->bind('keterangan', $row['keterangan']);
      $this->db->execute();

      $count++;
      $noUrut++;
  }

  return $count;

}

public function TerimaBarang($dataInsert)
{
    $id_pesan = $dataInsert[0]['id_pesan'];
    $prefix = $id_pesan . '-';

    $this->db->query("SELECT MAX(id_barang_terima) AS last_id
                      FROM barang_terima
                      WHERE id_barang_terima LIKE :prefix");
    $this->db->bind('prefix', $prefix . '%');
    $last = $this->db->single();

    $lastId = $last['last_id'] ?? null;

    if ($lastId) {
        $lastNumber = (int) substr($lastId, -3);
    } else {
        $lastNumber = 500; // agar mulai 501
    }

    $count = 0;

    foreach ($dataInsert as $row) {

        $lastNumber++;

        $id_barang_terima = $prefix . str_pad($lastNumber, 3, '0', STR_PAD_LEFT);

        // INSERT barang diterima
        $this->db->query("INSERT INTO barang_terima
                          (id_barang_terima, id_pesan, id_barang, qty, harga, keterangan)
                          VALUES
                          (:id_barang_terima, :id_pesan, :id_barang, :qty, :harga, :keterangan)");

        $this->db->bind('id_barang_terima', $id_barang_terima);
        $this->db->bind('id_pesan', $row['id_pesan']);
        $this->db->bind('id_barang', $row['id_barang']);
        $this->db->bind('qty', $row['qty']);
        $this->db->bind('harga', $row['harga']);
        $this->db->bind('keterangan', $row['keterangan']);
        $this->db->execute();


        /* =============================
           UPDATE STOK MASTER BARANG
           ============================= */

        $this->db->query("UPDATE master_barang
                          SET stok = stok + :qty,
                              ready_stok = ready_stok + :qty,
                              harga = :harga
                          WHERE id_barang = :id_barang");

        $this->db->bind('qty', $row['qty']);
        $this->db->bind('harga', $row['harga']);
        $this->db->bind('id_barang', $row['id_barang']);
        $this->db->execute();


        $count++;
    }

    // Update waktu penerimaan di pemesanan
    $this->db->query("UPDATE pemesanan 
                      SET created_at_terima = CURRENT_TIMESTAMP 
                      WHERE id_pesan = :id_pesan");
    $this->db->bind('id_pesan', $id_pesan);
    $this->db->execute();

    return $count;
}


  public function getAllPemasok()
  {
    $this->db->query('SELECT * FROM pemasok');
    return $this->db->resultSet();
  }

  public function getBarangById($id)
{
    $this->db->query("SELECT * FROM master_barang WHERE id_barang = :id;");
    $this->db->bind('id', $id);
    return $this->db->single(); // kembalikan array associative
}

  public function getPesananById($id)
{
    $this->db->query("SELECT 
    bp.*, bp.harga AS harga_satuan,
    mb.*,
    pms.*,
    pm.*,
    IFNULL(bt.total_qty, 0) AS qty_terima
FROM barang_pesanan bp

JOIN pemesanan pm 
    ON bp.id_pesan = pm.id_pesan

JOIN master_barang mb 
    ON bp.id_barang = mb.id_barang

JOIN pemasok pms 
    ON bp.id_pemasok = pms.id_pemasok

LEFT JOIN (
    SELECT 
        id_pesan,
        id_barang,
        SUM(qty) AS total_qty
    FROM barang_terima
    GROUP BY id_pesan, id_barang
) bt 
    ON bt.id_pesan = bp.id_pesan
   AND bt.id_barang = bp.id_barang

WHERE bp.id_barang_pesanan = :id;");
    $this->db->bind('id', $id);
    return $this->db->single(); // kembalikan array associative
}


  public function cariDataBarang()
  {
    $keyword = $_POST['keyword'];
$query = "SELECT *
          FROM master_barang
          WHERE nama_barang LIKE :keyword";
    $this->db->query($query);
    $this->db->bind('keyword', "%$keyword%");
    return $this->db->resultSet();
  }

      // Ambil semua history pemesanan
public function getHistoryPemesanan() {
    $query = "SELECT 
        p.id_pesan,
        p.created_at,
        b.nama_barang,
        pm.nama_pemasok,
        bp.qty,
        bp.keterangan,
        p.disetujui,
        u.first_name,
        u.last_name
    FROM pemesanan p
    JOIN barang_pesanan bp ON p.id_pesan = bp.id_pesan
    JOIN master_barang b ON bp.id_barang = b.id_barang
    JOIN pemasok pm ON bp.id_pemasok = pm.id_pemasok
    JOIN pengguna u ON u.id_pengguna = p.id_pengguna
    GROUP BY p.id_pesan
    ORDER BY p.created_at DESC";

    $this->db->query($query);
    return $this->db->resultSet();
}

      // Ambil semua history pemesanan
public function getDataPenerimaan() {
    $query = "SELECT
    p.id_pesan,
    p.created_at,
    u.first_name,
    u.last_name,
    p.disetujui,
    
    -- Total qty yang dipesan
    SUM(bp.qty) AS total_qty_pesan,

    -- Total qty yang diterima
    COALESCE(SUM(bt.qty), 0) AS total_qty_terima,

    -- Nama barang (opsional)
    GROUP_CONCAT(DISTINCT b.nama_barang SEPARATOR ', ') AS nama_barang,

    -- Nama pemasok
    GROUP_CONCAT(DISTINCT pm.nama_pemasok SEPARATOR ', ') AS nama_pemasok

FROM pemesanan p
JOIN pengguna u ON u.id_pengguna = p.id_pengguna
JOIN barang_pesanan bp ON p.id_pesan = bp.id_pesan

LEFT JOIN barang_terima bt 
    ON bt.id_pesan = p.id_pesan
    AND bt.id_barang = bp.id_barang

JOIN master_barang b ON bp.id_barang = b.id_barang
JOIN pemasok pm ON bp.id_pemasok = pm.id_pemasok

WHERE p.disetujui = 'Diterima'

GROUP BY p.id_pesan

-- ❗ Hanya tampilkan jika barang diterima belum lengkap
HAVING COALESCE(SUM(bt.qty), 0) < SUM(bp.qty)

ORDER BY p.created_at DESC;";

    $this->db->query($query);
    return $this->db->resultSet();
}


  public function getBarangPemesananById($id) {
      $query = "SELECT 
  bp.*,
  mb.nama_barang,
  pm.nama_pemasok,
  p.*,
  IFNULL(bt.total_qty, 0) AS qty_terima
FROM barang_pesanan bp

JOIN pemesanan p 
  ON bp.id_pesan = p.id_pesan

JOIN master_barang mb 
  ON bp.id_barang = mb.id_barang

JOIN pemasok pm 
  ON bp.id_pemasok = pm.id_pemasok

LEFT JOIN (
    SELECT 
        id_pesan,
        id_barang,
        SUM(qty) AS total_qty
    FROM barang_terima
    GROUP BY id_pesan, id_barang
) bt 
ON bt.id_pesan = bp.id_pesan 
AND bt.id_barang = bp.id_barang

WHERE bp.id_pesan = :id_pesan;";
      $this->db->query($query);
      $this->db->bind('id_pesan', $id);
      return $this->db->resultSet();
  }

  public function getHistoryPenerimaanById($id) {
      $query = "SELECT 
    bt.*,
    p.*,
    mb.nama_barang,
    pm.nama_pemasok
FROM barang_terima bt
JOIN master_barang mb 
    ON bt.id_barang = mb.id_barang
JOIN pemesanan p 
    ON bt.id_pesan = p.id_pesan
JOIN barang_pesanan bp 
    ON p.id_pesan = bp.id_pesan
JOIN pemasok pm 
    ON bp.id_pemasok = pm.id_pemasok
WHERE bt.id_pesan = :id_pesan
GROUP BY bt.id_barang_terima";
      $this->db->query($query);
      $this->db->bind('id_pesan', $id);
      return $this->db->resultSet();
  }


}
