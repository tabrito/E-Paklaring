<?php
class Paklaring_model
{
  private $table = 'paklaring';
  private $db;

  public function __construct()
  {
    $this->db = new Database;
  }
    public function getAllPaklaring()
  {
$this->db->query("SELECT *, pk.tanggal AS tanggal_rilis
    FROM paklaring pk
    JOIN pengajuan p
        ON pk.id_pengajuan = p.id_pengajuan
    JOIN karyawan k 
        ON p.nik = k.nik
    JOIN departemen d 
        ON k.id_departemen = d.id_departemen
    JOIN instansi i 
        ON d.id_instansi = i.id_instansi
    JOIN exit_clear ec
        ON p.id_pengajuan = ec.id_pengajuan
    WHERE ec.approval_hr = 'Approved' AND ec.approval_spv = 'Approved';");
    return $this->db->resultSet();
  }

    public function getPaklaringByDept($id)
  {
$this->db->query("SELECT *, pk.tanggal AS tanggal_rilis
    FROM paklaring pk
    JOIN pengajuan p
        ON pk.id_pengajuan = p.id_pengajuan
    JOIN karyawan k 
        ON p.nik = k.nik
    JOIN departemen d 
        ON k.id_departemen = d.id_departemen
    JOIN instansi i 
        ON d.id_instansi = i.id_instansi
    JOIN exit_clear ec
        ON p.id_pengajuan = ec.id_pengajuan
    WHERE k.id_departemen = :id AND ec.approval_hr = 'Approved' AND ec.approval_spv = 'Approved';");
    
    $this->db->bind('id', $id);
    return $this->db->resultSet();
  }

    public function getPaklaringByKaryawan($id)
  {
$this->db->query("SELECT *, pk.tanggal AS tanggal_rilis
    FROM paklaring pk
    JOIN pengajuan p
        ON pk.id_pengajuan = p.id_pengajuan
    JOIN karyawan k 
        ON p.nik = k.nik
    JOIN departemen d 
        ON k.id_departemen = d.id_departemen
    JOIN instansi i 
        ON d.id_instansi = i.id_instansi
    JOIN exit_clear ec
        ON p.id_pengajuan = ec.id_pengajuan
    WHERE p.nik = :nik AND ec.approval_hr = 'Approved' AND ec.approval_spv = 'Approved';");
    
    $this->db->bind('nik', $id);
    return $this->db->resultSet();
  }

 public function generateIDPaklaring()
{
    $this->db->query("SELECT id_paklaring 
                      FROM paklaring 
                      ORDER BY id_paklaring DESC 
                      LIMIT 1");

    $last = $this->db->single();

    if (!$last) {
        return 'PAK-0001';
    }

    $lastNumber = (int) substr($last['id_paklaring'], 4);
    $newNumber  = $lastNumber + 1;

    return 'PAK-' . str_pad($newNumber, 4, '0', STR_PAD_LEFT);
}

    public function rilisDataPaklaring($id)
  {
      $idPaklaring = $this->generateIDPaklaring();

      $query1 = "INSERT INTO paklaring
                (id_paklaring, id_pengajuan, no_paklaring, tanggal)
                VALUES
                (:id_paklaring, :id_pengajuan, :no_paklaring, :tanggal)";

      $this->db->query($query1);
      $this->db->bind('id_paklaring', $idPaklaring);
      $this->db->bind('id_pengajuan', $id);
      $this->db->bind('no_paklaring', 'PAK-NOV-001');
      $this->db->bind('tanggal', date('Y-m-d'));
      $this->db->execute();
      
      return $this->db->rowCount();

  }

}
