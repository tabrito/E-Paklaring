<?php
class Profile_model
{
  private $table = 'users';
  private $db;

  public function __construct()
  {
    $this->db = new Database;
  }
    public function getProfile()
  {
$this->db->query("SELECT
                      u.id_user, 
                      u.username, 
                      u.role,
                      u.status,

                      k.*,

                      COALESCE(k.nik, a.nik) AS nik,
                      COALESCE(k.first_name, a.first_name) AS first_name,
                      COALESCE(k.last_name, a.last_name) AS last_name,
                      COALESCE(k.id_departemen, a.id_departemen) AS id_departemen,
                      COALESCE(k.jabatan, a.jabatan) AS jabatan,

                      d.departemen,
                      i.instansi,

                      CASE
                          WHEN k.nik IS NOT NULL THEN 'karyawan'
                          WHEN a.nik IS NOT NULL THEN 'approver'
                          ELSE 'unknown'
                      END AS tipe_user

                  FROM users u
                  LEFT JOIN karyawan k 
                      ON u.id_user = k.id_user

                  LEFT JOIN approver a 
                      ON u.id_user = a.id_user

                  LEFT JOIN departemen d 
                      ON d.id_departemen = COALESCE(k.id_departemen, a.id_departemen)
                  
                  LEFT JOIN instansi i
                      ON d.id_instansi = i.id_instansi
                  WHERE u.role <> 'non-user' AND u.id_user = :id_user
                  ORDER BY u.status, first_name;");
    $this->db->bind('id_user', $_SESSION['user']['id_user']);

    return $this->db->resultSet();
  }

public function getUserByUsername($username)
{
    $this->db->query("
        SELECT 
            u.*,
            
            COALESCE(k.first_name, a.first_name) AS first_name,
            COALESCE(k.last_name, a.last_name) AS last_name,
            COALESCE(k.jabatan, a.jabatan) AS jabatan,

            CASE
                WHEN k.id_user IS NOT NULL THEN 'karyawan'
                WHEN a.id_user IS NOT NULL THEN 'approver'
                ELSE 'unknown'
            END AS tipe_user

        FROM users u

        LEFT JOIN karyawan k 
            ON u.id_user = k.id_user

        LEFT JOIN approver a 
            ON u.id_user = a.id_user

        WHERE u.username = :username
    ");

    $this->db->bind('username', $username);

    return $this->db->single();
}

      public function getKaryawanNonUser()
  {
$this->db->query("SELECT 
    k.*,
    u.status,
    d.departemen,
    i.instansi
FROM karyawan k
LEFT JOIN users u 
    ON k.id_user = u.id_user
LEFT JOIN departemen d 
    ON k.id_departemen = d.id_departemen
LEFT JOIN instansi i 
    ON d.id_instansi = i.id_instansi
WHERE u.role = 'Non-user'
ORDER BY u.status, k.first_name;");
    return $this->db->resultSet();
  }

      public function getApproverNonUser()
  {
$this->db->query("SELECT 
    a.*,
    d.departemen,
    i.instansi
FROM approver a
LEFT JOIN users u 
    ON a.id_user = u.id_user
LEFT JOIN departemen d 
    ON a.id_departemen = d.id_departemen
LEFT JOIN instansi i 
    ON d.id_instansi = i.id_instansi
WHERE u.role = 'Non-user'
ORDER BY a.jabatan, a.first_name;");
    return $this->db->resultSet();
  }

  public function generateIdUser()
{
    $this->db->query("SELECT id_user 
                      FROM users 
                      ORDER BY id_user DESC 
                      LIMIT 1");

    $last = $this->db->single();

    if (!$last) {
        return 'U-0001';
    }

    $lastNumber = (int) substr($last['id_user'], 2); // ambil angka setelah D-
    $newNumber  = $lastNumber + 1;

    return 'U-' . str_pad($newNumber, 4, '0', STR_PAD_LEFT);
}

    // ================================
    // TAMBAH USER
    // ================================
    public function tambahUser($data)
    {
        $password = password_hash($data['password'], PASSWORD_DEFAULT);
        $idBaru = $this->generateIdUser();

        $query = "INSERT INTO users
                  (id_user, username, password, role, status)
                  VALUES
                  (:id_user, :username, :password, :role, :status)";

        $this->db->query($query);
        $this->db->bind('id_user', $idBaru); // nik
        $this->db->bind('username', $data['username']);
        $this->db->bind('password', $password);
        $this->db->bind('role', $data['role']);
        $this->db->bind('status', $data['status']);
        $this->db->execute();

        $id = $data['kategori'];

        $this->db->query("SELECT * FROM karyawan
                        WHERE nik = :id;");
        $this->db->bind('id', $id);
        $karyawan = $this->db->single();
        
        if ($karyawan) {

            // Update id_user di tabel karyawan
            $this->db->query("UPDATE karyawan 
                              SET id_user = :id_user 
                              WHERE nik = :id");
            $this->db->bind('id_user', $idBaru);
            $this->db->bind('id', $id);

            return $this->db->execute();
        }

        $this->db->query("SELECT * FROM approver
                        WHERE nik = :id;");
        $this->db->bind('id', $id);
        $approver = $this->db->single();
        
        if ($approver) {

            // Update id_user di tabel karyawan
            $this->db->query("UPDATE approver 
                              SET id_user = :id_user 
                              WHERE nik = :id");
            $this->db->bind('id_user', $idBaru);
            $this->db->bind('id', $id);

            return $this->db->execute();
        }

        return $this->db->rowCount();
    }

    // ================================
    // UPDATE USER
    // ================================
    public function updateUser($data)
    {
        if (!empty($data['password'])) {

            $password = password_hash($data['password'], PASSWORD_DEFAULT);

            $query = "UPDATE users SET
                        username = :username,
                        password = :password,
                        role = :role,
                        status = :status
                      WHERE id_user = :id_user";

            $this->db->query($query);
            $this->db->bind('password', $password);

        } else {

            $query = "UPDATE users SET
                        username = :username,
                        role = :role,
                        status = :status
                      WHERE id_user = :id_user";

            $this->db->query($query);
        }

        $this->db->bind('username', $data['username']);
        $this->db->bind('role', $data['role']);
        $this->db->bind('status', $data['status']);
        $this->db->bind('id_user', $data['id_user']);

        $this->db->execute();

        return $this->db->rowCount();
    }

}
