<?php
class Home_model
{
  private $table = 'master_barang';
  private $db;

  public function __construct()
  {
    $this->db = new Database;
  }

  public function getAllPengajuan()
  {
    $this->db->query("SELECT COUNT(id_pengajuan) as count FROM pengajuan");
    return $this->db->single();
  }

  public function getAllExitClear()
  {
    $this->db->query("SELECT COUNT(id_exit_clear) as count FROM exit_clear");
    return $this->db->single();
  }

  public function getAllPaklaring()
  {
    $this->db->query("SELECT COUNT(id_paklaring) as count FROM paklaring");
    return $this->db->single();
  }

  public function getAllUsers()
  {
    $this->db->query("SELECT COUNT(id_user) as count FROM users");
    return $this->db->single();
  }

  public function getAllKaryawan()
  {
    $this->db->query("SELECT COUNT(nik) as count FROM karyawan");
    return $this->db->single();
  }

  public function getAllApprover()
  {
    $this->db->query("SELECT COUNT(nik) as count FROM approver");
    return $this->db->single();
  }

}
