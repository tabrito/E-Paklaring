<?php
class Instansi_model
{
  private $table = 'karyawan';
  private $db;

  public function __construct()
  {
    $this->db = new Database;
  }
    public function getAllInstansi()
  {
$this->db->query("SELECT
    i.*,
    d.departemen
    FROM instansi i
    LEFT JOIN departemen d 
    ON i.id_instansi = d.id_instansi
    GROUP BY i.id_instansi;");
    return $this->db->resultSet();
  }

  public function getIdByNama($nama)
{
    $this->db->query("SELECT id_departemen FROM departemen WHERE departemen = :nama");
    $this->db->bind('nama', $nama);
    return $this->db->single();
}

public function getByNamaDanInstansi($namaDept, $namaInstansi)
{
    $query = "
        SELECT d.id_departemen
        FROM departemen d
        JOIN instansi i 
            ON d.id_instansi = i.id_instansi
        JOIN approver a 
            ON a.id_departemen = d.id_departemen
        WHERE d.departemen = :dept
        AND i.instansi = :instansi
        GROUP BY d.id_departemen
    ";

    $this->db->query($query);

    $this->db->bind('dept', $namaDept);
    $this->db->bind('instansi', $namaInstansi);

    return $this->db->single();
}

public function getByNamaDanInstansiNonApprover($namaDept, $namaInstansi)
{
    $query = "
        SELECT d.id_departemen
        FROM departemen d
        JOIN instansi i 
            ON d.id_instansi = i.id_instansi
        WHERE d.departemen = :dept
        AND i.instansi = :instansi
        AND NOT EXISTS (
            SELECT 1 
            FROM approver a
            WHERE a.id_departemen = d.id_departemen)
    ";

    $this->db->query($query);

    $this->db->bind('dept', $namaDept);
    $this->db->bind('instansi', $namaInstansi);

    return $this->db->single();
}

    public function getAllDepartemen()
  {
$this->db->query("SELECT *, d.id_departemen as id_departemen
    FROM departemen d
    LEFT JOIN approver a
    ON d.id_departemen = a.id_departemen
    JOIN instansi i
    ON d.id_instansi = i.id_instansi;");
    return $this->db->resultSet();
  }

    public function generateIDInstansi()
{
    $this->db->query("SELECT id_instansi 
                      FROM instansi 
                      ORDER BY id_instansi DESC 
                      LIMIT 1");

    $last = $this->db->single();

    if (!$last) {
        return 'I-0001';
    }

    $lastNumber = (int) substr($last['id_instansi'], 2);
    $newNumber  = $lastNumber + 1;

    return 'I-' . str_pad($newNumber, 4, '0', STR_PAD_LEFT);
}

    public function generateIDDepartemen()
{
    $this->db->query("SELECT id_departemen 
                      FROM departemen 
                      ORDER BY id_departemen DESC 
                      LIMIT 1");

    $last = $this->db->single();

    if (!$last) {
        return 'D-0001';
    }

    $lastNumber = (int) substr($last['id_departemen'], 2);
    $newNumber  = $lastNumber + 1;

    return 'D-' . str_pad($newNumber, 4, '0', STR_PAD_LEFT);
}

    public function tambahInstansi($data)
  {
      $query = "INSERT INTO instansi
                (id_instansi, instansi, alamat)
                VALUES
                (:id_instansi, :instansi, :alamat)";

      $this->db->query($query);
      $this->db->bind('id_instansi', $data['id_instansi']);
      $this->db->bind('instansi', $data['instansi']);
      $this->db->bind('alamat', $data['alamat']);
      $this->db->execute();
      
      return $this->db->rowCount();

  }

      public function addDepartemen($data)
    {
      $idBaru = $this->generateIDDepartemen();

        $query = "INSERT INTO departemen
                  (id_departemen, departemen, id_instansi)
                  VALUES
                  (:id_departemen, :departemen, :id_instansi)";

        $this->db->query($query);

        $this->db->bind('id_departemen', $idBaru);
        $this->db->bind('departemen', $data['departemen']);
        $this->db->bind('id_instansi', $data['id_instansi']);

        $this->db->execute();

        return $idBaru; // ambil id_departemen terakhir
    }

        public function updateInstansi($data)
    {

    $query = "UPDATE instansi SET
                instansi = :instansi,
                alamat = :alamat
                WHERE id_instansi = :id_instansi";

    $this->db->query($query);

        $this->db->bind('instansi', $data['instansi']);
        $this->db->bind('alamat', $data['alamat']);
        $this->db->bind('id_instansi', $data['id_instansi']);

        $this->db->execute();

        return $this->db->rowCount();
    }

            public function deleteInstansi($id_instansi)
    {
        $this->db->query("DELETE FROM instansi WHERE id_instansi = :id_instansi");
        $this->db->bind('id_instansi', $id_instansi);
        $this->db->execute();

        return $this->db->rowCount();
    }

    

    public function deleteDepartemen($id)
{
    $query = "DELETE FROM departemen WHERE id_departemen = :id";

    $this->db->query($query);
    $this->db->bind('id', $id);
    $this->db->execute();

    return $this->db->rowCount();
}

}
