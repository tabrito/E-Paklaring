  <!-- Flash Message -->
  <div class="row">
    <div class="col-lg-8">
      <?php Flasher::flash(); ?>
    </div>
  </div>

<div class="main-content">

<div class="d-flex align-items-center mb-3">

  <div class="flex-fill text-center">
    <h4 class="table-title fw-bold mb-0">
      Data Users
    </h4>
  </div>

  <div>
    <a href="#" 
      class="btn btn-ubah btn-add px-3"
      data-bs-toggle="modal" 
      data-bs-target="#modalTambah">
      Tambah User
    </a>
  </div>

</div>

<!-- Daftar Mahasiswa -->
<div class="row">
  <div class="col-12">
    <div class="" style="height: 470px; overflow-y: auto;">
      <table class="table table-bordered mb-0" style="font-size: 14px;">
        <thead class="table-head text-center align-middle">
          <tr>
            <th>No</th>
            <th>NIK</th>
            <th>Full Name</th>
            <th>Username</th>
            <th>Role</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php $no = 1; 
          ?>
          <?php foreach ($data['user'] as $user) : 
            ?>
            <tr class="<?= $rowClass; ?>">
              <td class="text-center"><?= $no++; ?></td>
              <td><?= $user['nik']; ?></td>
              <td><?= $user['first_name']; ?> <?= $user['last_name']; ?></td>
              <td><?= $user['username']; ?></td>
              <td><?= $user['role']; ?></td>
              <td><?= $user['status']; ?></td>
              <td class="text-center">
                <a href="#" 
                  class="btn btn-sm btn-tambah btn-edit"
                  data-bs-toggle="modal" 
                  data-bs-target="#modalTambah"
                  data-id="<?= $user['id_user']; ?>"
                  data-nik="<?= $user['nik']; ?>"
                  data-kategori="<?= $user['nik']; ?>"
                  data-fullname="<?= $user['first_name']; ?> <?= $user['last_name']; ?>"
                  data-username="<?= $user['username']; ?>"
                  data-role="<?= $user['role']; ?>"
                  data-status="<?= $user['status']; ?>">
                  Edit
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

</div>

</div>

<!-- Modal Form -->
<div class="modal fade" id="modalTambah" tabindex="-1" role="dialog" aria-labelledby="formModalTambah" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content shadow rounded-lg">

      <!-- Header -->
      <div class="modal-header bg-modal text-white">
        <h5 class="modal-title w-100 text-center" id="formModalTambah">
          Tambah Users
        </h5>
      </div>

      <!-- Form -->
      <form action="<?= BASEURL; ?>/users/tambah"
      method="post">

        <div class="modal-body">

          <input type="hidden" name="id" id="id">
          <input type="hidden" name="id_barang" id="id_barang">
          <input type="hidden" name="foto_lama" id="foto_lama">

          <!-- Nama Barang -->

          <!-- Kategori -->
          <div class="form-group d-flex">
            <label style="width: 150px" class="label-modal" for="kategori"><strong>Pilih User</strong></label>
            <select class="form-control" 
                    id="kategori" 
                    name="kategori" required>
              <option id="id_choosen" value=""></option>
              <option value="">-- Approver --</option>
              <?php foreach ($data['app'] as $app) : ?>
                <option value="<?= $app['nik']; ?>" data-jabatan="<?= $app['jabatan']; ?>">
                  <?= $app['first_name']; ?> <?= $app['last_name']; ?>
                </option>
              <?php endforeach; ?>

              <option value="">-- Karyawan --</option>
              <?php foreach ($data['kar'] as $kar) : ?>
                <option value="<?= $kar['nik']; ?>" data-jabatan="<?= $kar['jabatan']; ?>">
                  <?= $kar['first_name']; ?> <?= $kar['last_name']; ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Username -->
          <div class="form-group d-flex mb-3">
            <label style="width: 150px" class="label-modal">
              <strong>Username</strong>
            </label>
            <input type="text" 
                  class="form-control" 
                  name="username" 
                  placeholder="Masukkan username"
                  id="username"
                  required>
          </div>

          <!-- Password -->
          <div class="form-group mb-3 d-none" id="div-password">
            <label style="width: 150px" class="label-modal">
              <strong>Password</strong>
            </label>
            <input type="password" 
                  class="form-control" 
                  name="password" 
                  placeholder="Masukkan password"
                  id="password"
                  required>
          </div>

          <input type="hidden" name="id_user" id="id_user">

          <!-- Role -->
          <div class="form-group d-flex mb-3">
            <label style="width: 150px" class="label-modal">
              <strong>Role</strong>
            </label>
            <input type="text" class="form-control" readonly style="background-color: white;" name="role" id="role">
          </div>

          <!-- Status -->
          <div class="form-group d-flex mb-3">
            <label style="width: 150px" class="label-modal">
              <strong>Status</strong>
            </label>
            <select class="form-control" name="status" id="status" required>
              <option value="">-- Pilih Status --</option>
              <option value="Active">Active</option>
              <option value="Non-active">Non-active</option>
            </select>
          </div>

        </div>

        <!-- Footer -->
        <div class="modal-footer">
          <button type="button"
                  class="btn btn-secondary" data-bs-dismiss="modal">
            Batal
          </button>

          <button type="submit" 
                  class="btn btn-simpan">
            Simpan
          </button>
        </div>

      </form>
    </div>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {

  const modal = document.getElementById("modalTambah");
  const form = modal.querySelector("form");

  document.querySelector(".btn-add").addEventListener("click", function () {
    document.getElementById("div-password").classList.remove("d-none");
    document.getElementById("div-password").classList.add("d-flex");
  });

  document.querySelectorAll(".btn-edit").forEach(button => {
    button.addEventListener("click", function () {

      // Ambil data
      const id = this.getAttribute("data-id");
      const nik = this.getAttribute("data-nik");
      const kategori = this.getAttribute("data-kategori");
      const fullname = this.getAttribute("data-fullname");
      const username = this.getAttribute("data-username");
      const role = this.getAttribute("data-role");
      const status = this.getAttribute("data-status");
      
      document.getElementById("div-password").classList.add("d-none");
      document.getElementById("div-password").classList.remove("d-flex");

      // Isi form
      document.getElementById("id_choosen").value = nik;
      document.getElementById("id_choosen").textContent = fullname;

      document.getElementById("id_user").value = id;
      document.getElementById("kategori").value = kategori;
      document.getElementById("username").value = username;
      document.getElementById("role").value = role;
      document.getElementById("status").value = status;

      // Password kosongkan saat edit
      document.getElementById("password").value = "";
      document.getElementById("password").removeAttribute("required");

      // Ganti Judul Modal
      document.getElementById("formModalTambah").innerText = "Edit Users";

      // Ganti Action Form
      form.action = "<?= BASEURL; ?>/users/update";
    });
  });

  document.getElementById("kategori").addEventListener("change", function () {

  let selected = this.options[this.selectedIndex];
  let jabatan = selected.dataset.jabatan;

  let roleInput = document.getElementById("role");

  if (!jabatan) {
    roleInput.value = "";
    return;
  }

  if (jabatan.toLowerCase() === "manager") {
    roleInput.value = "HRD";
  } 
  else if (jabatan.toLowerCase() === "supervisor") {
    roleInput.value = "Supervisor";
  } 
  else {
    roleInput.value = "Karyawan";
  }

});

});
</script>