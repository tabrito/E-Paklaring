  <!-- Flash Message -->
  <div class="row">
    <div class="col-lg-8">
      <?php Flasher::flash(); ?>
    </div>
  </div>

<div class="main-content">
<div class="d-flex align-items-center mb-3">

  <div class="flex-fill text-center" style="width: 300px;">
    <h4 class="table-title fw-bold mb-0">Data Request</h4>
  </div>

</div>

<!-- Daftar Mahasiswa -->
<div class="row">
  <div class="col-12">
    <div class="" style="height: 360px;">
      <table class="table table-bordered mb-0" style="font-size: 14px;">
        <thead class="table-head text-center align-middle">
          <tr>
            <th rowspan="2">No</th>
            <th rowspan="2">Tanggal Request</th>
            <th rowspan="2">Nama Karyawan</th>
            
            <th colspan="3">Exit Clear</th>
            <th colspan="2">Approval</th>
            <th width="9%" rowspan="2">Paklaring</th>
            <?php if($_SESSION['user']['role'] == 'HRD') : ?>
            <th width="9%" rowspan="2">Action</th>
            <?php endif ?>
          </tr>
          <tr>
            <th width="9%">Interview</th>
            <th width="9%">Aset</th>
            <th width="9%">Administrasi</th>
            
            <th width="9%">SPV</th>
            <th width="9%">HRD</th>
          </tr>
        </thead>
        <tbody>
          <?php $no = 1; ?>
          <?php foreach ($data['req'] as $req) : 
            ?>
            <tr class="<?= $rowClass; ?>">
              <td class="text-center"><?= $no++; ?></td>
              <td>
                <?= !empty($req['tanggal_pengajuan']) 
                    ? date('d-M-y', strtotime($req['tanggal_pengajuan'])) 
                    : '-' ?>
              </td>
              <td><?= $req['first_name']; ?> <?= $req['last_name']; ?></td>
              
              <td class="text-center">
                <?php if($req['id_interview']) : ?>
                <a href="#" class="status-circle approve">
                  <i class="bi bi-check"></i>
                </a>
                <?php else : ?>
                <a href="#" class="status-circle empty">
                  <i class="bi bi-question"></i>
                </a>
                <?php endif ?>                  
              </td>
              <td class="text-center">
                <?php if($req['id_aset']) : ?>
                <a href="#" class="status-circle approve">
                  <i class="bi bi-check"></i>
                </a>
                <?php else : ?>
                <a href="#" class="status-circle empty">
                  <i class="bi bi-question"></i>
                </a>
                <?php endif ?>                  
              </td>
              <td class="text-center">
                <?php if($req['id_administrasi']) : ?>
                <a href="#" class="status-circle approve">
                  <i class="bi bi-check"></i>
                </a>
                <?php else : ?>
                <a href="#" class="status-circle empty">
                  <i class="bi bi-question"></i>
                </a>
                <?php endif ?>                  
              </td>
              <td class="text-center">
                <?php if($req['approval_spv'] == 'Approved') : ?>
                <a href="#" class="status-circle approve">
                  <i class="bi bi-check"></i>
                </a>
                <?php elseif($req['approval_spv'] == 'Rejected') : ?>
                <a href="#" class="status-circle reject">
                  <i class="bi bi-x"></i>
                </a>
                <?php else : ?>
                <a href="#" class="status-circle empty">
                  <i class="bi bi-question"></i>
                </a>
                <?php endif ?>    
              </td>
              <td class="text-center">
                <?php if($req['approval_hr'] == 'Approved') : ?>
                <a href="#" class="status-circle approve">
                  <i class="bi bi-check"></i>
                </a>
                <?php elseif($req['approval_hr'] == 'Rejected') : ?>
                <a href="#" class="status-circle reject">
                  <i class="bi bi-x"></i>
                </a>
                <?php else : ?>
                <a href="#" class="status-circle empty">
                  <i class="bi bi-question"></i>
                </a>
                <?php endif ?>    
              </td>
              <td class="text-center">
                <?php if($req['id_paklaring']) : ?>
                <a href="#" class="status-circle approve">
                  <i class="bi bi-check"></i>
                </a>
                <?php else : ?>
                <a href="#" class="status-circle empty">
                  <i class="bi bi-question"></i>
                </a>
                <?php endif ?>  
              </td>
              <?php if($_SESSION['user']['role'] == 'HRD') : ?>
              <td class="d-flex text-center align-middle">
              <?php if(
                  $req['approval_hr'] == 'Approved' &&
                  $req['approval_spv'] == 'Approved' &&
                  empty($req['id_paklaring'])
              ) : ?>

              <a href="<?= BASEURL; ?>/paklaring/rilisPaklaring/<?= $req['id_pengajuan']; ?>" 
                class="btn btn-sm btn-ubah"
                onclick="return confirm('Apakah anda yakin merilis paklaring?')">
                Rilis Paklaring
              </a>

              <?php elseif(
                  $req['approval_hr'] == 'Approved' &&
                  $req['approval_spv'] == 'Approved' &&
                  !empty($req['id_paklaring'])
              ) : ?>

              <a href="<?= BASEURL; ?>/paklaring/lihat/<?= $req['id_paklaring']; ?>" 
                class="btn btn-sm btn-tambah">
                Lihat Paklaring
              </a>

              <?php else : ?>

              <label class="text-center">Belum bisa rilis paklaring</label>

              <?php endif ?>
              </td>
              <?php endif ?>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <?php if(empty($data['req'])) :?>
      <div class="d-flex justify-content-center mt-3">
        <a href="<?= BASEURL; ?>/request/tambah"
          class="btn btn-ubah px-4"
          onclick="return confirm('Ajukan paklaring ?\nAnda akan diarahkan untuk mengisi exit clear')">
          Ajukan Paklaring
        </a>
      </div>
      <?php else : ?>
        <?php if($_SESSION['user']['role'] == 'Karyawan') : ?>
      <div class="d-flex justify-content-center mt-3">
        <a href="<?= BASEURL; ?>/exit_clear/tambah" class="btn btn-ubah px-4">
          Isi Exit Clear
        </a>
      </div>
      <?php endif ?>
      <?php endif ?>
    </div>
  </div>
</div>

</div>

</div>

<!-- Modal Form -->
<div class="modal fade" id="modalTambah" tabindex="-1" role="dialog" aria-labelledby="formModalTambah" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content shadow rounded-lg">

      <!-- Header -->
      <div class="modal-header bg-modal text-white">
        <h5 class="modal-title w-100 text-center" id="formModalTambah">
          <i class="bi bi-box-seam me-2"></i> Tambah Pengajuan
        </h5>
      </div>

      <!-- Form -->
      <form action="<?= BASEURL; ?>/master_barang/tambahBarang" 
            method="post" 
            enctype="multipart/form-data">

        <div class="modal-body">

          <input type="hidden" name="id" id="id">
          <input type="hidden" name="id_barang" id="id_barang">
          <input type="hidden" name="foto_lama" id="foto_lama">

          <!-- Nama Barang -->
          <div class="form-group d-flex">
            <label style="width: 150px" class="label-modal" for="nama_barang"><strong>Nama</strong></label>
            <input type="text" class="form-control" 
                   id="nama_barang" 
                   name="nama_barang" required>
          </div>

          <!-- Kategori -->
          <div class="form-group d-flex">
            <label style="width: 150px" class="label-modal" for="kategori"><strong>Kategori</strong></label>
            <select class="form-control" 
                    id="kategori" 
                    name="kategori" required>
              <option value="">-- Pilih Kategori --</option>
              <?php foreach ($data['kategori'] as $k) : ?>
                <option value="<?= $k['id_kategori']; ?>">
                  <?= $k['nama_kategori']; ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Stok Minimal -->
          <div class="form-group d-flex">
            <label style="width: 150px" class="label-modal" for="min_stok"><strong>Stok Minimal</strong></label>
            <input type="number" 
                   class="form-control" 
                   id="min_stok" 
                   name="min_stok" required>
          </div>

          <!-- Deskripsi -->
          <div class="form-group d-flex">
            <label style="width: 150px" class="label-modal" for="deskripsi"><strong>Deskripsi</strong></label>
            <textarea class="form-control" 
                      id="deskripsi" 
                      name="deskripsi" rows="3" required></textarea>
          </div>

          <!-- Foto -->
          <div class="form-group d-flex">
            <label style="width: 150px" class="label-modal" for="foto"> <strong>Foto Barang</strong></label>
            <input type="file" 
                   class="form-control-file" 
                   id="foto" 
                   name="foto" 
                   accept="image/*"
                   onchange="previewImage()" required>
          </div>

          <!-- Preview -->
          <div class="text-center">
            <img id="preview" 
                 class="img-fluid mt-3 rounded shadow-sm" 
                 style="max-height: 250px; display:none;">
          </div>

        </div>

        <!-- Footer -->
        <div class="modal-footer">
          <button type="button" 
                  class="btn btn-secondary" 
                  data-dismiss="modal">
            Batal
          </button>

          <button type="submit" 
                  class="btn btn-simpan">
            <i class="bi bi-check-circle"></i> Simpan
          </button>
        </div>

      </form>
    </div>
  </div>
</div>