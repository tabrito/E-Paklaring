  <!-- Flash Message -->
  <div class="row">
    <div class="col-lg-8">
      <?php Flasher::flash(); ?>
    </div>
  </div>

<div class="main-content">

<div class="d-flex align-items-center mb-3">

  <div class="flex-fill text-center">
    <h4 class="table-title fw-bold mb-0">
      Profile User
    </h4>
  </div>

</div>

<!-- Daftar Mahasiswa -->
<div class="row">

  <!-- LEFT CARD : PROFILE -->
  <div class="col-lg-6">
    <?php foreach ($data['pro'] as $pro) : ?>
      <div class="card border-0 shadow-sm mb-4 rounded-4">
        <div class="card-body p-4">

          <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="fw-bold mb-0">
              <strong><?= $pro['first_name']; ?> <?= $pro['last_name']; ?></strong>
            </h5>

            <span class="badge btn-tambah px-3 py-2">
              <?= $pro['role']; ?>
            </span>
          </div>

          <hr>

          <div class="row mb-2">
            <div class="col-4 text-muted">NIK</div>
            <div class="col-8 fw-semibold"><?= $pro['nik']; ?></div>
          </div>

          <div class="row mb-2">
            <div class="col-4 text-muted">Username</div>
            <div class="col-8 fw-semibold"><?= $pro['username']; ?></div>
          </div>

          <div class="row mb-2">
            <div class="col-4 text-muted">TTL</div>
            <div class="col-8 fw-semibold"><?= $pro['tempat_lahir']; ?>, <?= date('d F Y', strtotime($pro['tanggal_lahir'])); ?></div>
          </div>

          <div class="row mb-2">
            <div class="col-4 text-muted">Jenis Kelamin</div>
            <div class="col-8 fw-semibold"><?= $pro['jenis_kelamin']; ?></div>
          </div>

          <div class="row mb-2">
            <div class="col-4 text-muted">Jabatan</div>
            <div class="col-8 fw-semibold"><?= $pro['jabatan']; ?></div>
          </div>

          <div class="row mb-2">
            <div class="col-4 text-muted">Departemen</div>
            <div class="col-8 fw-semibold"><?= $pro['departemen']; ?></div>
          </div>

          <div class="row mb-2">
            <div class="col-4 text-muted">Instansi</div>
            <div class="col-8 fw-semibold"><?= $pro['instansi']; ?></div>
          </div>

          <div class="row mb-2">
            <div class="col-4 text-muted">Tanggal Masuk</div>
            <div class="col-8 fw-semibold"><?= date('d F Y', strtotime($pro['tanggal_masuk'])); ?></div>
          </div>

          <div class="row mb-2">
            <div class="col-4 text-muted">Tanggal Resign</div>
            <div class="col-8 fw-semibold"><?= date('d F Y', strtotime($pro['tanggal_resign'])); ?></div>
          </div>

          <div class="row mb-2">
            <div class="col-4 text-muted">Tanggal Keluar</div>
            <div class="col-8 fw-semibold"><?= date('d F Y', strtotime($pro['tanggal_keluar'])); ?></div>
          </div>

          <div class="row">
            <div class="col-4 text-muted">Status</div>
            <div class="col-8">
              <?php if ($pro['status'] == 'Active') : ?>
                <span class="badge btn-approve px-3 py-2">Active</span>
              <?php else : ?>
                <span class="badge btn-reject px-3 py-2">Non-active</span>
              <?php endif; ?>
            </div>
          </div>

        </div>
      </div>
    <?php endforeach; ?>
  </div>

  <!-- RIGHT CARD : CHANGE PASSWORD -->
  <div class="col-lg-6">
    <div class="card border-0 shadow-sm mb-4 rounded-4">
      <div class="card-body p-4">

        <h5 class="fw-bold mb-3 text-center"><strong>Change Password</strong></h5>
        <hr>

        <form action="<?= BASEURL; ?>/users/changePassword" method="post">

          <div class="mb-3">
            <label class="form-label">Current Password</label>
            <input type="password" name="current_password" class="form-control" required>
          </div>

          <div class="mb-3">
            <label class="form-label">New Password</label>
            <input type="password" name="new_password" class="form-control" required>
          </div>

          <div class="mb-3">
            <label class="form-label">Confirm New Password</label>
            <input type="password" name="confirm_password" class="form-control" required>
          </div>

          <button type="submit" class="btn btn-ubah w-100 rounded-3">
            Update Password
          </button>

        </form>

      </div>
    </div>
  </div>

</div>

</div>

</div>

<!-- Modal Form -->
<div class="modal fade" id="modalTambah" tabindex="-1" role="dialog" aria-labelledby="formModalTambah" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content shadow rounded-lg">

      <!-- Header -->
      <div class="modal-header bg-modal text-white">
        <h5 class="modal-title w-100 text-center" id="formModalTambah">
          Tambah Users
        </h5>
      </div>

      <!-- Form -->
      <form action="<?= BASEURL; ?>/users/tambah"
      method="post">

        <div class="modal-body">

          <input type="hidden" name="id" id="id">
          <input type="hidden" name="id_barang" id="id_barang">
          <input type="hidden" name="foto_lama" id="foto_lama">

          <!-- Nama Barang -->

          <!-- Kategori -->
          <div class="form-group d-flex">
            <label style="width: 150px" class="label-modal" for="kategori"><strong>Pilih User</strong></label>
            <select class="form-control" 
                    id="kategori" 
                    name="kategori" required>
              <option id="id_choosen" value=""></option>
              <option value="">-- Approver --</option>
              <?php foreach ($data['app'] as $app) : ?>
                <option value="<?= $app['nik']; ?>">
                  <?= $app['first_name']; ?> <?= $app['last_name']; ?>
                </option>
              <?php endforeach; ?>

              <option value="">-- Karyawan --</option>
              <?php foreach ($data['kar'] as $kar) : ?>
                <option value="<?= $kar['nik']; ?>">
                  <?= $kar['first_name']; ?> <?= $kar['last_name']; ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Username -->
          <div class="form-group d-flex mb-3">
            <label style="width: 150px" class="label-modal">
              <strong>Username</strong>
            </label>
            <input type="text" 
                  class="form-control" 
                  name="username" 
                  placeholder="Masukkan username"
                  id="username"
                  required>
          </div>

          <!-- Password -->
          <div class="form-group d-flex mb-3">
            <label style="width: 150px" class="label-modal">
              <strong>Password</strong>
            </label>
            <input type="password" 
                  class="form-control" 
                  name="password" 
                  placeholder="Masukkan password"
                  id="password"
                  required>
          </div>

          <input type="hidden" name="id_user" id="id_user">

          <!-- Role -->
          <div class="form-group d-flex mb-3">
            <label style="width: 150px" class="label-modal">
              <strong>Role</strong>
            </label>
            <select class="form-control" name="role" id="role" required>
              <option value="">-- Pilih Role --</option>
              <option value="HRD">HRD</option>
              <option value="Supervisor">Supervisor</option>
              <option value="Karyawan">Karyawan</option>
            </select>
          </div>

          <!-- Status -->
          <div class="form-group d-flex mb-3">
            <label style="width: 150px" class="label-modal">
              <strong>Status</strong>
            </label>
            <select class="form-control" name="status" id="status" required>
              <option value="">-- Pilih Status --</option>
              <option value="Active">Active</option>
              <option value="Non-active">Non-active</option>
            </select>
          </div>

        </div>

        <!-- Footer -->
        <div class="modal-footer">
          <button type="button" 
                  class="btn btn-secondary" 
                  data-dismiss="modal">
            Batal
          </button>

          <button type="submit" 
                  class="btn btn-simpan">
            Simpan
          </button>
        </div>

      </form>
    </div>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {

  const modal = document.getElementById("modalTambah");
  const form = modal.querySelector("form");

  document.querySelectorAll(".btn-edit").forEach(button => {
    button.addEventListener("click", function () {

      // Ambil data
      const id = this.getAttribute("data-id");
      const nik = this.getAttribute("data-nik");
      const kategori = this.getAttribute("data-kategori");
      const fullname = this.getAttribute("data-fullname");
      const username = this.getAttribute("data-username");
      const role = this.getAttribute("data-role");
      const status = this.getAttribute("data-status");

      // Isi form
      document.getElementById("id_choosen").value = nik;
      document.getElementById("id_choosen").textContent = fullname;

      document.getElementById("id_user").value = id;
      document.getElementById("kategori").value = kategori;
      document.getElementById("username").value = username;
      document.getElementById("role").value = role;
      document.getElementById("status").value = status;

      // Password kosongkan saat edit
      document.getElementById("password").value = "";
      document.getElementById("password").removeAttribute("required");

      // Ganti Judul Modal
      document.getElementById("formModalTambah").innerText = "Edit Users";

      // Ganti Action Form
      form.action = "<?= BASEURL; ?>/users/update";
    });
  });

});
</script>