  <!-- Flash Message -->
  <div class="row">
    <div class="col-lg-8">
      <?php Flasher::flash(); ?>
    </div>
  </div>

<div class="main-content">
<div class="d-flex align-items-center mb-3">
  <div>
    <a href="#" 
      class="btn btn-ubah px-3"
      data-bs-toggle="modal" 
      data-bs-target="#modalTambah">
      Tambah Karyawan
    </a>
  </div>

  <div class="flex-fill text-center">
    <h4 class="table-title fw-bold mb-0">
      Data Karyawan
    </h4>
  </div>

    <div>
    <form action="<?= BASEURL; ?>/karyawan/importExcel" 
          method="post" 
          enctype="multipart/form-data"
          id="formImport">

      <input type="file" 
            name="file_excel" 
            id="file_excel"
            accept=".xls,.xlsx"
            style="display:none"
            onchange="document.getElementById('formImport').submit()">

      <button type="button"
              class="btn btn-tambah px-3 ml-2"
              onclick="document.getElementById('file_excel').click()">
        Import Excel
      </button>

    </form>
  </div>
    <div>
  <a href="<?= BASEURL; ?>/karyawan/downloadTemplate" 
    class="btn btn-tambah px-3 ml-2">
    Download Template
  </a>
  </div>

</div>

<!-- Daftar Mahasiswa -->
<div class="row">
  <div class="col-12">
    <div class="" style="height: 360px;">
      <table class="table table-bordered mb-0" style="font-size: 14px;">
        <thead class="table-head text-center align-middle">
          <tr>
            <th>No</th>
            <th>NIK</th>
            <th>Nama Karyawan</th>
            <th>Tanggal Lahir</th>
            <th>Jabatan</th>
            <th>Departemen</th>
            <th>Instansi</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php $no = 1; 
          ?>
          <?php foreach ($data['kar'] as $pak) : 
            ?>
            <tr class="<?= $rowClass; ?>">
              <td class="text-center"><?= $no++; ?></td>
              <td><?= $pak['nik']; ?></td>
              <td><?= $pak['first_name']; ?> <?= $pak['last_name']; ?></td>
              <td>
                <?= !empty($pak['tanggal_lahir']) 
                    ? date('d/m/Y', strtotime($pak['tanggal_lahir'])) 
                    : '-' ?>
              </td>
              <td><?= $pak['jabatan']; ?></td>
              <td><?= $pak['departemen']; ?></td>
              <td><?= $pak['instansi']; ?></td>
              <td><?= $pak['status']; ?></td>
              <td class="text-center">
                <a href="#" 
                  class="btn btn-tambah"
                  id="btn-edit-karyawan"
                  data-bs-toggle="modal" 
                  data-bs-target="#modalTambah"

                  data-nik="<?= $pak['nik']; ?>"
                  data-first="<?= $pak['first_name']; ?>"
                  data-last="<?= $pak['last_name']; ?>"
                  data-jk="<?= $pak['jenis_kelamin']; ?>"
                  data-tempat="<?= $pak['tempat_lahir']; ?>"
                  data-tgl="<?= $pak['tanggal_lahir']; ?>"
                  data-masuk="<?= $pak['tanggal_masuk']; ?>"
                  data-inst="<?= $pak['id_instansi']; ?>"
                  data-dept="<?= $pak['id_departemen']; ?>"
                  data-jabatan="<?= $pak['jabatan']; ?>"
                  data-resign="<?= $pak['tanggal_resign']; ?>"
                  data-keluar="<?= $pak['tanggal_keluar']; ?>">

                  Edit
                </a>
                <a href="<?= BASEURL; ?>/karyawan/delete/<?= $pak['nik']; ?>" 
                  class="btn btn-sm btn-hapus"
                  onclick="return confirm('Yakin ingin menghapus?')">
                  Delete
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

</div>

</div>

<!-- Modal Form -->
<div class="modal fade" id="modalTambah" tabindex="-1" role="dialog" aria-labelledby="formModalTambah" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content shadow rounded-lg">

      <!-- Header -->
      <div class="modal-header bg-modal text-white">
        <h5 class="modal-title w-100 text-center" id="formModalTambah">
          Tambah Karyawan
        </h5>
      </div>

        <!-- Form Tambah Karyawan -->
        <form action="<?= BASEURL; ?>/karyawan/tambah" method="post">

          <div class="modal-body">

            <!-- NIK -->
            <div class="form-group d-flex mb-3">
              <label style="width:150px"><strong>NIK</strong></label>
              <input type="text" name="nik" class="form-control" required>
              <input type="hidden" name="nik_lama" id="nik_lama">
            </div>

            <!-- Nama Depan -->
            <div class="form-group d-flex mb-3">
              <label style="width:150px"><strong>First Name</strong></label>
              <input type="text" name="first_name" class="form-control" required>
            </div>

            <!-- Nama Belakang -->
            <div class="form-group d-flex mb-3">
              <label style="width:150px"><strong>Last Name</strong></label>
              <input type="text" name="last_name" class="form-control" required>
            </div>

            <!-- Jenis Kelamin -->
            <div class="form-group d-flex mb-3">
              <label style="width:150px"><strong>Jenis Kelamin</strong></label>
              <select name="jenis_kelamin" class="form-control" required>
                <option value="">-- Pilih --</option>
                <option value="Laki-laki">Laki-laki</option>
                <option value="Perempuan">Perempuan</option>
              </select>
            </div>

            <!-- Tempat Lahir -->
            <div class="form-group d-flex mb-3">
              <label style="width:150px"><strong>Tempat Lahir</strong></label>
              <input type="text" name="tempat_lahir" class="form-control" required>
            </div>

            <!-- Tanggal Lahir -->
            <div class="form-group d-flex mb-3">
              <label style="width:150px"><strong>Tanggal Lahir</strong></label>
              <input type="date" name="tanggal_lahir" class="form-control" required>
            </div>

            <!-- Tanggal Masuk -->
            <div class="form-group d-flex mb-3">
              <label style="width:150px"><strong>Tanggal Masuk</strong></label>
              <input type="date" name="tanggal_masuk" class="form-control" required>
            </div>

            <!-- Instansi -->
            <div class="form-group d-flex mb-3">
              <label style="width:150px"><strong>Instansi</strong></label>
              <select id="id_instansi" class="form-control" required>
                <option value="">-- Pilih Instansi --</option>
                <?php foreach ($data['ins'] as $i) : ?>
                  <option value="<?= $i['id_instansi']; ?>">
                    <?= $i['instansi']; ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>

            <!-- Departemen -->
            <div class="form-group d-flex mb-3">
              <label style="width:150px"><strong>Departemen</strong></label>
              <select name="id_departemen" id="id_departemen" class="form-control" required>
                <option value="">-- Pilih Departemen --</option>
              </select>
            </div>

            <!-- Jabatan -->
            <div class="form-group d-flex mb-3">
              <label style="width:150px"><strong>Jabatan</strong></label>
              <input type="text" name="jabatan" class="form-control" required>
            </div>

            <!-- Tanggal Resign -->
            <div class="form-group d-flex mb-3">
              <label style="width:150px"><strong>Tanggal Resign</strong></label>
              <input type="date" name="tanggal_resign" class="form-control">
            </div>

            <!-- Tanggal Keluar -->
            <div class="form-group d-flex mb-3">
              <label style="width:150px"><strong>Tanggal Keluar</strong></label>
              <input type="date" name="tanggal_keluar" class="form-control">
            </div>

          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
              Batal
            </button>

            <button type="submit" class="btn btn-simpan">
              Simpan
            </button>
          </div>

        </form>
    </div>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {

  const modal = document.getElementById("modalTambah");
  const form = modal.querySelector("form");

  document.querySelectorAll("#btn-edit-karyawan").forEach(button => {
    button.addEventListener("click", function() {

      // Ambil data
      const nik = this.dataset.nik;

      document.getElementById("nik_lama").value = nik;
      document.querySelector("[name='nik']").value = nik;
      document.querySelector("[name='first_name']").value = this.dataset.first;
      document.querySelector("[name='last_name']").value = this.dataset.last;
      document.querySelector("[name='jenis_kelamin']").value = this.dataset.jk;
      document.querySelector("[name='tempat_lahir']").value = this.dataset.tempat;
      document.querySelector("[name='tanggal_lahir']").value = this.dataset.tgl;
      document.querySelector("[name='tanggal_masuk']").value = this.dataset.masuk;
      document.querySelector("#id_instansi").value = this.dataset.inst;

      let departemenSelect = document.getElementById("id_departemen");

      // simpan dulu dataset
      let idDept = this.dataset.dept;

      departemenSelect.innerHTML = '<option value="">Loading...</option>';

      fetch("<?= BASEURL; ?>/approver/getDepartemen/" + this.dataset.inst)
        .then(response => response.json())
        .then(data => {

          departemenSelect.innerHTML = '<option value="">-- Pilih Departemen --</option>';

          data.forEach(function(dep) {

            let selected = (dep.id_departemen == idDept) ? "selected" : "";

            departemenSelect.innerHTML += 
              `<option value="${dep.id_departemen}" ${selected}>
                ${dep.departemen}
              </option>`;
          });

        });

      document.querySelector("#id_departemen").value = this.dataset.dept;      
      document.querySelector("[name='jabatan']").value = this.dataset.jabatan;
      document.querySelector("[name='tanggal_resign']").value = this.dataset.resign;
      document.querySelector("[name='tanggal_keluar']").value = this.dataset.keluar;

      // Ganti Judul
      document.getElementById("formModalTambah").innerText = "Edit Karyawan";

      // Ganti Action
      form.action = "<?= BASEURL; ?>/karyawan/update";

    });
  });

});

document.getElementById("id_instansi").addEventListener("change", function() {

  let id_instansi = this.value;
  let departemenSelect = document.getElementById("id_departemen");

  departemenSelect.innerHTML = '<option value="">Loading...</option>';

  fetch("<?= BASEURL; ?>/karyawan/getDepartemen/" + id_instansi)
    .then(response => response.json())
    .then(data => {

      departemenSelect.innerHTML = '<option value="">-- Pilih Departemen --</option>';

      data.forEach(function(dep) {
        departemenSelect.innerHTML += 
          `<option value="${dep.id_departemen}">
            ${dep.departemen}
          </option>`;
      });

    });
});
</script>