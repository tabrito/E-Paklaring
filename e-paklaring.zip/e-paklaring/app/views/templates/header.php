<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Halaman <?= $data['judul']; ?></title>

  <!-- Favicon / Logo Aplikasi -->
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
  <link rel="icon" 
        href="<?= BASEURL; ?>/img/logo_inventory.png">

  <link rel="stylesheet" href="<?= BASEURL; ?>/css/bootstrap.css">
  <link rel="stylesheet" href="<?= BASEURL; ?>/css/style.css">
</head>


<body style="height: 300px; overflow-y: auto; overflow-x: hidden; scrollbar-width: none; -ms-overflow-style: none;">
<!-- Tambahkan Font Awesome di head -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<div class="sidebar" 
     style="width: 230px; height: 100vh; overflow-y: auto; scrollbar-width: none; -ms-overflow-style: none;">

  <a class="navbar-brand d-block mb-3" href="<?= BASEURL; ?>">
    e-paklaring
  </a>

  <ul class="nav flex-column">

    <li class="nav-item">
      <a class="nav-link" href="<?= BASEURL; ?>">Dashboard</a>
    </li>

    <?php if($_SESSION['user']['role'] == 'Karyawan' OR $_SESSION['user']['role'] == 'HRD' OR $_SESSION['user']['role'] == 'Superadmin') : ?>
    <li class="nav-item">
      <a class="nav-link" href="<?= BASEURL; ?>/request">Request</a>
    </li>
    <?php endif ?>

    <?php if($_SESSION['user']['role'] == 'Karyawan' OR $_SESSION['user']['role'] == 'Superadmin') : ?>
    <li class="nav-item">
      <a class="nav-link" href="<?= BASEURL; ?>/exit_clear">Exit Clear</a>
    </li>
    <?php endif ?>

    <?php if($_SESSION['user']['role'] == 'HRD' OR $_SESSION['user']['role'] == 'Supervisor' OR $_SESSION['user']['role'] == 'Superadmin') : ?>
    <li class="nav-item">
      <a class="nav-link" href="<?= BASEURL; ?>/approval">Approval</a>
    </li>
    <?php endif ?>

    <?php if($_SESSION['user']['role'] == 'Karyawan' OR $_SESSION['user']['role'] == 'HRD' OR $_SESSION['user']['role'] == 'Superadmin') : ?>
    <li class="nav-item">
      <a class="nav-link" href="<?= BASEURL; ?>/paklaring">Paklaring</a>
    </li>
    <?php endif ?>

    <?php if($_SESSION['user']['role'] == 'HRD' OR $_SESSION['user']['role'] == 'Superadmin') : ?>
    <li class="nav-item">
      <a class="nav-link" href="<?= BASEURL; ?>/users">Users</a>
    </li>
    <?php endif ?>

    <?php if($_SESSION['user']['role'] == 'HRD' OR $_SESSION['user']['role'] == 'Superadmin') : ?>
    <!-- DROPDOWN DATA -->
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle"
         style="color: #fe7b00; cursor: pointer;"
         role="button"
         data-bs-toggle="dropdown"
         aria-expanded="false">
        Data
      </a>

      <ul class="dropdown-menu ml-3">
        <li>
          <a class="dropdown-item" href="<?= BASEURL; ?>/karyawan">
            Karyawan
          </a>
        </li>
        <li>
          <a class="dropdown-item" href="<?= BASEURL; ?>/approver">
            Approver
          </a>
        </li>
        <li>
          <a class="dropdown-item" href="<?= BASEURL; ?>/instansi">
            Instansi
          </a>
        </li>
      </ul>
    </li>
    <?php endif ?>

  </ul>
</div>
<div class="container mt-4 p-0">
<!-- Top Navbar -->
<div class="top-navbar d-flex align-items-center justify-content-between p-3">

  <!-- Nama Instansi -->
  <div class="instansi-name fw-bold">
    PT. Sinergi Global Service
  </div>

  <!-- Search Tengah -->
  <div class="flex-grow-1 px-4">
      <form action="<?= BASEURL; ?>/request/search" method="POST">
    <div class="position-relative mx-auto" style="max-width: 400px;">
      <input 
        type="text" 
        class="form-control form-search ps-4 pe-5" 
        name="keyword"
        placeholder="Search..."
      >
      <i class="fas fa-search position-absolute"
         style="right: 15px; top: 50%; transform: translateY(-50%); color: #fff;">
      </i>
    </div>
      </form>
  </div>

  <!-- Nama User -->
<div class="dropdown">
  <div class="user-name fw-semibold dropdown-toggle d-flex align-items-center"
       role="button"
       data-bs-toggle="dropdown"
       aria-expanded="false"
       style="cursor:pointer;">
       
    <?= $_SESSION['user']['first_name']; ?> 
    <i class="fas fa-user ml-2"></i>
  </div>


  <ul class="dropdown-menu dropdown-menu-end shadow">
    <li>
      <a class="dropdown-item" href="<?= BASEURL; ?>/profile">
        <i class="fas fa-user-circle me-2"></i> Profile
      </a>
    </li>
    <li><hr class="dropdown-divider"></li>
    <li>
      <a class="dropdown-item text-danger" href="<?= BASEURL; ?>/login/logout">
        <i class="fas fa-sign-out-alt me-2"></i> Logout
      </a>
    </li>
  </ul>
</div>

</div>