  <!-- Flash Message -->
  <div class="row">
    <div class="col-lg-8">
      <?php Flasher::flash(); ?>
    </div>
  </div>

<div class="main-content">
<div class="d-flex align-items-center mb-3">

  <div class="flex-fill text-center" style="width: 300px; margin-left: 100px;" >
    <h4 class="table-title fw-bold mb-0">Data Exit Clear</h4>
  </div>

  <div>
    <a href="<?= BASEURL; ?>/approval/cetak_pdf/<?= $data['exi']['nik']; ?>/<?= $data['exi']['id_departemen']; ?>" 
      class="btn btn-ubah px-3 ml-2">
      Print PDF
    </a>
  </div>

</div>

<!-- Daftar Mahasiswa -->
<div class="row">
  <div class="col-12">
    <div class="" style="height: 490px; overflow-y: auto;">
        <!-- TABLE INTERVIEW -->
      <table class="table table-bordered mb-0" style="font-size: 14px;">
        <thead class="table-head text-center align-middle">
          <tr>
            <th colspan="3" style="background-color: #fff; color: #333; font-size: 16px;">
              <?= $data['exi']['first_name']; ?> <?= $data['exi']['last_name']; ?>
            </th>
          </tr>
          <tr>
            <th width="20%">Exit Clear</th>
            <th width="40%">Pertanyaan</th>
            <th width="40">Jawaban</th>
          </tr>
        </thead>
        <tbody>
        <tr>
          <td rowspan="4" class="text-center">Interview</td>
          <td>Mengapa Saudara mengundurkan diri dari PT Sinergi Global Servis?</td>
          <td>
            <?= $data['exi']['alasan']; ?>
          </td>
        </tr>

        <tr>
          <td>Seberapa puas Anda dengan pekerjaan Anda saat ini?</td>
          <td>
            <?= $data['exi']['kepuasan']; ?>
          </td>
        </tr>

        <tr>
          <td>Hal apa yang paling Anda apresiasi selama bekerja di perusahaan ini?</td>
          <td>
            <?= $data['exi']['apresiasi']; ?>
          </td>
        </tr>

        <tr>
          <td>Apa saran Anda agar perusahaan dapat menjadi tempat kerja yang lebih baik?</td>
          <td>
            <?= $data['exi']['saran']; ?>
          </td>
        </tr>

        <tr>
          <td colspan="3" style="background-color: #535353; height: 3px; padding: 0;"></td>
        </tr>

        <tr>
          <td rowspan="4" class="text-center">Aset</td>
          <td>Sudahkah Saudara mengembalikan Seragam?</td>
          <td>
            <?= $data['exi']['seragam']; ?>
          </td>
        </tr>

        <tr>
          <td>Sudahkah Saudara mengembalikan ID Card?</td>
          <td>
            <?= $data['exi']['id_card']; ?>
          </td>
        </tr>

        <tr>
          <td>Sudahkah Saudara mengembalikan Laptop kantor?</td>
          <td>
            <?= $data['exi']['laptop']; ?>
          </td>
        </tr>

        <tr>
          <td>Sudahkah Saudara melakukan serah terima file kerja?</td>
          <td>
            <?= $data['exi']['file_kerja']; ?>
          </td>
        </tr>

        
        <tr>
          <td colspan="3" style="background-color: #535353; height: 3px; padding: 0;"></td>
        </tr>

        <tr>
          <td rowspan="4" class="text-center">Administrasi</td>
          <td>Berapa besar gaji terakhir yang Anda terima?</td>
          <td>
            <?= 'Rp ' . number_format($data['exi']['gaji_terakhir'], 0, ',', '.'); ?>
          </td>
        </tr>

        <tr>
          <td>Berapa jumlah sisa cuti tahunan yang masih Anda miliki?</td>
          <td>
            <?= $data['exi']['sisa_cuti']; ?> Hari
          </td>
        </tr>
        </tbody>
        </table>
          <?php if($_SESSION['user']['role'] == "HRD") : ?>
          <div id="appr_hrd" data-val="<?= $data['exi']['approval_hr']; ?>"></div>
          <?php elseif($_SESSION['user']['role'] == "Supervisor") : ?>
          <div id="appr_hrd" data-val="<?= $data['exi']['approval_spv']; ?>"></div>
          <?php endif; ?>
          <div class="d-none text-center justify-content-center mt-3 form-approval">
          <?php if($_SESSION['user']['role'] == 'HRD') : ?>
          <a href="<?= BASEURL; ?>/approval/approveHRD/<?= $data['exi']['id_exit_clear']; ?>"
            class="btn btn-approve px-4" style="width: 100px;">
            Approve
          </a>
          <?php elseif($_SESSION['user']['role'] == 'Supervisor') : ?>
          <a href="<?= BASEURL; ?>/approval/approveSPV/<?= $data['exi']['id_exit_clear']; ?>"
            class="btn btn-approve px-4" style="width: 100px;">
            Approve
          </a>
          <?php endif ?>
          <div style="height: 10px;"></div>
          <?php if($_SESSION['user']['role'] == 'HRD') : ?>
          <a href="<?= BASEURL; ?>/approval/rejectHRD/<?= $data['exi']['id_exit_clear']; ?>"
            class="btn btn-reject px-4" style="width: 100px;">
            Reject
          </a>
          <?php elseif($_SESSION['user']['role'] == 'Supervisor') : ?>
          <a href="<?= BASEURL; ?>/approval/rejectSPV/<?= $data['exi']['id_exit_clear']; ?>"
            class="btn btn-reject px-4" style="width: 100px;">
            Reject
          </a>
          <?php endif ?>
        </div>
        <div class="text-center mt-3 form-edit-approval">
          <?php if($_SESSION['user']['role'] == "Supervisor") : ?>
            <?php if($data['stat']['approval_spv'] == "Approved") : ?>
              <a href="#"
                class="btn btn-edit-approval btn-approve-ot" style="width: 120px;">
                <?= $data['stat']['approval_spv']; ?>
                <i class="fas fa-pen mx-2"></i>
              </a>
            <?php elseif($data['stat']['approval_spv'] == "Rejected") : ?>
              <a href="#"
                class="btn btn-edit-approval btn-reject-ot" style="width: 120px;">
                <?= $data['stat']['approval_spv']; ?>
                <i class="fas fa-pen mx-2"></i>
              </a>
            <?php endif ?>
          <?php elseif($_SESSION['user']['role'] == "HRD") : ?>
            <?php if($data['stat']['approval_hr'] == "Approved") : ?>
              <a href="#"
                class="btn btn-edit-approval btn-approve-ot" style="width: 120px;">
                <?= $data['stat']['approval_hr']; ?>
                <i class="fas fa-pen mx-2"></i>
              </a>
            <?php elseif($data['stat']['approval_hr'] == "Rejected") : ?>
              <a href="#"
                class="btn btn-edit-approval btn-reject-ot" style="width: 120px;">
                <?= $data['stat']['approval_hr']; ?>
                <i class="fas fa-pen mx-2"></i>
              </a>
            <?php endif ?>
          <?php endif ?>
        </div>
      </div>
  </div>
</div>

</div>

</div>

<script>
document.addEventListener("DOMContentLoaded", function () {

  const btnEdit = document.querySelectorAll(".btn-edit-approval");
  const formApproval = document.querySelector(".form-approval");
  const formEdit = document.querySelector(".form-edit-approval");

  btnEdit.forEach(function(btn){
    btn.addEventListener("click", function(e){
      e.preventDefault();

      formApproval.classList.remove("d-none");
      formEdit.classList.add("d-none");
    });
  });

  let apprHrd = document.getElementById("appr_hrd").dataset.val;

  if(apprHrd) {
  } else {
    formApproval.classList.remove("d-none");
  }

});
</script>