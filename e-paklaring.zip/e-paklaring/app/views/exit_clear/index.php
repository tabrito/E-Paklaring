  <!-- Flash Message -->
  <div class="row">
    <div class="col-lg-8">
      <?php Flasher::flash(); ?>
    </div>
  </div>

<div class="main-content">
<div class="d-flex align-items-center mb-3">

  <div class="flex-fill text-center" style="margin-left: 110px;">
    <h4 class="table-title fw-bold mb-0">
      Exit Clear
    </h4>
  </div>

    <div>
    <a href="<?= BASEURL; ?>/exit_clear/cetak_pdf/<?= $data['exi']['id_departemen']; ?>" 
      class="btn btn-ubah px-3 ml-2">
      Print PDF
    </a>
  </div>

</div>

<!-- Daftar Mahasiswa -->
<div class="row">
  <div class="col-12">
    <div style="height: 480px; overflow-y: auto;">
      <!-- SECTION 1 -->
      <div class="section" id="section1">
        <!-- TABLE INTERVIEW -->
      <table class="table table-bordered mb-0" style="font-size: 14px;">
        <thead class="table-head text-center align-middle">
          <tr>
            <th colspan="2" style="background-color: #fff; color: #333; font-size: 16px;">
              Interview
            </th>
          </tr>
          <tr>
            <th width="50%">Pertanyaan</th>
            <th width="50%">Jawaban</th>
          </tr>
        </thead>
        <tbody>
        <?php if($data['exi']) : ?>
        <?php if($data['exi']['id_interview']) : ?>
        <form action="<?= BASEURL; ?>/exit_clear/ubahInterview" method="post">
        <?php else : ?>
        <form action="<?= BASEURL; ?>/exit_clear/tambahInterview" method="post">
        <?php endif ?>
        <?php else : ?>
        <form action="<?= BASEURL; ?>/exit_clear/tambahInterview" method="post">
        <?php endif ?>
        <tr>
          <input type="hidden" name="id_exit_clear" value="<?= $data['exi']['id_exit']; ?>">
          <input type="hidden" name="id_interview" value="<?= $data['exi']['id_interview']; ?>">
          <td>Mengapa Saudara mengundurkan diri dari PT Sinergi Global Servis?</td>
          <td>
            <span id="alasanText">
              <?= !empty($data['exi']['alasan']) 
                  ? htmlspecialchars($data['exi']['alasan']) 
                  : '' ?>
            </span>
            <textarea id="alasanInput" name="alasan" class="p-1 m-0 d-none"
                      style="width: 100%;" rows="5"
                      placeholder="Tuliskan alasan pengunduran diri Anda secara jelas"></textarea>
          </td>
        </tr>

        <tr>
          <td>Seberapa puas Anda dengan pekerjaan Anda saat ini?</td>
          <td>
            <span id="puasText">
              <?= !empty($data['exi']['kepuasan']) 
                  ? htmlspecialchars($data['exi']['kepuasan']) 
                  : '' ?>
            </span>
            <select id="puasInput" name="kepuasan" class="p-1 m-0 d-none" style="width: 100%;">
              <option value="" disabled selected>Pilih tingkat kepuasan</option>
              <option value="Sangat Tidak Puas">Sangat Tidak Puas</option>
              <option value="Tidak Puas">Tidak Puas</option>
              <option value="Cukup Puas">Cukup Puas</option>
              <option value="Puas">Puas</option>
              <option value="Sangat Puas">Sangat Puas</option>
            </select>
          </td>
        </tr>

        <tr>
          <td>Hal apa yang paling Anda apresiasi selama bekerja di perusahaan ini?</td>
          <td>
            <span id="apresiasiText">
              <?= !empty($data['exi']['apresiasi']) 
                  ? htmlspecialchars($data['exi']['apresiasi']) 
                  : '' ?>
            </span>
          <textarea id="apresiasiInput" name="apresiasi" class="p-1 m-0 d-none"
                      style="width: 100%;" rows="5"
                      placeholder="Contoh: dukungan atasan, budaya kerja, dll."></textarea>
          </td>
        </tr>

        <tr>
          <td>Apa saran Anda agar perusahaan dapat menjadi tempat kerja yang lebih baik?</td>
          <td>
            <span id="saranText">
              <?= !empty($data['exi']['saran']) 
                  ? htmlspecialchars($data['exi']['saran']) 
                  : '' ?>
            </span>
          <textarea id="saranInput" name="saran" class="p-1 m-0 d-none"
                      style="width: 100%;" rows="5"
                      placeholder="Berikan saran yang konstruktif"></textarea>
          </td>
        </tr>

        <tr>
          <td colspan="2">
            <div class="d-flex justify-content-center">
              <button type="submit" id="saveInterview" class="btn btn-ubah px-4">Save</button>
              <div style="width: 10px;"></div>
              <button type="button" id="editInterview" class="btn btn-tambah px-4">Edit</button>
              <div style="width: 10px;"></div>
              <a href="<?= BASEURL; ?>/exit_clear/resetInterview/<?= $data['exi']['id_interview']; ?>"
                id="resetInterview"
                class="btn btn-hapus px-4"
                onclick="return confirm('Reset data interview?')">
                Reset
              </a>
            </div>
          </td>
        </tr>
        </form>
        </tbody>
        </table>
      </div>
        <!-- SECTION 2 -->
        <div class="section d-none" id="section2">
          <!-- TABLE ASSET -->
          <table class="table table-bordered mb-0" style="font-size: 14px;">
          <thead class="table-head text-center align-middle">
            <tr>
              <th colspan="2" style="background-color: #fff; color: #333; font-size: 16px;">
                Asset
              </th>
            </tr>
            <tr>
              <th width="50%">Pertanyaan</th>
              <th width="50%">Jawaban</th>
            </tr>
          </thead>

          <tbody>
          <?php if($data['exi']) : ?>
          <?php if($data['exi']['id_aset']) : ?>
          <form action="<?= BASEURL; ?>/exit_clear/ubahAset" method="post">
          <?php else : ?>
          <form action="<?= BASEURL; ?>/exit_clear/tambahAset" method="post">
          <?php endif ?>
          <?php else : ?>
          <form action="<?= BASEURL; ?>/exit_clear/tambahAset" method="post">
          <?php endif ?>
            <!-- SERAGAM -->
            <tr>
              <input type="hidden" name="id_exit_clear" value="<?= $data['exi']['id_exit']; ?>">
              <input type="hidden" name="id_aset" value="<?= $data['exi']['id_aset']; ?>">
              <td>Sudahkah Saudara mengembalikan Seragam?</td>
              <td>
                <span id="seragamText">
                  <?= !empty($data['exi']['seragam']) 
                      ? htmlspecialchars($data['exi']['seragam']) 
                      : '' ?>
                </span>
                <div id="seragamInput" class="d-none">
                  <label><input type="radio" name="seragam" value="Sudah"> Sudah</label>
                  <label class="ms-3"><input type="radio" name="seragam" value="Belum"> Belum</label>
                </div>
              </td>
            </tr>

            <!-- ID CARD -->
            <tr>
              <td>Sudahkah Saudara mengembalikan ID Card?</td>
              <td>
                <span id="idcardText">
                  <?= !empty($data['exi']['id_card']) 
                      ? htmlspecialchars($data['exi']['id_card']) 
                      : '' ?>
                </span>
                <div id="idcardInput" class="d-none">
                  <label><input type="radio" name="idcard" value="Sudah"> Sudah</label>
                  <label class="ms-3"><input type="radio" name="idcard" value="Belum"> Belum</label>
                </div>
              </td>
            </tr>

            <!-- LAPTOP -->
            <tr>
              <td>Sudahkah Saudara mengembalikan Laptop kantor?</td>
              <td>
                <span id="laptopText">
                  <?= !empty($data['exi']['laptop']) 
                      ? htmlspecialchars($data['exi']['laptop']) 
                      : '' ?>
                </span>
                <div id="laptopInput" class="d-none">
                  <label><input type="radio" name="laptop" value="Sudah"> Sudah</label>
                  <label class="ms-3"><input type="radio" name="laptop" value="Belum"> Belum</label>
                </div>
              </td>
            </tr>

            <!-- SERAH TERIMA -->
            <tr>
              <td>Sudahkah Saudara melakukan serah terima file kerja?</td>
              <td>
                <span id="serahText">
                  <?= !empty($data['exi']['file_kerja']) 
                      ? htmlspecialchars($data['exi']['file_kerja']) 
                      : '' ?>
                </span>
                <div id="serahInput" class="d-none">
                  <label><input type="radio" name="serah" value="Sudah"> Sudah</label>
                  <label class="ms-3"><input type="radio" name="serah" value="Belum"> Belum</label>
                </div>
              </td>
            </tr>

            <!-- BUTTON -->
            <tr>
              <td colspan="2">
                <div class="d-flex justify-content-center gap-2">
                  <button type="submit" id="saveAst" class="btn btn-ubah px-4">Save</button>
                  <div style="width: 10px;"></div>
                  <button type="button" id="editAst" class="btn btn-tambah px-4">Edit</button>
                  <div style="width: 10px;"></div>
                  <a href="<?= BASEURL; ?>/exit_clear/resetAset/<?= $data['exi']['id_aset']; ?>"
                    id="resetAst"
                    class="btn btn-hapus px-4"
                    onclick="return confirm('Reset data aset?')">
                    Reset
                  </a>
                </div>
              </td>
            </tr>
          </form>
          </tbody>
        </table>
        </div>
        <!-- SECTION 3 -->
        <div class="section d-none" id="section3">
          <!-- TABLE ADMINISTRASI -->
          <table class="table table-bordered mb-0" style="font-size: 14px;">
            <thead class="table-head text-center align-middle">
              <tr>
              <th colspan="2" style="background-color: #fff; color: #333; font-size: 16px;">
                Administrasi
              </th>      
              </tr>
              <tr>
                <th width="50%">Pertanyaan</th>
                <th width="50%">Jawaban</th>
              </tr>
            </thead>
            <tbody>
            <?php if($data['exi']) : ?>
            <?php if($data['exi']['id_administrasi']) : ?>
            <form action="<?= BASEURL; ?>/exit_clear/ubahAdmin" method="post">
            <?php else : ?>
            <form action="<?= BASEURL; ?>/exit_clear/tambahAdmin" method="post">
            <?php endif ?>
            <?php else : ?>
            <form action="<?= BASEURL; ?>/exit_clear/tambahAdmin" method="post">
            <?php endif ?>
              <!-- SERAGAM -->
              <tr>
                <input type="hidden" name="id_exit_clear" value="<?= $data['exi']['id_exit']; ?>">
                <input type="hidden" name="id_administrasi" value="<?= $data['exi']['id_administrasi']; ?>">
                <td>Berapa besar gaji terakhir yang Anda terima?</td>
                <td>
                  <span id="gajiText">
                    <?= !empty($data['exi']['gaji_terakhir']) 
                        ? !empty($data['exi']['gaji_terakhir'])
                        ? 'Rp ' . number_format($data['exi']['gaji_terakhir'], 0, ',', '.')
                        : ''
                        : '' ?>
                  </span>
                  <input type="number" 
                        name="gaji"
                        id="gajiInput" 
                        class="p-1 m-0 d-none" 
                        style="width: 100%;" 
                        placeholder="Contoh: Rp 5.000.000">
                </td>
              </tr>

              <tr>
                <td>Berapa jumlah sisa cuti tahunan yang masih Anda miliki?</td>
                <td>
                  <span id="cutiText">
                    <?= !empty($data['exi']['sisa_cuti'])
                        ? $data['exi']['sisa_cuti'] . ' hari'
                        : '' ?>
                  </span>
                  <input type="number" 
                        name="cuti"
                        id="cutiInput"
                        class="p-1 m-0 d-none" 
                        style="width: 100%;" 
                        placeholder="Contoh: 5"
                        min="0">
                </td>
              </tr>
                <tr>
                  <td colspan="2">
                    <div class="d-flex justify-content-center">
                      <button type="submit" id="saveAdm" class="btn btn-ubah px-4">Save</button>
                      <div style="width: 10px;"></div>
                      <button type="button" id="editAdm" class="btn btn-tambah px-4">Edit</button>
                      <div style="width: 10px;"></div>
                      <a href="<?= BASEURL; ?>/exit_clear/resetAdmin/<?= $data['exi']['id_administrasi']; ?>"
                        id="resetAdm"
                        class="btn btn-hapus px-4"
                        onclick="return confirm('Reset data administrasi?')">
                        Reset
                      </a>
                    </div>
                  </td>
                </tr>
            </form>
            </tbody>
          </table>
        </div>
      <!-- NAVIGATION BUTTON -->
      <div class="d-flex justify-content-between mt-5">
        <button class="btn btn-tambah" id="prevBtn">Prev</button>
        <button class="btn btn-tambah" id="nextBtn">Next</button>
      </div>
    </div>
  </div>
</div>
</div>
</div>

<script>
  // =========================
  // ADMINISTRASI
  // =========================
  const gajiInput  = document.getElementById('gajiInput');
  const cutiInput  = document.getElementById('cutiInput');

  const gajiText   = document.getElementById('gajiText');
  const cutiText   = document.getElementById('cutiText');

  const editBtn  = document.getElementById('editAdm');
  const saveBtn  = document.getElementById('saveAdm');
  const resetBtn = document.getElementById('resetAdm');

  // =========================
  // VALIDASI CUTI (ANGKA SAJA)
  // =========================
  cutiInput.addEventListener('input', function() {
    this.value = this.value.replace(/[^0-9]/g, '');
    if (this.value < 0) this.value = 0;
  });

  // =========================
  // EDIT ADMINISTRASI
  // =========================
  editBtn.addEventListener('click', function() {

    gajiInput.classList.remove('d-none');
    cutiInput.classList.remove('d-none');

    gajiText.classList.add('d-none');
    cutiText.classList.add('d-none');

    gajiInput.value = gajiText.innerText === '' ? '' : gajiText.textContent.trim().replace(/[^\d]/g, '');;
    cutiInput.value = cutiText.innerText === '' ? '' : cutiText.textContent.trim().replace(' hari','');
  });

  // =========================
  // SAVE ADMINISTRASI
  // =========================
  saveBtn.addEventListener('click', function() {

    gajiText.innerText = gajiInput.value || '';
    cutiText.innerText = cutiInput.value ? cutiInput.value + ' hari' : '';

    gajiInput.classList.add('d-none');
    cutiInput.classList.add('d-none');

    gajiText.classList.remove('d-none');
    cutiText.classList.remove('d-none');
  });

  // =========================
  // RESET ADMINISTRASI
  // =========================
  resetBtn.addEventListener('click', function() {

      gajiInput.value = '';
      cutiInput.value = '';

      gajiText.innerText = '';
      cutiText.innerText = '';

      gajiInput.classList.add('d-none');
      cutiInput.classList.add('d-none');

      gajiText.classList.remove('d-none');
      cutiText.classList.remove('d-none');
  });

  
  // INTERVIEW
  const editInterview  = document.getElementById('editInterview');
  const saveInterview  = document.getElementById('saveInterview');
  const resetInterview = document.getElementById('resetInterview');

  const alasanText = document.getElementById('alasanText');
  const puasText = document.getElementById('puasText');
  const apresiasiText = document.getElementById('apresiasiText');
  const saranText = document.getElementById('saranText');

  const alasanInput = document.getElementById('alasanInput');
  const puasInput = document.getElementById('puasInput');
  const apresiasiInput = document.getElementById('apresiasiInput');
  const saranInput = document.getElementById('saranInput');

  // EDIT INTERVIEW
  editInterview.addEventListener('click', function() {

    alasanInput.classList.remove('d-none');
    puasInput.classList.remove('d-none');
    apresiasiInput.classList.remove('d-none');
    saranInput.classList.remove('d-none');

    alasanText.classList.add('d-none');
    puasText.classList.add('d-none');
    apresiasiText.classList.add('d-none');
    saranText.classList.add('d-none');

    alasanInput.value = alasanText.innerText === '' ? '' : alasanText.textContent.trim();
    puasInput.value = puasText.innerText === '' ? '' : puasText.textContent.trim();
    apresiasiInput.value = apresiasiText.innerText === '' ? '' : apresiasiText.textContent.trim();
    saranInput.value = saranText.innerText === '' ? '' : saranText.textContent.trim();
  });

  // SAVE INTERVIEW
  saveInterview.addEventListener('click', function() {

    alasanText.innerText = alasanInput.value || '';
    puasText.innerText = puasInput.value || '';
    apresiasiText.innerText = apresiasiInput.value || '';
    saranText.innerText = saranInput.value || '';

    alasanInput.classList.add('d-none');
    puasInput.classList.add('d-none');
    apresiasiInput.classList.add('d-none');
    saranInput.classList.add('d-none');

    alasanText.classList.remove('d-none');
    puasText.classList.remove('d-none');
    apresiasiText.classList.remove('d-none');
    saranText.classList.remove('d-none');
  });

  // RESET INTERVIEW
  resetInterview.addEventListener('click', function() {

      alasanInput.value = '';
      puasInput.value = '';
      apresiasiInput.value = '';
      saranInput.value = '';

      alasanText.innerText = '';
      puasText.innerText = '';
      apresiasiText.innerText = '';
      saranText.innerText = '';

      alasanInput.classList.add('d-none');
      puasInput.classList.add('d-none');
      apresiasiInput.classList.add('d-none');
      saranInput.classList.add('d-none');

      alasanText.classList.remove('d-none');
      puasText.classList.remove('d-none');
      apresiasiText.classList.remove('d-none');
      saranText.classList.remove('d-none');

  });

const editAst = document.getElementById("editAst");
const saveAst = document.getElementById("saveAst");
const resetAst = document.getElementById("resetAst");

// List semua field
const fields = [
  { name: "seragam", text: "seragamText", input: "seragamInput" },
  { name: "idcard", text: "idcardText", input: "idcardInput" },
  { name: "laptop", text: "laptopText", input: "laptopInput" },
  { name: "serah", text: "serahText", input: "serahInput" },
];

// EDIT MODE
editAst.addEventListener("click", function () {

  fields.forEach(field => {

    const textEl = document.getElementById(field.text);
    const inputEl = document.getElementById(field.input);

    textEl.classList.add("d-none");
    inputEl.classList.remove("d-none");

    // 🔥 AMBIL NILAI DARI SPAN
    const value = textEl.textContent.trim();

    if (value !== '') {
      const radios = inputEl.querySelectorAll("input[type='radio']");

      radios.forEach(radio => {
        radio.checked = (radio.value === value);
      });
    }
  });

});

// SAVE MODE
saveAst.addEventListener("click", function () {
  fields.forEach(field => {
    const radios = document.querySelector(`input[name="${field.name}"]:checked`);
    const textElement = document.getElementById(field.text);

    textElement.innerText = radios ? radios.value : "-";

    document.getElementById(field.text).classList.remove("d-none");
    document.getElementById(field.input).classList.add("d-none");
  });
});

// RESET
resetAst.addEventListener("click", function () {
  fields.forEach(field => {

    // Hapus radio terpilih
    document.querySelectorAll(`input[name="${field.name}"]`).forEach(r => r.checked = false);

    // Reset text
    document.getElementById(field.text).innerText = "-";

    document.getElementById(field.text).classList.remove("d-none");
    document.getElementById(field.input).classList.add("d-none");
  });
});

  const sections = document.querySelectorAll('.section');
  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');

let current = <?= $data['current'] ?>;

  function showSection(index) {
    sections.forEach((section, i) => {
      section.classList.add('d-none');
      if (i === index) {
        section.classList.remove('d-none');
      }
    });

    // Disable tombol jika di awal / akhir
    prevBtn.disabled = index === 0;
    nextBtn.disabled = index === sections.length - 1;
  }

  prevBtn.addEventListener('click', () => {
    if (current > 0) {
      current--;
      showSection(current);
    }
  });

  nextBtn.addEventListener('click', () => {
    if (current < sections.length - 1) {
      current++;
      showSection(current);
    }
  });

  // Tampilkan pertama kali
  showSection(current);
</script>