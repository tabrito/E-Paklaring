<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">

<style>

body {
  font-family: "Times New Roman", serif;
  font-size: 12px;
  margin-left: 30px;
  margin-right: 20px;
}

table {
  width: 100%;
  border-collapse: collapse;
}

td, th {
  border: 1px solid black;
  padding: 4px;
}

.no-border td {
  border: none;
}

.center {
  text-align: center;
}

.bold {
  font-weight: bold;
}

.small {
  font-size: 10px;
}

.line {
  border-bottom: 1px solid black;
  height: 15px;
}

.title {
  text-align: center;
  font-weight: bold;
  font-size: 14px;
}

.subtitle {
  text-align: center;
  font-style: italic;
  margin-bottom: 5px;
}

</style>

</head>
<body>


<!-- HEADER -->
<table>
<tr>

<td width="20%">
Issued by:<br>
<i>HRGA</i>
</td>

<td width="60%" class="center">
<b>PT SINERGI GLOBAL SERVIS</b><br>

<?php
$path = realpath(__DIR__ . '/../../../public/img/logo.png');
$type = pathinfo($path, PATHINFO_EXTENSION);
$dataImg = file_get_contents($path);
$base64 = 'data:image/' . $type . ';base64,' . base64_encode($dataImg);
?>

<img src="<?= $base64; ?>" width="150"></td>

<td width="20%">
Code Number:<br>
FORM 00
</td>

</tr>

<tr>

<td>Date issued:</td>
<td></td>
<td></td>

</tr>

</table>


<br>


<div class="title">EXIT INTERVIEW FORM</div>
<div class="subtitle">
Formulir Wawancara Karyawan yang Mengundurkan Diri
</div>


<br>


<strong>Karyawan terhormat,</strong><br><br>

Mohon luangkan sedikit waktu Anda untuk melengkapi Exit Interview Form ini. Kami sangat menghargai komentar atau umpan balik Anda selama bekerja dengan PT. Sinergi Global Servis. Kami menilai pendapat Anda.


<br><br>


<!-- DATA KARYAWAN -->
<table>
  

<tr>
<td width="25%"><strong>Nama<br><span class="small" style="font-style: italic;">Name</span></strong></td>
<td width="25%"><?= $data['exit']['first_name']; ?> <?= $data['exit']['last_name']; ?></td>

<td width="25%"><strong>Instansi<br><span class="small" style="font-style: italic;">Instantion</span></strong></td>
<td width="25%"><?= $data['exit']['instansi']; ?></td>
</tr>


<tr>
<td width="25%"><strong>No Karyawan<br><span class="small" style="font-style: italic;">Employee ID</span></strong></td>
<td><?= $data['exit']['nik']; ?></td>

<td width="25%"><strong>Departemen<br><span class="small" style="font-style: italic;">Department</span></strong></td>
<td><?= $data['exit']['departemen']; ?></td>
</tr>


<tr>
<td width="25%"><strong>Jabatan<br><span class="small" style="font-style: italic;">Position</span></strong></td>
<td><?= $data['exit']['jabatan']; ?></td>

<td width="25%"><strong>Tanggal Pengunduran Diri<br><span class="small" style="font-style: italic;">Resignion Date</span></strong></td>
<td><?= date('d F Y', strtotime($data['exit']['tanggal_resign'])); ?></td>
</tr>


<tr>
<td width="25%"><strong>Tanggal Masuk<br><span class="small" style="font-style: italic;">Date Hired</span></strong></td>
<td><?= date('d F Y', strtotime($data['exit']['tanggal_masuk'])); ?></td>

<td width="25%"><strong>Hari Kerja Terakhir<br><span class="small" style="font-style: italic;">Last Working Date</span></strong></td>
<td><?= date('d F Y', strtotime($data['exit']['tanggal_keluar'])); ?></td>
</tr>

</table>


<br><br>


<!-- PERTANYAAN -->


1. Mengapa Saudara mengundurkan diri ?  
<div class="line"><?= $data['exit']['alasan']; ?></div>
<div class="line"></div>
<div class="line"></div>

<br>

<?php $kepuasan = $data['exit']['kepuasan']; ?>

2. Seberapa puas Anda dengan pekerjaan ? <br><br>

<?php $kepuasan = $data['exit']['kepuasan']; ?>

<style>
.box {
  display: inline-block;
  width: 10px;
  height: 10px;
  border: 1px solid black;
  text-align: center;
  font-size: 10px;
  line-height: 10px;
}
</style>


<div>
<span class="box"><?= $kepuasan == 'Sangat Tidak Puas' ? 'X' : '' ?></span>
Sangat Tidak Puas
</div>

<div>
<span class="box"><?= $kepuasan == 'Tidak Puas' ? 'X' : '' ?></span>
Tidak Puas
</div>

<div>
<span class="box"><?= $kepuasan == 'Cukup Puas' ? 'X' : '' ?></span>
Cukup Puas
</div>

<div>
<span class="box"><?= $kepuasan == 'Puas' ? 'X' : '' ?></span>
Puas
</div>

<div>
<span class="box"><?= $kepuasan == 'Sangat Puas' ? 'X' : '' ?></span>
Sangat Puas
</div>

<br>

3. Hal yang paling diapresiasi  
<div class="line"><?= $data['exit']['apresiasi']; ?></div>
<div class="line"></div>

<br>

4. Saran untuk perusahaan  
<div class="line"><?= $data['exit']['saran']; ?></div>
<div class="line"></div>

<br>

<br><br>

5. Aset & Administrasi  
<br><br>
<table>
<tr>
<td width="50%" class="center" colspan="2">
<b>A. HUMAN RESOURCES DEPARTMENT</b>
</td>
</tr>

<tr>
<td width="50%">Seragam / Pakaian Kerja</td>
<td width="50%">: <?= $data['exit']['seragam']; ?></td>
</tr>

<tr>
<td>Kartu Identitas Karyawan ID Card</td>
<td>: <?= $data['exit']['id_card']; ?></td>
</tr>

<tr>
<td>Laptop</td>
<td>: <?= $data['exit']['laptop']; ?></td>
</tr>

<tr>
<td>Gaji Terakhir</td>
<td>: <?= "Rp " . number_format($data['exit']['gaji_terakhir'], 0, ',', '.'); ?></td>
</tr>

<tr>
<td>Sisa Cuti</td>
<td>: <?= $data['exit']['sisa_cuti']; ?> Hari</td>

</tr>
<tr>
<td width="50%" class="center" colspan="2">
<b>B. RELEVANT DEPARTMENT</b>
</td>
</tr>

<tr>
<td>File Pekerjaan . Flashdisk</td>
<td>: <?= $data['exit']['file_kerja']; ?></td>

</tr>
</table>

<br><br><br>

<!-- HEADER -->
<table>
<tr>

<td width="20%">
Issued by:<br>
<i>HRGA</i>
</td>

<td width="60%" class="center">
<b>PT SINERGI GLOBAL SERVIS</b><br>

<img src="<?= $base64; ?>" width="150"></td>

</td>

<td width="20%">
Code Number:<br>
FORM 00
</td>

</tr>

<tr>

<td>Date issued:</td>
<td></td>
<td></td>

</tr>

</table>

<br><br>

Berdasarkan segala hal tersebut diatas, apabila saya diperlukan sewaktu-waktu oleh perusahaan untuk dimintakan keterangan maka saya menyatakan bersedia untuk datang dan membantu perusahaan terhadap data-data yang saya kelola selama ini.

<br><br>

<table width="100%" class="no-border">

<tr>
<td colspan="2">
Jakarta , <?= date('d F Y', strtotime($data['exit']['tanggal_pengajuan'])); ?>
</td>
</tr>

<tr>
<td width="25%">Yang menyatakan,</td>
<td width="50%"></td>
<td width="25%">Disetujui oleh</td>
</tr>

<tr>
  <td width="25%">
    <?php if($data['exit']['approval_spv'] == "Approved") : ?>
    <?php

    $file = $data['app'][1]['ttd'];

    $path = realpath(__DIR__ . '/../../../public/img/ttd/' . $file);

    $type = pathinfo($path, PATHINFO_EXTENSION);

    $dataImg = file_get_contents($path);

    $base64 = 'data:image/' . $type . ';base64,' . base64_encode($dataImg);

    ?>
    <div>
    <img src="<?= $base64; ?>" width="150" height="80">
    </div>
    <?php else : ?>
      <div style="height: 80;"></div>
    <?php endif; ?>
  </td>
  <td width="50%"></td>
  <td width="25%">
  <?php if($data['exit']['approval_hr'] == "Approved") : ?>

  <?php
  $file_ttd = $data['app'][0]['ttd'];
  $file_stempel = 'stempel.png'; // nama file stempel kamu

  $path_ttd = realpath(__DIR__ . '/../../../public/img/ttd/' . $file_ttd);
  $path_stempel = realpath(__DIR__ . '/../../../public/img/ttd/' . $file_stempel);

  $type_ttd = pathinfo($path_ttd, PATHINFO_EXTENSION);
  $type_stempel = pathinfo($path_stempel, PATHINFO_EXTENSION);

  $dataImg_ttd = file_get_contents($path_ttd);
  $dataImg_stempel = file_get_contents($path_stempel);

  $base64_ttd = 'data:image/' . $type_ttd . ';base64,' . base64_encode($dataImg_ttd);
  $base64_stempel = 'data:image/' . $type_stempel . ';base64,' . base64_encode($dataImg_stempel);
  ?>

  <div style="position: relative; width:150px; height:100px;">
      
      <!-- Stempel (belakang) -->
      <img src="<?= $base64_stempel; ?>" 
          style="position:absolute; width:120px; height:120px; opacity:0.5; top:0; left:10px;">
      
      <!-- TTD (depan) -->
      <img src="<?= $base64_ttd; ?>" 
          style="position:absolute; width:150px; height:80px; top:20px; left:0;">
  </div>

  <?php else : ?>
  <div style="height: 80px;"></div>
  <?php endif; ?>
  </td>
</tr>

<tr>
<td>
<b><?= $data['app'][1]['first_name']; ?> <?= $data['app'][1]['last_name']; ?></b><br>
<?= $data['app'][1]['departemen']; ?> <?= $data['app'][1]['jabatan']; ?>
</td>

<td></td>

<td>
<b><?= $data['app'][0]['first_name']; ?> <?= $data['app'][0]['last_name']; ?></b><br>
<?= $data['app'][0]['departemen']; ?> <?= $data['app'][0]['jabatan']; ?>
</td>
</tr>

</table>
</body>
</html>