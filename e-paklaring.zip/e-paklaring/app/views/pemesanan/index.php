  <?php
  if ($_SESSION['user']['role'] == "Kepala Sekolah") {
    $_SESSION['after_submit'] = true;   // ← penanda
  }
?>  
  
  <!-- Flash Message -->
  <div class="row">
    <div class="col-lg-8">
      <?php Flasher::flash(); ?>
    </div>
  </div>

<div class="d-flex align-items-center mt-3 justify-content-between" style="padding-left: 20px; padding-right: 20px;">
  <?php if ($_SESSION['user']['role'] == "Kepala Sekolah") { ?>
    <h3 style="font-weight: bolder;">Pemesanan Barang</h3>
  <?php } ?>
  <?php if ($_SESSION['user']['role'] == "Admin") { ?>
  <form action="<?= BASEURL; ?>/pemesanan/cariBarang" method="post" class="flex-grow-1">
    <div class="input-group shadow-sm rounded w-100">
      <input type="text" class="form-control input-search" placeholder="Search..." name="keyword" id="keyword" autocomplete="off">
      <div class="input-group-append" style="">
        <button class="btn btn-search" type="submit" id="tombolCari">
          <i class="bi bi-search"></i> Cari
        </button>
      </div>
    </div>
  </form>

    <div class="d-flex">
      <a id="btnInputPemesanan" class="btn btn-hapus" style="margin-left: 50px; width: 120px; height: 40px;">Form Input</a>
      <a id="btnHistoryPemesanan" class="btn btn-ubah" style="margin-left: 10px; width: 120px; height: 40px;">History</a>
    </div>
  <?php } ?>

</div>

<!-- Daftar Barang -->
<div id="formPemesananDiv" style="margin-bottom: 20px; display: none; height: 300px; overflow-y: auto; overflow-x: hidden; scrollbar-width: none; -ms-overflow-style: none;">
  <div class="row">
    <div class="col-12">
    <div class="table-responsive table-transaksi shadow-sm rounded">
      <table class="table table-striped table-hover mb-0" style="font-size: 14px;">
          <thead>
            <tr>
              <th class="text-center table-title" colspan="7">Data Barang</th>
            </tr>
            <tr class="table-head">
              <th>No</th>
              <th>ID Barang</th>
              <th>Nama Barang</th>
              <th>Stok</th>
              <th>Stok Minimal</th>
              <th>Harga Satuan</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $no = 1; ?>
            <?php foreach ($data['brg'] as $brg) :
            $stok    = $brg['stok'] ?? 0;
            $minStok = $brg['min_stok'] ?? 0;
            $rowClass = ($stok < $minStok) ? 'stok-warning' : '';
            ?>
            <tr class="<?= $rowClass; ?>">
              <td><?= $no++; ?></td>
              <td><?= $brg['id_barang']; ?></td>
              <td><?= $brg['nama_barang']; ?></td>
              <td><?= $brg['stok'] ?? 0; ?></td>
              <td><?= $brg['min_stok'] ?? 0; ?></td>
              <td>Rp <?= number_format($brg['harga'], 0, ',', '.'); ?></td>
              <td>
                <a class="btn btn-sm btn-ubah mr-1 modalPesanBarang" data-id="<?= $brg['id_barang']; ?>">
                  <i class="bi bi-pencil"></i> Pesan Barang
                </a>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- Form Pemesanan -->
<div id="formPesananDiv" style="display: none; margin-top: 10px;">
  <form id="formPesanBarang" method="post" action="<?= BASEURL; ?>/pemesanan/tambahPesanan">
    <div class="table-responsive table-transaksi shadow-sm rounded">
      <table class="table table-striped table-hover mb-0" style="font-size: 14px;">      
        <thead class="">
        <tr>
          <th class="text-center table-title" colspan="8">Form Pemesanan</th>
        </tr>
        <tr class="table-head">
          <th style="width: 70px;">No</th>
          <th style="width: 100px;">ID Barang</th>
          <th>Nama Barang</th>
          <th>Pemasok</th>
          <th>Harga</th>
          <th style="width: 100px;">Qty</th>
          <th>Keterangan</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <!-- Baris baru akan ditambahkan di sini via JS -->
      </tbody>
    </table>
            </div>
    <div class="text-center mt-2">
      <button type="submit" class="btn btn-simpan shadow-sm rounded">
        <i class="bi bi-check-circle"></i> Submit
      </button>
    </div>
  </form>
</div>

<!-- History Pemesanan -->
<div id="historyPemesananDiv" style="display: none; height: 450px; overflow-y: auto; overflow-x: hidden; scrollbar-width: none; -ms-overflow-style: none;">
    <div class="table-responsive table-transaksi shadow-sm rounded">
      <table class="table table-striped table-hover mb-0" style="font-size: 14px;">
      <thead class="">
        <tr>
        <?php if ($_SESSION['user']['role'] == "Kepala Sekolah") { ?>
          <th class="text-center table-title" colspan="7">Request Pemesanan</th>
        <?php } else {?>
          <th class="text-center table-title" colspan="8">History Pemesanan</th>
        <?php }?>
        </tr>
        <tr class="table-head">          
          <th>No</th>
          <th>No Pesanan</th>
          <th>Date</th>
          <th>Persetujuan</th>
          <?php if ($_SESSION['user']['role'] == "Admin") { ?>
          <th>Penerimaan</th>
          <?php } ?>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
          <?php $no = 1; ?>
        <?php foreach ($data['history'] as $h) : ?>
          <?php
          $status = $h['disetujui'];

          // Tentukan warna berdasarkan value
          switch ($status) {
              case 'Diterima':
                  $color = '#03a600';
                  break;
              case 'Ditolak':
                  $color = '#c10000';
                  break;
              case 'Menunggu':
              case 'menunggu':
                  $color = '#343a40';
                  break;
              default:
                  $color = '#000'; // default hitam
          }
          ?>
        <tr>
          <td><?= $no++; ?></td>
          <td><?= $h['id_pesan']; ?></td>
          <td><?= date('d-M-y', strtotime($h['created_at'])); ?></td>
          <?php if ($_SESSION['user']['role'] == "Kepala Sekolah") : ?>
          <td class="d-flex">
          <?php if ($h['disetujui'] == "Menunggu") {?>
            <a href="<?= BASEURL; ?>/pemesanan/terimaPemesanan/<?= $h['id_pesan']; ?>" class="btn btn-sm btn-terima mr-1">Setuju</a>
            <a href="<?= BASEURL; ?>/pemesanan/tolakPemesanan/<?= $h['id_pesan']; ?>" class="btn btn-sm btn-tolak mr-1">Tolak</a>
          <?php } ?>
          <?php if ($h['disetujui'] == "Diterima") {?>
            <span style="color: <?= $color ?>; font-weight: bold;">
                <?= $h['disetujui']; ?>
            </span>
          <?php } ?>
          <?php if ($h['disetujui'] == "Ditolak") {?>
            <span style="color: <?= $color ?>; font-weight: bold;">
                <?= $h['disetujui']; ?>
            </span>
          <?php } ?>
          </td>
          <?php endif ?>
          <?php if ($_SESSION['user']['role'] == "Admin") : ?>
          <td>
            <span style="color: <?= $color ?>; font-weight: bold;">
                <?= $h['disetujui']; ?>
            </span>
          </td>
          <?php endif ?>
          <?php if ($_SESSION['user']['role'] == "Admin") : ?>
          <td>
            <?php if($h['disetujui'] == "Diterima") : ?>
            <a href="<?= BASEURL; ?>/penerimaan/detail/<?= $h['id_pesan']; ?>" class="btn btn-sm btn-ubah mr-1"><i class="bi bi-trash"></i> Terima Pesanan</a>
            <?php endif ?>
          </td>
          <?php endif ?>
          <td>
            <a href="<?= BASEURL; ?>/pemesanan/cetakPdf/<?= $h['id_pesan']; ?>" 
              class="btn btn-sm btn-ubah mr-1" target="_blank">
              <i class="bi bi-printer"></i> Cetak Dokumen
            </a>
            <a href="#"
              class="btn btn-sm btn-hapus mr-1 modalDetails"
              data-toggle="modal"
              data-target="#modalDetails"
              data-id="<?= $h['id_pesan']; ?>">
              <i class="bi bi-pencil-square"></i> Details
            </a>
            <?php if ($_SESSION['user']['role'] == "Admin") : ?>
            <a href="<?= BASEURL; ?>/pemesanan/hapusPemesanan/<?= $h['id_pesan']; ?>" class="btn btn-sm btn-hapus" onclick="return confirm('Yakin ingin menghapus?')"><i class="bi bi-trash"></i> Hapus</a>
            <?php endif ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal Edit Pemesanan -->
<div class="modal fade" id="modalEditPesanan" tabindex="-1" role="dialog" aria-labelledby="formModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content shadow rounded">

      <div class="modal-header bg-modal text-white">
        <h5 class="modal-title" id="formModalLabel">
          <i class="bi bi-pencil-square"></i> Detail Pemesanan
        </h5>
        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body">
        <form action="<?= BASEURL; ?>/pemesanan/updatePemesanan" method="post">

          <!-- id_pesan (hidden) -->
          <input type="hidden" id="id_barang_pesanan" name="id_barang_pesanan">

          <div class="form-group d-flex">
            <label class="form-label label-input" for="nama_barang">Nama Barang</label>
            <input type="text" class="form-control shadow-sm rounded" id="nama_barang" name="nama_barang" readonly>
          </div>

          <div class="form-group d-flex">
            <label class="form-label label-input" for="id_pemasok">Pemasok</label>
            <select class="form-control shadow-sm rounded" id="id_pemasok" name="id_pemasok">
              <option value="">-- Pilih Pemasok --</option>
              <?php foreach ($data['pemasok'] as $p): ?>
                <option value="<?= $p['id_pemasok']; ?>">
                  <?= $p['nama_pemasok']; ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="form-group d-flex">
            <label class="form-label label-input" for="qty">Qty</label>
            <input type="number" class="form-control shadow-sm rounded" id="qty" name="qty">
          </div>

          <div class="form-group d-flex">
            <label class="form-label label-input" for="keterangan">Keterangan</label>
            <textarea class="form-control shadow-sm rounded" id="keterangan" name="keterangan"></textarea>
          </div>

          <div class="modal-footer justify-content-center">
            <button type="submit" class="btn btn-simpan shadow-sm rounded">
              <i class="bi bi-check-circle"></i> Simpan Perubahan
            </button>
          </div>

        </form>
      </div>

    </div>
  </div>
</div>

<!-- Modal Detail Pemesanan -->
<div class="modal fade" id="modalDetails" tabindex="-1" role="dialog" aria-labelledby="modalDetailsLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content shadow rounded">

      <div class="modal-header bg-modal text-white">
        <h5 class="modal-title" id="modalDetailsLabel">
          <i class="bi bi-pencil-square"></i> Detail Pemesanan
        </h5>
        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body">

        <!-- WRAPPER KONTEN -->
        <div style="max-height:300px; overflow-y:auto; overflow-x:hidden;">

          <div class="table-responsive shadow-sm rounded">
            <table class="table table-striped table-hover mb-0" style="font-size: 14px;">
              <thead>
                <tr class="table-head">
                  <th width="5%">No</th>
                  <th width="20%">Nama Barang</th>
                  <th width="20%">Pemasok</th>
                  <th width="7%">Qty</th>
                  <th width="7%">Harga</th>
                  <th width="20%">Keterangan</th>
                  <th width="30%">Action</th>
                </tr>
              </thead>
              <tbody id="detailBarangBody">
                <tr>
                  <td colspan="6" class="text-center">Memuat data...</td>
                </tr>
              </tbody>
            </table>
          </div>

        </div>
      </div>

    </div>
  </div>
</div>

<!-- ✅ SIMPAN BASEURL DI SINI -->
<script>
  const BASEURL = "<?= BASEURL; ?>";
</script>

<script>
$(document).ready(function() {
  console.log($("#formPemesananDiv").length);
  // Tampilkan form input secara default
  $("#formPemesananDiv").show();
  $("#formPesananDiv").show();
  $("#historyPemesananDiv").hide();

  // Set tombol Form Input sebagai aktif
  $("#btnInputPemesanan").addClass("btn-aktif").removeClass("btn-nonaktif");
  $("#btnHistoryPemesanan").addClass("btn-nonaktif").removeClass("btn-aktif");

  // Toggle saat tombol diklik
  $("#btnInputPemesanan").on("click", function() {
    $("#formPemesananDiv").slideDown();
    $("#formPesananDiv").slideDown();
    $("#historyPemesananDiv").slideUp();

    $(this).addClass("btn-aktif").removeClass("btn-nonaktif");
    $("#btnHistoryPemesanan").addClass("btn-nonaktif").removeClass("btn-aktif");

    // Ganti judul
  });

  $("#btnHistoryPemesanan").on("click", function() {
    $("#historyPemesananDiv").slideDown();
    $("#formPemesananDiv").slideUp();
    $("#formPesananDiv").slideUp();

    $(this).addClass("btn-aktif").removeClass("btn-nonaktif");
    $("#btnInputPemesanan").addClass("btn-nonaktif").removeClass("btn-aktif");

    // Ganti judul
    $("#judulPemesanan").text("History Pemesanan");
  });

  function closeModal(modalId) {
    const modal = $(modalId);
    if (modal.hasClass('show')) {
      modal.find('[data-dismiss="modal"]').trigger('click');
    }
  }

  // Saat Modal Detail dibuka → tutup Modal Edit
  $('#modalDetails').on('show.bs.modal', function () {
    closeModal('#modalEditPesanan');
  });

  // Saat Modal Edit dibuka → tutup Modal Detail
  $('#modalEditPesanan').on('show.bs.modal', function () {
    closeModal('#modalDetails');
  });
});

</script>

<?php if (isset($_SESSION['after_submit'])): ?>
<script>
$(document).ready(function() {
    // JS yang ingin dijalankan setelah submit
    $("#historyPemesananDiv").slideDown();
    $("#formPemesananDiv").slideUp();
    $("#formPesananDiv").slideUp();

    $("#btnHistoryPemesanan").addClass("btn-aktif").removeClass("btn-nonaktif");
    $("#btnInputPemesanan").addClass("btn-nonaktif").removeClass("btn-aktif");

    $("#judulPemesanan").text("History Pemesanan");
});
</script>
<?php unset($_SESSION['after_submit']); endif; ?>

