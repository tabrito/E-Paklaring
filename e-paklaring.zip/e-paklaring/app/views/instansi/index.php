  <!-- Flash Message -->
  <div class="row">
    <div class="col-lg-8">
      <?php Flasher::flash(); ?>
    </div>
  </div>

<div class="main-content">
<div class="d-flex align-items-center mb-3">

  <div class="flex-fill text-center">
    <h4 class="table-title fw-bold mb-0">
      Data Instansi
    </h4>
  </div>

    <div>
    <a href="#" 
      class="btn btn-ubah px-3"
      data-bs-toggle="modal" 
      data-bs-target="#modalTambah">
      Tambah Instansi
    </a>
  </div>

</div>

<!-- Daftar Mahasiswa -->
<div class="row">
  <div class="col-12">
    <div class="" style="height: 360px;">
      <table class="table table-bordered mb-0" style="font-size: 14px;">
        <thead class="table-head text-center align-middle">
          <tr>
            <th>No</th>
            <th>ID Instansi</th>
            <th>Instansi</th>
            <th>Alamat</th>
            <th>Departemen</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php $no = 1; 
          ?>
          <?php foreach ($data['ins'] as $ins) : 
            ?>
            <tr class="<?= $rowClass; ?>">
              <td class="text-center"><?= $no++; ?></td>
              <td><?= $ins['id_instansi']; ?></td>
              <td><?= $ins['instansi']; ?></td>
              <td><?= $ins['alamat']; ?></td>
              <td class="d-flex" data-id_inst="<?= $ins['id_instansi']; ?>">
                <?php foreach($data['dep'] as $dep) : ?>
                  <?php if($dep['id_instansi'] == $ins['id_instansi']) : ?>
                    
                    <?php if($dep['nik']) : ?>
                    <div class="list-dept d-flex align-items-center">
                      <span><?= $dep['departemen']; ?></span>
                      <span class="del-dept ms-2" style="cursor:pointer;" data-id="<?= $dep['id_departemen']; ?> ">&times;</span>
                    </div>
                    <?php else : ?>
                    <div class="non-list-dept d-flex align-items-center">
                      <span><?= $dep['departemen']; ?></span>
                      <span class="del-dept ms-2" style="cursor:pointer;" data-id="<?= $dep['id_departemen']; ?>">&times;</span>
                    </div>
                    <?php endif ?>
                  <?php endif ?>
                <?php endforeach ?>
              <span class="add-dept ms-2">
                <i class="bi bi-plus"></i>
              </span>
              </td>
              <td class="text-center">
                <a href="#" 
                  class="btn btn-sm btn-tambah btn-edit"
                  data-bs-toggle="modal" 
                  data-bs-target="#modalTambah"
                  data-id="<?= $ins['id_instansi']; ?>"
                  data-instansi="<?= $ins['instansi']; ?>"
                  data-alamat="<?= $ins['alamat']; ?>">
                  Edit
                </a>
                <a href="<?= BASEURL; ?>/instansi/delete/<?= $ins['id_instansi']; ?>" 
                  class="btn btn-sm btn-hapus"
                  onclick="return confirm('Yakin ingin menghapus?')">
                  Delete
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <div class="mt-3 ml-1">
        <?php foreach ($data['dep'] as $dep) : 
          if($dep['nik'] == NULL) : ?>
            <label style="font-size: 14px;">Departemen <strong><?= $dep['departemen']; ?></strong> pada instansi <strong><?= $dep['instansi']; ?></strong> belum memiliki Approver - <a href="<?= BASEURL; ?>/approver" style="font-style: italic; color: #ff6e00;">Tambah Approver</a></li> 
        <?php endif;
        endforeach; ?>
      </div>
    </div>
  </div>
</div>

</div>

</div>

<!-- Modal Form -->
<div class="modal fade" id="modalTambah" tabindex="-1" role="dialog" aria-labelledby="formModalTambah" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content shadow rounded-lg">

      <!-- Header -->
      <div class="modal-header bg-modal text-white">
        <h5 class="modal-title w-100 text-center" id="formModalTambah">
          Tambah Instansi
        </h5>
      </div>

      <!-- Form -->
      <form action="<?= BASEURL; ?>/instansi/tambah" 
            method="post" 
            enctype="multipart/form-data">

        <div class="modal-body">

          <input type="hidden" name="id" id="id">
          <input type="hidden" name="id_barang" id="id_barang">
          <input type="hidden" name="foto_lama" id="foto_lama">

          <!-- Nama Barang -->
          <div class="form-group d-flex">
            <label style="width: 150px" class="label-modal" for="id_instansi"><strong>ID Instansi</strong></label>
            <input type="text" class="form-control" 
                   id="id_instansi" 
                   name="id_instansi" readonly value="<?= $data['idIns']; ?>">
          </div>

          <!-- Nama Barang -->
          <div class="form-group d-flex">
            <label style="width: 150px" class="label-modal" for="instansi"><strong>Instansi</strong></label>
            <input type="text" class="form-control" 
                   id="instansi" 
                   name="instansi" required>
          </div>

          <!-- Kategori -->
          <div class="form-group d-flex">
            <label style="width: 150px" class="label-modal" for="alamat"><strong>Alamat</strong></label>
            <input type="text" class="form-control" 
                   id="alamat" 
                   name="alamat" required>
          </div>

        </div>

        <!-- Footer -->
        <div class="modal-footer">
          <button type="button" 
                  class="btn btn-secondary" 
                  data-dismiss="modal">
            Batal
          </button>

          <button type="submit" 
                  class="btn btn-simpan">
            <i class="bi bi-check-circle"></i> Simpan
          </button>
        </div>

      </form>
    </div>
  </div>
</div>

<script>
    const modal = document.getElementById("modalTambah");
  const form = modal.querySelector("form");
    document.querySelectorAll(".btn-edit").forEach(button => {
    button.addEventListener("click", function () {

      // Ambil data
      const id = this.getAttribute("data-id");
      const instansi = this.getAttribute("data-instansi");
      const alamat = this.getAttribute("data-alamat");

      document.getElementById("id_instansi").value = id;
      document.getElementById("instansi").value = instansi;
      document.getElementById("alamat").value = alamat;

      // Ganti Judul Modal
      document.getElementById("formModalTambah").innerText = "Edit Instansi";

      // Ganti Action Form
      form.action = "<?= BASEURL; ?>/instansi/update";
    });
  });

  document.querySelectorAll(".add-dept").forEach(btn => {

  btn.addEventListener("click", function() {

    let td = this.parentElement;

    let div = document.createElement("div");
    div.className = "list-dept d-flex align-items-center px-1 py-0";

    div.innerHTML = `
      <input type="text"
        class="form-control form-control-sm m-0 border-0 shadow-none input-dept"
        style="width:80px; height:20px">
      <span class="del-dept" style="cursor:pointer;">&times;</span>
    `;

    td.insertBefore(div, this);

    let input = div.querySelector(".input-dept");

    input.focus();

    // event enter
    input.addEventListener("keydown", function(e) {

      if (e.key === "Enter") {

        e.preventDefault();

        let namaDept = this.value;
        let idInst = td.dataset.id_inst; // pastikan td punya ini

        fetch("<?= BASEURL; ?>/instansi/addDepartemen", {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded"
          },
          body: "departemen=" + namaDept + "&id_instansi=" + idInst
        })
        .then(res => res.text())
        .then(res => {

          console.log("RAW RES =", res);

          let idDept = res.trim();

          console.log("ID =", idDept);

          div.innerHTML = `
            <span>${namaDept}</span>
            <span class="del-dept"
                  style="cursor:pointer;"
                  data-id="${idDept}">
              &times;
            </span>
          `;

        });

      }

    });

  });

});

document.addEventListener("click", function(e) {

  let btn = e.target.closest(".del-dept");

  if (!btn) return;

  let konfirmasi = confirm("Yakin ingin menghapus departemen ini?");

  if (!konfirmasi) return;

  console.log(btn);
  console.log(btn.dataset.id);

  let id = btn.dataset.id;
  let div = btn.parentElement;

  if (!id) {
    div.remove();
    return;
  }

  fetch("<?= BASEURL; ?>/instansi/deleteDepartemen/" + id)
    .then(res => res.text())
    .then(res => {

      console.log(res);

      div.remove();

    });

});
</script>