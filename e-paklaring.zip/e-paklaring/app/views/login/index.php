<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">

<style>
.body-login {
  min-height: 100vh;
  background: linear-gradient(135deg, #feae00, #fe7b00);
  display: flex;
  justify-content: center;
  align-items: center;
}

/* Card Style */
.card {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border: none;
  border-radius: 20px;
  box-shadow: 0 15px 40px rgba(0,0,0,0.15);
}

/* Title */
h3 {
  font-weight: 700;
  color: #333;
}

/* Label */
.form-label {
  font-weight: 600;
  color: #fe7b00;
}

/* Input */
.form-control {
  border-radius: 10px;
  border: 1px solid #eee;
  padding: 10px 12px;
  transition: 0.3s ease;
}

.form-control:focus {
  border-color: #fe7b00;
  box-shadow: 0 0 0 3px rgba(254, 123, 0, 0.15);
}

/* Button */
.btn-login {
  background: linear-gradient(135deg, #feae00, #fe7b00);
  color: #fff;
  font-weight: 600;
  border: none;
  border-radius: 10px;
  padding: 10px;
  transition: 0.3s ease;
}

.btn-login:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(0,0,0,0.2);
}

/* Alert */
.alert {
  border-radius: 10px;
}
</style>
</head>
<body class="d-flex body-login justify-content-center align-items-center vh-100">
<div class="card p-4" style="width: 350px;">
    <h3 class="text-center mb-3">Login</h3>
    <?php if(!empty($data['error'])): ?>
        <div class="alert alert-danger"><?= $data['error']; ?></div>
    <?php endif; ?>
    <form action="<?= BASEURL; ?>/login/auth" method="post">
        <div class="mb-3">
          <label class="form-label">Username</label>
          <div class="input-group">
            <span class="input-group-text">
              <i class="bi bi-person-fill"></i>
            </span>
            <input type="text" name="username" class="form-control" placeholder="Masukkan username" required>
          </div>
        </div>
        <div class="mb-3">
          <label class="form-label">Password</label>
          <div class="input-group">
            <span class="input-group-text">
              <i class="bi bi-lock-fill"></i>
            </span>
            <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
          </div>
        </div>
        <button type="submit" class="btn btn-login w-100">Login</button>
    </form>
</div>
</body>
</html>
