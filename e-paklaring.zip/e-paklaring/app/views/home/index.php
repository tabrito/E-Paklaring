  <!-- Flash Message -->
  <div class="row">
    <div class="col-lg-8">
      <?php Flasher::flash(); ?>
    </div>
  </div>

<div class="row" style="margin-left: 20px;">

  <div class="col m-2 home-content">
    <div class="text-center"><b>Pengajuan</b></div>
    <div class="text-center m-2" style="color: #fe7b00; font-size: 40px"><b><?= $data['pengajuan']['count']; ?></b></div>
  </div>
  <div class="col m-2 home-content">
    <div class="text-center"><b>Exit Clear</b></div>
    <div class="text-center m-2" style="color: #fe7b00; font-size: 40px"><b><?= $data['exit_clear']['count']; ?></b></div>
  </div>
  <div class="col m-2 home-content">
    <div class="text-center"><b>Paklaring</b></div>
    <div class="text-center m-2" style="color: #fe7b00; font-size: 40px"><b><?= $data['paklaring']['count']; ?></b></div>
  </div>

</div>
<div class="row" style="margin-left: 20px;">

  <div class="col m-2 home-content">
    <div class="text-center"><b>Users</b></div>
    <div class="text-center m-2" style="color: #fe7b00; font-size: 40px"><b><?= $data['users']['count']; ?></b></div>
  </div>
  <div class="col m-2 home-content">
    <div class="text-center"><b>Karyawan</b></div>
    <div class="text-center m-2" style="color: #fe7b00; font-size: 40px"><b><?= $data['karyawan']['count']; ?></b></div>
  </div>
  <div class="col m-2 home-content">
    <div class="text-center"><b>Approver</b></div>
    <div class="text-center m-2" style="color: #fe7b00; font-size: 40px"><b><?= $data['approver']['count']; ?></b></div>
  </div>

</div>


</div>
