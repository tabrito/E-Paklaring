<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">

<style>

body {
  font-family: "Times New Roman", serif;
  font-size: 12px;
  margin: 40px;
}

.header {
  border-bottom: 2px solid #999;
  padding-bottom: 5px;
}

.title {
  text-align: center;
  font-weight: bold;
  font-size: 16px;
  margin-top: 20px;
}

.nomor {
  text-align: center;
  font-style: italic;
}

.konten {
  margin-top: 30px;
  line-height: 1.6;
}

.table-data {
  margin-left: 30px;
}

.right {
  text-align: right;
}

</style>

</head>
<body>


<!-- HEADER -->
<table width="100%" class="header">
<tr>

<td width="25%">

<?php
$path = realpath(__DIR__ . '/../../../public/img/logo.png');
$type = pathinfo($path, PATHINFO_EXTENSION);
$dataImg = file_get_contents($path);
$base64 = 'data:image/' . $type . ';base64,' . base64_encode($dataImg);
?>

<img src="<?= $base64; ?>" width="150"></td>

</td>

<td width="75%"></td>

</tr>
</table>



<div class="title">
SURAT KETERANGAN KERJA
</div>

<div class="nomor">
<?php $no = explode("-", $data['exit']['id_pengajuan']) ?>
<?php

$tgl = $data['exit']['tanggal_paklaring'];

$bulan = date('n', strtotime($tgl)); // 1 - 12
$tahun = date('Y', strtotime($tgl));

$romawi = [
    1 => 'I',
    2 => 'II',
    3 => 'III',
    4 => 'IV',
    5 => 'V',
    6 => 'VI',
    7 => 'VII',
    8 => 'VIII',
    9 => 'IX',
    10 => 'X',
    11 => 'XI',
    12 => 'XII'
];

$bulan_romawi = $romawi[$bulan];

?>
No : <?= $no[1]; ?>/SK-HRD-SGS/<?= $bulan_romawi; ?>/<?= $tahun; ?>
</div>



<div class="konten">

Kami yang bertandatangan di bawah ini, menerangkan bahwa :

<br><br>


<table class="table-data">

<tr>
<td width="120"><b>Nama</b></td>
<td width="10">:</td>
<td>
<b><?= $data['exit']['first_name']; ?> <?= $data['exit']['last_name']; ?></b>
</td>
</tr>

<tr>
<td><b>Tempat & Tanggal Lahir</b></td>
<td>:</td>
<td>

<b><?= $data['exit']['tempat_lahir']; ?>, <?= date('d F Y', strtotime($data['exit']['tanggal_lahir'])); ?></b>

</td>
</tr>

</table>


<br>


Adalah karyawan <b>PT. SINERGI GLOBAL SERVIS</b>, yang ditugaskan sebagai
<b><?= $data['exit']['jabatan']; ?> <?= $data['exit']['departemen']; ?></b>

di instansi

<b><?= $data['exit']['instansi']; ?></b>

sejak

<b><?= date('d F Y', strtotime($data['exit']['tanggal_masuk'])); ?></b>

sampai dengan

<b><?= date('d F Y', strtotime($data['exit']['tanggal_keluar'])); ?></b>.


<br><br>


Surat keterangan ini dibuat agar dipergunakan sebagaimana mestinya.


<br><br><br>


<div class="right">

Jakarta,
<?= date('d F Y', strtotime($data['exit']['tanggal_pengajuan'])); ?>

<br>

PT. SINERGI GLOBAL SERVIS

</div>


<?php

$file_ttd = $data['app'][0]['ttd'];
$file_stempel = 'stempel.png'; // sesuaikan nama file stempel

$path_ttd = realpath(__DIR__ . '/../../../public/img/ttd/' . $file_ttd);
$path_stempel = realpath(__DIR__ . '/../../../public/img/ttd/' . $file_stempel);

$type_ttd = pathinfo($path_ttd, PATHINFO_EXTENSION);
$type_stempel = pathinfo($path_stempel, PATHINFO_EXTENSION);

$dataImg_ttd = file_get_contents($path_ttd);
$dataImg_stempel = file_get_contents($path_stempel);

$base64_ttd = 'data:image/' . $type_ttd . ';base64,' . base64_encode($dataImg_ttd);
$base64_stempel = 'data:image/' . $type_stempel . ';base64,' . base64_encode($dataImg_stempel);

?>

<div style="text-align: right;">
    <div style="position: relative; width:150px; height:100px; display:inline-block;">

        <!-- Stempel -->
        <img src="<?= $base64_stempel; ?>" 
             style="position:absolute; width:120px; height:120px; opacity:0.5; top:0; left:15px;">

        <!-- TTD -->
        <img src="<?= $base64_ttd; ?>" 
             style="position:absolute; width:150px; height:80px; top:20px; left:0;">

    </div>
</div>

<table width="100%">
<tr>

<td width="75%"></td>

<td width="25%" align="center">

<b>
<?= $data['app'][0]['first_name']; ?> <?= $data['app'][0]['last_name']; ?>
</b>

<br>

<?= $data['app'][0]['departemen']; ?> <?= $data['app'][0]['jabatan']; ?>

</td>

</tr>
</table>


</div>


</body>
</html>