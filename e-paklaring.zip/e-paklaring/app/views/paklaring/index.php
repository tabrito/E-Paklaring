  <!-- Flash Message -->
  <div class="row">
    <div class="col-lg-8">
      <?php Flasher::flash(); ?>
    </div>
  </div>

<div class="main-content">
<div class="d-flex align-items-center mb-3">

  <div class="flex-fill text-center" style="width: 300px;">
    <h4 class="table-title fw-bold mb-0">Data Paklaring</h4>
  </div>

</div>

<!-- Daftar Mahasiswa -->
<div class="row">
  <div class="col-12">
    <div class="" style="height: 360px;">
      <table class="table table-bordered mb-0" style="font-size: 14px;">
        <thead class="table-head text-center align-middle">
          <tr>
            <th>No</th>
            <th>Tanggal Rilis</th>
            <th>Nama Karyawan</th>
            <th>Jabatan</th>
            <th>Departemen</th>
            <th>Instansi</th>
            <th>Tanggal Masuk</th>
            <th>Tanggal Keluar</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php $no = 1; 
          ?>
          <?php foreach ($data['pak'] as $pak) : 
            ?>
            <tr class="<?= $rowClass; ?>">
              <td class="text-center"><?= $no++; ?></td>
              <td class="text-center">
                <?= !empty($pak['tanggal_rilis']) 
                    ? date('d-M-y', strtotime($pak['tanggal_rilis'])) 
                    : '-' ?>
              </td>
              <td><?= $pak['first_name']; ?> <?= $pak['last_name']; ?></td>
              <td><?= $pak['jabatan']; ?></td>
              <td><?= $pak['departemen']; ?></td>
              <td><?= $pak['instansi']; ?></td>
              <td class="text-center">
                <?= !empty($pak['tanggal_masuk']) 
                    ? date('d-M-y', strtotime($pak['tanggal_masuk'])) 
                    : '-' ?>
              </td>
              <td class="text-center">
                <?= !empty($pak['tanggal_keluar']) 
                    ? date('d-M-y', strtotime($pak['tanggal_keluar'])) 
                    : '-' ?>
              </td>
              <td class="text-center">
                <a href="<?= BASEURL; ?>/paklaring/cetak_pdf/<?= $pak['nik']; ?>" 
                  class="btn btn-ubah px-3 ml-2">
                  Download
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
        <?php if($_SESSION['user']['role'] == 'Karyawan') :?>
          <?php if(empty($data['req'])) :?>
          <div class="d-flex justify-content-center mt-3">
            <label style="font-style: italic;">
              Anda belum mengajukan paklaring
            </label>
          </div>
          <?php elseif(empty($data['pak'])) : ?>
          <div class="d-flex justify-content-center mt-3">
            <label style="font-style: italic;">
              Paklaring sedang dalam proses
            </label>
          </div>
          <?php endif ?>
        <?php else :?>
          <?php if(empty($data['pak'])) :?>
          <div class="d-flex justify-content-center mt-3">
            <label style="font-style: italic;">
              Tidak ada data paklaring
            </label>
          </div>
          <?php endif ?>
        <?php endif ?>
    </div>
  </div>
</div>

</div>

</div>

<!-- Modal Form -->
<div class="modal fade" id="modalTambah" tabindex="-1" role="dialog" aria-labelledby="formModalTambah" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content shadow rounded-lg">

      <!-- Header -->
      <div class="modal-header bg-modal text-white">
        <h5 class="modal-title w-100 text-center" id="formModalTambah">
          <i class="bi bi-box-seam me-2"></i> Tambah Pengajuan
        </h5>
      </div>

      <!-- Form -->
      <form action="<?= BASEURL; ?>/master_barang/tambahBarang" 
            method="post" 
            enctype="multipart/form-data">

        <div class="modal-body">

          <input type="hidden" name="id" id="id">
          <input type="hidden" name="id_barang" id="id_barang">
          <input type="hidden" name="foto_lama" id="foto_lama">

          <!-- Nama Barang -->
          <div class="form-group d-flex">
            <label style="width: 150px" class="label-modal" for="nama_barang"><strong>Nama</strong></label>
            <input type="text" class="form-control" 
                   id="nama_barang" 
                   name="nama_barang" required>
          </div>

          <!-- Kategori -->
          <div class="form-group d-flex">
            <label style="width: 150px" class="label-modal" for="kategori"><strong>Kategori</strong></label>
            <select class="form-control" 
                    id="kategori" 
                    name="kategori" required>
              <option value="">-- Pilih Kategori --</option>
              <?php foreach ($data['kategori'] as $k) : ?>
                <option value="<?= $k['id_kategori']; ?>">
                  <?= $k['nama_kategori']; ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Stok Minimal -->
          <div class="form-group d-flex">
            <label style="width: 150px" class="label-modal" for="min_stok"><strong>Stok Minimal</strong></label>
            <input type="number" 
                   class="form-control" 
                   id="min_stok" 
                   name="min_stok" required>
          </div>

          <!-- Deskripsi -->
          <div class="form-group d-flex">
            <label style="width: 150px" class="label-modal" for="deskripsi"><strong>Deskripsi</strong></label>
            <textarea class="form-control" 
                      id="deskripsi" 
                      name="deskripsi" rows="3" required></textarea>
          </div>

          <!-- Foto -->
          <div class="form-group d-flex">
            <label style="width: 150px" class="label-modal" for="foto"> <strong>Foto Barang</strong></label>
            <input type="file" 
                   class="form-control-file" 
                   id="foto" 
                   name="foto" 
                   accept="image/*"
                   onchange="previewImage()" required>
          </div>

          <!-- Preview -->
          <div class="text-center">
            <img id="preview" 
                 class="img-fluid mt-3 rounded shadow-sm" 
                 style="max-height: 250px; display:none;">
          </div>

        </div>

        <!-- Footer -->
        <div class="modal-footer">
          <button type="button" 
                  class="btn btn-secondary" 
                  data-dismiss="modal">
            Batal
          </button>

          <button type="submit" 
                  class="btn btn-simpan">
            <i class="bi bi-check-circle"></i> Simpan
          </button>
        </div>

      </form>
    </div>
  </div>
</div>