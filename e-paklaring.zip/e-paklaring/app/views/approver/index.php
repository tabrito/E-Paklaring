  <!-- Flash Message -->
  <div class="row">
    <div class="col-lg-8">
      <?php Flasher::flash(); ?>
    </div>
  </div>

<div class="main-content">
<div class="d-flex align-items-center mb-3">
  <div>
    <a href="#" 
      class="btn btn-ubah px-3"
      data-bs-toggle="modal" 
      data-bs-target="#modalTambah">
      Tambah Approver
    </a>
  </div>

  <div class="flex-fill text-center">
    <h4 class="table-title fw-bold mb-0">
      Data Approver
    </h4>
  </div>

  <div>
    <form action="<?= BASEURL; ?>/approver/importExcel" 
          method="post" 
          enctype="multipart/form-data"
          id="formImport">

      <input type="file" 
            name="file_excel" 
            id="file_excel"
            accept=".xls,.xlsx"
            style="display:none"
            onchange="document.getElementById('formImport').submit()">

      <button type="button"
              class="btn btn-tambah px-3 ml-2"
              onclick="document.getElementById('file_excel').click()">
        Import Excel
      </button>

    </form>
  </div>
    <div>
  <a href="<?= BASEURL; ?>/approver/downloadTemplate" 
    class="btn btn-tambah px-3 ml-2">
    Download Template
  </a>
  </div>

</div>

<!-- Daftar Mahasiswa -->
<div class="row">
  <div class="col-12">
    <div class="" style="height: 360px;">
      <table class="table table-bordered mb-0" style="font-size: 14px;">
        <thead class="table-head text-center align-middle">
          <tr>
            <th>No</th>
            <th>NIK</th>
            <th>Nama Approver</th>
            <th>Jabatan</th>
            <th>Departemen</th>
            <th>Instansi</th>
            <th>Status</th>
            <th>TTD</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php $no = 1; 
          ?>
          <?php foreach ($data['app'] as $app) : 
            ?>
            <tr class="<?= $rowClass; ?>">
              <td class="text-center"><?= $no++; ?></td>
              <td><?= $app['nik']; ?></td>
              <td><?= $app['first_name']; ?> <?= $app['last_name']; ?></td>
              <td><?= $app['jabatan']; ?></td>
              <td><?= $app['departemen']; ?></td>
              <td><?= $app['instansi']; ?></td>
              <td><?= $app['status']; ?></td>
              <td>
                <?php if($app['ttd']) : ?>
                  <?= $app['ttd']; ?>
                <?php else : ?>
                  <form action="<?= BASEURL; ?>/approver/uploadTTD" 
                        method="post" 
                        enctype="multipart/form-data"
                        id="formTTD">

                    <input type="file" 
                          name="ttd"
                          id="file_ttd"
                          accept="image/*"
                          style="display:none"
                          onchange="document.getElementById('formTTD').submit()">
                    
                    <input type="hidden" name="nik" value="<?= $app['nik']; ?>">

                    <button type="button"
                            class="btn btn-tambah px-3"
                            onclick="document.getElementById('file_ttd').click()">
                      <i class="fas fa-plus"></i> TTD
                    </button>

                  </form>
                <?php endif; ?>
              </td>
              <td class="text-center">
                <a href="#" 
                  class="btn btn-tambah"
                  id="btn-edit-approver"
                  data-bs-toggle="modal" 
                  data-bs-target="#modalTambah"

                  data-nik="<?= $app['nik']; ?>"
                  data-first="<?= $app['first_name']; ?>"
                  data-last="<?= $app['last_name']; ?>"
                  data-id_inst="<?= $app['id_instansi']; ?>"
                  data-inst="<?= $app['instansi']; ?>"
                  data-id_dept="<?= $app['id_departemen']; ?>"
                  data-dept="<?= $app['departemen']; ?>"
                  data-jabatan="<?= $app['jabatan']; ?>"
                  data-ttd="<?= $app['ttd']; ?>">

                  Edit
                </a>
                <a href="<?= BASEURL; ?>/approver/delete/<?= $app['nik']; ?>" 
                  class="btn btn-sm btn-hapus"
                  onclick="return confirm('Yakin ingin menghapus?')">
                  Delete
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

</div>

</div>

<!-- Modal Form -->
<div class="modal fade" id="modalTambah" tabindex="-1" role="dialog" aria-labelledby="formModalTambah" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content shadow rounded-lg">

      <!-- Header -->
      <div class="modal-header bg-modal text-white">
        <h5 class="modal-title w-100 text-center" id="formModalTambah">
          Tambah Approver
        </h5>
      </div>

        <!-- Form Tambah Karyawan -->
        <form action="<?= BASEURL; ?>/approver/tambah" 
              method="post"
              enctype="multipart/form-data">
          <div class="modal-body">

            <!-- NIK -->
            <div class="form-group d-flex mb-3">
              <label style="width:150px"><strong>NIK</strong></label>
              <input type="text" name="nik" class="form-control" required>
              <input type="hidden" name="nik_lama" id="nik_lama">
            </div>

            <!-- Nama Depan -->
            <div class="form-group d-flex mb-3">
              <label style="width:150px"><strong>First Name</strong></label>
              <input type="text" name="first_name" class="form-control" required>
            </div>

            <!-- Nama Belakang -->
            <div class="form-group d-flex mb-3">
              <label style="width:150px"><strong>Last Name</strong></label>
              <input type="text" name="last_name" class="form-control" required>
            </div>

            <!-- Instansi -->
            <div class="form-group d-flex mb-3">
              <label style="width:150px"><strong>Instansi</strong></label>
              <select id="id_instansi" class="form-control" required>
                <option value="">-- Pilih Instansi --</option>
                <?php foreach ($data['ins'] as $i) : ?>
                  <option value="<?= $i['id_instansi']; ?>">
                    <?= $i['instansi']; ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>

            <!-- Departemen -->
            <div class="form-group d-flex mb-3">
              <label style="width:150px"><strong>Departemen</strong></label>
              <select name="id_departemen" id="id_departemen" class="form-control" required>
                <option value="">-- Pilih Departemen --</option>
                <option id="id_choosen" value="" selected></option>
              </select>
            </div>

            <!-- Jabatan -->
            <div class="form-group d-flex mb-3">
              <label style="width:150px"><strong>Jabatan</strong></label>
              <input type="text" style="background-color: white;" class="form-control" name="jabatan" id="jabatan" readonly required>
            </div>

            <!-- TTD -->
            <div class="form-group d-flex mb-3">
              <label style="width:150px"><strong>TTD</strong></label>

              <input type="file" 
                    name="ttd" 
                    class="form-control" 
                    accept="image/*"
                    required>
              <input type="hidden" name="ttd_lama" id="ttd_lama">
            </div>

                          <!-- Preview -->
              <img id="preview-ttd" 
                  class="mt-3 rounded shadow-sm"
                  style="width: 200px; display:none; margin-left: 150px;">

          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
              Batal
            </button>

            <button type="submit" class="btn btn-simpan">
              Simpan
            </button>
          </div>

        </form>
    </div>
  </div>
</div>


<script>
  
document.getElementById("id_instansi").addEventListener("change", function() {

  let id_instansi = this.value;
  let departemenSelect = document.getElementById("id_departemen");

  departemenSelect.innerHTML = '<option value="">Loading...</option>';

  fetch("<?= BASEURL; ?>/approver/getDepartemen/" + id_instansi)
    .then(response => response.json())
    .then(data => {

      departemenSelect.innerHTML = '<option value="">-- Pilih Departemen --</option>';

      data.forEach(function(dep) {
              console.log(dep)
        departemenSelect.innerHTML += 
          `<option value="${dep.id_departemen}">
            ${dep.departemen}
          </option>`;
      });

    });
});

document.addEventListener("DOMContentLoaded", function() {

  const modal = document.getElementById("modalTambah");
  const form = modal.querySelector("form");

  document.querySelectorAll("#btn-edit-approver").forEach(button => {
    button.addEventListener("click", function() {
      // Ambil data
      const nik = this.dataset.nik;

      document.getElementById("nik_lama").value = nik;
      document.querySelector("[name='nik']").value = nik;
      document.querySelector("[name='first_name']").value = this.dataset.first;
      document.querySelector("[name='last_name']").value = this.dataset.last;

      document.querySelector("#id_instansi").value = this.dataset.id_inst;

      const id_departemen = this.getAttribute("data-id_departemen");

      // Isi form
      document.getElementById("id_choosen").value = this.dataset.id_dept;
      document.getElementById("id_choosen").textContent = this.dataset.dept;

      let departemenSelect = document.getElementById("id_departemen");

      // simpan dulu dataset
      let idDept = this.dataset.id_dept;

      fetch("<?= BASEURL; ?>/approver/getDepartemen/" + this.dataset.id_inst)
        .then(response => response.json())
        .then(data => {

          data.forEach(function(dep) {

            let selected = (dep.id_departemen == idDept) ? "selected" : "";

            departemenSelect.innerHTML += 
              `<option value="${dep.id_departemen}" ${selected}>
                ${dep.departemen}
              </option>`;
          });

        });

      document.querySelector("#id_departemen").value = this.dataset.id_dept;
      document.querySelector("[name='jabatan']").value = this.dataset.jabatan;


      // Simpan nama ttd lama
      document.getElementById("ttd_lama").value = this.dataset.ttd;
      let fileInput = document.querySelector("input[name='ttd']");
      fileInput.removeAttribute("required");


      // Tampilkan preview
      const preview = document.getElementById("preview-ttd");

      if (this.dataset.ttd) {
        preview.src = "<?= BASEURL; ?>/img/ttd/" + this.dataset.ttd;
        preview.style.display = "block";
      } else {
        preview.style.display = "none";
      }

      // Ganti Judul
      document.getElementById("formModalTambah").innerText = "Edit Approver";

      // Ganti Action
      form.action = "<?= BASEURL; ?>/approver/update";

    });
  });

  const departemen = document.getElementById("id_departemen");

  const jabatan = document.getElementById("jabatan");

  departemen.addEventListener("change", function () {

    let dep = this.value;

    console.log(dep);

    if (dep === "HRD") {
      jabatan.value = "Manager";
    } else if (dep !== "") {
      jabatan.value = "Supervisor";
    } else {
      jabatan.value = "";
    }

  });

});

document.getElementById("ttd").addEventListener("change", function(e) {
    const file = e.target.files[0];
    const preview = document.getElementById("preview-ttd");

    if (file) {
        const reader = new FileReader();

        reader.onload = function(event) {
            preview.src = event.target.result;
            preview.style.display = "block";
        }

        reader.readAsDataURL(file);
    } else {
        preview.style.display = "none";
    }
});
</script>